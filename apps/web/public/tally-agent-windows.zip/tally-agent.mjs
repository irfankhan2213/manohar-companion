#!/usr/bin/env node
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/util.js
var require_util = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/util.js"(exports) {
    "use strict";
    var nameStartChar = ":A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD";
    var nameChar = nameStartChar + "\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040";
    var nameRegexp = "[" + nameStartChar + "][" + nameChar + "]*";
    var regexName = new RegExp("^" + nameRegexp + "$");
    var getAllMatches = function(string, regex) {
      const matches = [];
      let match = regex.exec(string);
      while (match) {
        const allmatches = [];
        allmatches.startIndex = regex.lastIndex - match[0].length;
        const len = match.length;
        for (let index = 0; index < len; index++) {
          allmatches.push(match[index]);
        }
        matches.push(allmatches);
        match = regex.exec(string);
      }
      return matches;
    };
    var isName = function(string) {
      const match = regexName.exec(string);
      return !(match === null || typeof match === "undefined");
    };
    exports.isExist = function(v) {
      return typeof v !== "undefined";
    };
    exports.isEmptyObject = function(obj) {
      return Object.keys(obj).length === 0;
    };
    exports.merge = function(target, a, arrayMode) {
      if (a) {
        const keys = Object.keys(a);
        const len = keys.length;
        for (let i = 0; i < len; i++) {
          if (arrayMode === "strict") {
            target[keys[i]] = [a[keys[i]]];
          } else {
            target[keys[i]] = a[keys[i]];
          }
        }
      }
    };
    exports.getValue = function(v) {
      if (exports.isExist(v)) {
        return v;
      } else {
        return "";
      }
    };
    var DANGEROUS_PROPERTY_NAMES = [
      // '__proto__',
      // 'constructor',
      // 'prototype',
      "hasOwnProperty",
      "toString",
      "valueOf",
      "__defineGetter__",
      "__defineSetter__",
      "__lookupGetter__",
      "__lookupSetter__"
    ];
    var criticalProperties = ["__proto__", "constructor", "prototype"];
    exports.isName = isName;
    exports.getAllMatches = getAllMatches;
    exports.nameRegexp = nameRegexp;
    exports.DANGEROUS_PROPERTY_NAMES = DANGEROUS_PROPERTY_NAMES;
    exports.criticalProperties = criticalProperties;
  }
});

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/validator.js
var require_validator = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/validator.js"(exports) {
    "use strict";
    var util = require_util();
    var defaultOptions = {
      allowBooleanAttributes: false,
      //A tag can have attributes without any value
      unpairedTags: []
    };
    exports.validate = function(xmlData, options) {
      options = Object.assign({}, defaultOptions, options);
      const tags = [];
      let tagFound = false;
      let reachedRoot = false;
      if (xmlData[0] === "\uFEFF") {
        xmlData = xmlData.substr(1);
      }
      for (let i = 0; i < xmlData.length; i++) {
        if (xmlData[i] === "<" && xmlData[i + 1] === "?") {
          i += 2;
          i = readPI(xmlData, i);
          if (i.err) return i;
        } else if (xmlData[i] === "<") {
          let tagStartPos = i;
          i++;
          if (xmlData[i] === "!") {
            i = readCommentAndCDATA(xmlData, i);
            continue;
          } else {
            let closingTag = false;
            if (xmlData[i] === "/") {
              closingTag = true;
              i++;
            }
            let tagName = "";
            for (; i < xmlData.length && xmlData[i] !== ">" && xmlData[i] !== " " && xmlData[i] !== "	" && xmlData[i] !== "\n" && xmlData[i] !== "\r"; i++) {
              tagName += xmlData[i];
            }
            tagName = tagName.trim();
            if (tagName[tagName.length - 1] === "/") {
              tagName = tagName.substring(0, tagName.length - 1);
              i--;
            }
            if (!validateTagName(tagName)) {
              let msg;
              if (tagName.trim().length === 0) {
                msg = "Invalid space after '<'.";
              } else {
                msg = "Tag '" + tagName + "' is an invalid name.";
              }
              return getErrorObject("InvalidTag", msg, getLineNumberForPosition(xmlData, i));
            }
            const result = readAttributeStr(xmlData, i);
            if (result === false) {
              return getErrorObject("InvalidAttr", "Attributes for '" + tagName + "' have open quote.", getLineNumberForPosition(xmlData, i));
            }
            let attrStr = result.value;
            i = result.index;
            if (attrStr[attrStr.length - 1] === "/") {
              const attrStrStart = i - attrStr.length;
              attrStr = attrStr.substring(0, attrStr.length - 1);
              const isValid = validateAttributeString(attrStr, options);
              if (isValid === true) {
                tagFound = true;
              } else {
                return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, attrStrStart + isValid.err.line));
              }
            } else if (closingTag) {
              if (!result.tagClosed) {
                return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' doesn't have proper closing.", getLineNumberForPosition(xmlData, i));
              } else if (attrStr.trim().length > 0) {
                return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' can't have attributes or invalid starting.", getLineNumberForPosition(xmlData, tagStartPos));
              } else if (tags.length === 0) {
                return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' has not been opened.", getLineNumberForPosition(xmlData, tagStartPos));
              } else {
                const otg = tags.pop();
                if (tagName !== otg.tagName) {
                  let openPos = getLineNumberForPosition(xmlData, otg.tagStartPos);
                  return getErrorObject(
                    "InvalidTag",
                    "Expected closing tag '" + otg.tagName + "' (opened in line " + openPos.line + ", col " + openPos.col + ") instead of closing tag '" + tagName + "'.",
                    getLineNumberForPosition(xmlData, tagStartPos)
                  );
                }
                if (tags.length == 0) {
                  reachedRoot = true;
                }
              }
            } else {
              const isValid = validateAttributeString(attrStr, options);
              if (isValid !== true) {
                return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, i - attrStr.length + isValid.err.line));
              }
              if (reachedRoot === true) {
                return getErrorObject("InvalidXml", "Multiple possible root nodes found.", getLineNumberForPosition(xmlData, i));
              } else if (options.unpairedTags.indexOf(tagName) !== -1) {
              } else {
                tags.push({ tagName, tagStartPos });
              }
              tagFound = true;
            }
            for (i++; i < xmlData.length; i++) {
              if (xmlData[i] === "<") {
                if (xmlData[i + 1] === "!") {
                  i++;
                  i = readCommentAndCDATA(xmlData, i);
                  continue;
                } else if (xmlData[i + 1] === "?") {
                  i = readPI(xmlData, ++i);
                  if (i.err) return i;
                } else {
                  break;
                }
              } else if (xmlData[i] === "&") {
                const afterAmp = validateAmpersand(xmlData, i);
                if (afterAmp == -1)
                  return getErrorObject("InvalidChar", "char '&' is not expected.", getLineNumberForPosition(xmlData, i));
                i = afterAmp;
              } else {
                if (reachedRoot === true && !isWhiteSpace(xmlData[i])) {
                  return getErrorObject("InvalidXml", "Extra text at the end", getLineNumberForPosition(xmlData, i));
                }
              }
            }
            if (xmlData[i] === "<") {
              i--;
            }
          }
        } else {
          if (isWhiteSpace(xmlData[i])) {
            continue;
          }
          return getErrorObject("InvalidChar", "char '" + xmlData[i] + "' is not expected.", getLineNumberForPosition(xmlData, i));
        }
      }
      if (!tagFound) {
        return getErrorObject("InvalidXml", "Start tag expected.", 1);
      } else if (tags.length == 1) {
        return getErrorObject("InvalidTag", "Unclosed tag '" + tags[0].tagName + "'.", getLineNumberForPosition(xmlData, tags[0].tagStartPos));
      } else if (tags.length > 0) {
        return getErrorObject("InvalidXml", "Invalid '" + JSON.stringify(tags.map((t) => t.tagName), null, 4).replace(/\r?\n/g, "") + "' found.", { line: 1, col: 1 });
      }
      return true;
    };
    function isWhiteSpace(char) {
      return char === " " || char === "	" || char === "\n" || char === "\r";
    }
    function readPI(xmlData, i) {
      const start = i;
      for (; i < xmlData.length; i++) {
        if (xmlData[i] == "?" || xmlData[i] == " ") {
          const tagname = xmlData.substr(start, i - start);
          if (i > 5 && tagname === "xml") {
            return getErrorObject("InvalidXml", "XML declaration allowed only at the start of the document.", getLineNumberForPosition(xmlData, i));
          } else if (xmlData[i] == "?" && xmlData[i + 1] == ">") {
            i++;
            break;
          } else {
            continue;
          }
        }
      }
      return i;
    }
    function readCommentAndCDATA(xmlData, i) {
      if (xmlData.length > i + 5 && xmlData[i + 1] === "-" && xmlData[i + 2] === "-") {
        for (i += 3; i < xmlData.length; i++) {
          if (xmlData[i] === "-" && xmlData[i + 1] === "-" && xmlData[i + 2] === ">") {
            i += 2;
            break;
          }
        }
      } else if (xmlData.length > i + 8 && xmlData[i + 1] === "D" && xmlData[i + 2] === "O" && xmlData[i + 3] === "C" && xmlData[i + 4] === "T" && xmlData[i + 5] === "Y" && xmlData[i + 6] === "P" && xmlData[i + 7] === "E") {
        let angleBracketsCount = 1;
        for (i += 8; i < xmlData.length; i++) {
          if (xmlData[i] === "<") {
            angleBracketsCount++;
          } else if (xmlData[i] === ">") {
            angleBracketsCount--;
            if (angleBracketsCount === 0) {
              break;
            }
          }
        }
      } else if (xmlData.length > i + 9 && xmlData[i + 1] === "[" && xmlData[i + 2] === "C" && xmlData[i + 3] === "D" && xmlData[i + 4] === "A" && xmlData[i + 5] === "T" && xmlData[i + 6] === "A" && xmlData[i + 7] === "[") {
        for (i += 8; i < xmlData.length; i++) {
          if (xmlData[i] === "]" && xmlData[i + 1] === "]" && xmlData[i + 2] === ">") {
            i += 2;
            break;
          }
        }
      }
      return i;
    }
    var doubleQuote = '"';
    var singleQuote = "'";
    function readAttributeStr(xmlData, i) {
      let attrStr = "";
      let startChar = "";
      let tagClosed = false;
      for (; i < xmlData.length; i++) {
        if (xmlData[i] === doubleQuote || xmlData[i] === singleQuote) {
          if (startChar === "") {
            startChar = xmlData[i];
          } else if (startChar !== xmlData[i]) {
          } else {
            startChar = "";
          }
        } else if (xmlData[i] === ">") {
          if (startChar === "") {
            tagClosed = true;
            break;
          }
        }
        attrStr += xmlData[i];
      }
      if (startChar !== "") {
        return false;
      }
      return {
        value: attrStr,
        index: i,
        tagClosed
      };
    }
    var validAttrStrRegxp = new RegExp(`(\\s*)([^\\s=]+)(\\s*=)?(\\s*(['"])(([\\s\\S])*?)\\5)?`, "g");
    function validateAttributeString(attrStr, options) {
      const matches = util.getAllMatches(attrStr, validAttrStrRegxp);
      const attrNames = {};
      for (let i = 0; i < matches.length; i++) {
        if (matches[i][1].length === 0) {
          return getErrorObject("InvalidAttr", "Attribute '" + matches[i][2] + "' has no space in starting.", getPositionFromMatch(matches[i]));
        } else if (matches[i][3] !== void 0 && matches[i][4] === void 0) {
          return getErrorObject("InvalidAttr", "Attribute '" + matches[i][2] + "' is without value.", getPositionFromMatch(matches[i]));
        } else if (matches[i][3] === void 0 && !options.allowBooleanAttributes) {
          return getErrorObject("InvalidAttr", "boolean attribute '" + matches[i][2] + "' is not allowed.", getPositionFromMatch(matches[i]));
        }
        const attrName = matches[i][2];
        if (!validateAttrName(attrName)) {
          return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is an invalid name.", getPositionFromMatch(matches[i]));
        }
        if (!attrNames.hasOwnProperty(attrName)) {
          attrNames[attrName] = 1;
        } else {
          return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is repeated.", getPositionFromMatch(matches[i]));
        }
      }
      return true;
    }
    function validateNumberAmpersand(xmlData, i) {
      let re = /\d/;
      if (xmlData[i] === "x") {
        i++;
        re = /[\da-fA-F]/;
      }
      for (; i < xmlData.length; i++) {
        if (xmlData[i] === ";")
          return i;
        if (!xmlData[i].match(re))
          break;
      }
      return -1;
    }
    function validateAmpersand(xmlData, i) {
      i++;
      if (xmlData[i] === ";")
        return -1;
      if (xmlData[i] === "#") {
        i++;
        return validateNumberAmpersand(xmlData, i);
      }
      let count = 0;
      for (; i < xmlData.length; i++, count++) {
        if (xmlData[i].match(/\w/) && count < 20)
          continue;
        if (xmlData[i] === ";")
          break;
        return -1;
      }
      return i;
    }
    function getErrorObject(code, message, lineNumber) {
      return {
        err: {
          code,
          msg: message,
          line: lineNumber.line || lineNumber,
          col: lineNumber.col
        }
      };
    }
    function validateAttrName(attrName) {
      return util.isName(attrName);
    }
    function validateTagName(tagname) {
      return util.isName(tagname);
    }
    function getLineNumberForPosition(xmlData, index) {
      const lines = xmlData.substring(0, index).split(/\r?\n/);
      return {
        line: lines.length,
        // column number is last line's length + 1, because column numbering starts at 1:
        col: lines[lines.length - 1].length + 1
      };
    }
    function getPositionFromMatch(match) {
      return match.startIndex + match[1].length;
    }
  }
});

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/OptionsBuilder.js
var require_OptionsBuilder = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/OptionsBuilder.js"(exports) {
    var { DANGEROUS_PROPERTY_NAMES, criticalProperties } = require_util();
    var defaultOnDangerousProperty = (name) => {
      if (DANGEROUS_PROPERTY_NAMES.includes(name)) {
        return "__" + name;
      }
      return name;
    };
    var defaultOptions = {
      preserveOrder: false,
      attributeNamePrefix: "@_",
      attributesGroupName: false,
      textNodeName: "#text",
      ignoreAttributes: true,
      removeNSPrefix: false,
      // remove NS from tag name or attribute name if true
      allowBooleanAttributes: false,
      //a tag can have attributes without any value
      //ignoreRootElement : false,
      parseTagValue: true,
      parseAttributeValue: false,
      trimValues: true,
      //Trim string values of tag and attributes
      cdataPropName: false,
      numberParseOptions: {
        hex: true,
        leadingZeros: true,
        eNotation: true
      },
      tagValueProcessor: function(tagName, val) {
        return val;
      },
      attributeValueProcessor: function(attrName, val) {
        return val;
      },
      stopNodes: [],
      //nested tags will not be parsed even for errors
      alwaysCreateTextNode: false,
      isArray: () => false,
      commentPropName: false,
      unpairedTags: [],
      processEntities: true,
      htmlEntities: false,
      ignoreDeclaration: false,
      ignorePiTags: false,
      transformTagName: false,
      transformAttributeName: false,
      updateTag: function(tagName, jPath, attrs) {
        return tagName;
      },
      // skipEmptyListItem: false
      captureMetaData: false,
      maxNestedTags: 100,
      strictReservedNames: true,
      onDangerousProperty: defaultOnDangerousProperty
    };
    function validatePropertyName(propertyName, optionName) {
      if (typeof propertyName !== "string") {
        return;
      }
      const normalized = propertyName.toLowerCase();
      if (DANGEROUS_PROPERTY_NAMES.some((dangerous) => normalized === dangerous.toLowerCase())) {
        throw new Error(
          `[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`
        );
      }
      if (criticalProperties.some((dangerous) => normalized === dangerous.toLowerCase())) {
        throw new Error(
          `[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`
        );
      }
    }
    function normalizeProcessEntities(value) {
      if (typeof value === "boolean") {
        return {
          enabled: value,
          // true or false
          maxEntitySize: 1e4,
          maxExpansionDepth: 10,
          maxTotalExpansions: 1e3,
          maxExpandedLength: 1e5,
          allowedTags: null,
          tagFilter: null
        };
      }
      if (typeof value === "object" && value !== null) {
        return {
          enabled: value.enabled !== false,
          maxEntitySize: Math.max(1, value.maxEntitySize ?? 1e4),
          maxExpansionDepth: Math.max(1, value.maxExpansionDepth ?? 1e4),
          maxTotalExpansions: Math.max(1, value.maxTotalExpansions ?? Infinity),
          maxExpandedLength: Math.max(1, value.maxExpandedLength ?? 1e5),
          maxEntityCount: Math.max(1, value.maxEntityCount ?? 1e3),
          allowedTags: value.allowedTags ?? null,
          tagFilter: value.tagFilter ?? null
        };
      }
      return normalizeProcessEntities(true);
    }
    var buildOptions = function(options) {
      const built = Object.assign({}, defaultOptions, options);
      const propertyNameOptions = [
        { value: built.attributeNamePrefix, name: "attributeNamePrefix" },
        { value: built.attributesGroupName, name: "attributesGroupName" },
        { value: built.textNodeName, name: "textNodeName" },
        { value: built.cdataPropName, name: "cdataPropName" },
        { value: built.commentPropName, name: "commentPropName" }
      ];
      for (const { value, name } of propertyNameOptions) {
        if (value) {
          validatePropertyName(value, name);
        }
      }
      if (built.onDangerousProperty === null) {
        built.onDangerousProperty = defaultOnDangerousProperty;
      }
      built.processEntities = normalizeProcessEntities(built.processEntities);
      return built;
    };
    exports.buildOptions = buildOptions;
    exports.defaultOptions = defaultOptions;
  }
});

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/xmlNode.js
var require_xmlNode = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/xmlNode.js"(exports, module) {
    "use strict";
    var XmlNode = class {
      constructor(tagname) {
        this.tagname = tagname;
        this.child = [];
        this[":@"] = {};
      }
      add(key, val) {
        if (key === "__proto__") key = "#__proto__";
        this.child.push({ [key]: val });
      }
      addChild(node) {
        if (node.tagname === "__proto__") node.tagname = "#__proto__";
        if (node[":@"] && Object.keys(node[":@"]).length > 0) {
          this.child.push({ [node.tagname]: node.child, [":@"]: node[":@"] });
        } else {
          this.child.push({ [node.tagname]: node.child });
        }
      }
    };
    module.exports = XmlNode;
  }
});

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/DocTypeReader.js
var require_DocTypeReader = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/DocTypeReader.js"(exports, module) {
    var util = require_util();
    var DocTypeReader = class {
      constructor(options) {
        this.suppressValidationErr = !options;
        this.options = options || {};
      }
      readDocType(xmlData, i) {
        const entities = /* @__PURE__ */ Object.create(null);
        let entityCount = 0;
        if (xmlData[i + 3] === "O" && xmlData[i + 4] === "C" && xmlData[i + 5] === "T" && xmlData[i + 6] === "Y" && xmlData[i + 7] === "P" && xmlData[i + 8] === "E") {
          i = i + 9;
          let angleBracketsCount = 1;
          let hasBody = false, comment = false;
          let exp = "";
          for (; i < xmlData.length; i++) {
            if (xmlData[i] === "<" && !comment) {
              if (hasBody && hasSeq(xmlData, "!ENTITY", i)) {
                i += 7;
                let entityName, val;
                [entityName, val, i] = this.readEntityExp(xmlData, i + 1, this.suppressValidationErr);
                if (val.indexOf("&") === -1) {
                  if (this.options.enabled !== false && this.options.maxEntityCount != null && entityCount >= this.options.maxEntityCount) {
                    throw new Error(
                      `Entity count (${entityCount + 1}) exceeds maximum allowed (${this.options.maxEntityCount})`
                    );
                  }
                  const escaped = entityName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
                  entities[entityName] = {
                    regx: RegExp(`&${escaped};`, "g"),
                    val
                  };
                  entityCount++;
                }
              } else if (hasBody && hasSeq(xmlData, "!ELEMENT", i)) {
                i += 8;
                const { index } = this.readElementExp(xmlData, i + 1);
                i = index;
              } else if (hasBody && hasSeq(xmlData, "!ATTLIST", i)) {
                i += 8;
              } else if (hasBody && hasSeq(xmlData, "!NOTATION", i)) {
                i += 9;
                const { index } = this.readNotationExp(xmlData, i + 1, this.suppressValidationErr);
                i = index;
              } else if (hasSeq(xmlData, "!--", i)) {
                comment = true;
              } else {
                throw new Error(`Invalid DOCTYPE`);
              }
              angleBracketsCount++;
              exp = "";
            } else if (xmlData[i] === ">") {
              if (comment) {
                if (xmlData[i - 1] === "-" && xmlData[i - 2] === "-") {
                  comment = false;
                  angleBracketsCount--;
                }
              } else {
                angleBracketsCount--;
              }
              if (angleBracketsCount === 0) {
                break;
              }
            } else if (xmlData[i] === "[") {
              hasBody = true;
            } else {
              exp += xmlData[i];
            }
          }
          if (angleBracketsCount !== 0) {
            throw new Error(`Unclosed DOCTYPE`);
          }
        } else {
          throw new Error(`Invalid Tag instead of DOCTYPE`);
        }
        return { entities, i };
      }
      readEntityExp(xmlData, i) {
        i = skipWhitespace(xmlData, i);
        let entityName = "";
        while (i < xmlData.length && !/\s/.test(xmlData[i]) && xmlData[i] !== '"' && xmlData[i] !== "'") {
          entityName += xmlData[i];
          i++;
        }
        validateEntityName(entityName);
        i = skipWhitespace(xmlData, i);
        if (!this.suppressValidationErr) {
          if (xmlData.substring(i, i + 6).toUpperCase() === "SYSTEM") {
            throw new Error("External entities are not supported");
          } else if (xmlData[i] === "%") {
            throw new Error("Parameter entities are not supported");
          }
        }
        let entityValue = "";
        [i, entityValue] = this.readIdentifierVal(xmlData, i, "entity");
        if (this.options.enabled !== false && this.options.maxEntitySize != null && entityValue.length > this.options.maxEntitySize) {
          throw new Error(
            `Entity "${entityName}" size (${entityValue.length}) exceeds maximum allowed size (${this.options.maxEntitySize})`
          );
        }
        i--;
        return [entityName, entityValue, i];
      }
      readNotationExp(xmlData, i) {
        i = skipWhitespace(xmlData, i);
        let notationName = "";
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
          notationName += xmlData[i];
          i++;
        }
        !this.suppressValidationErr && validateEntityName(notationName);
        i = skipWhitespace(xmlData, i);
        const identifierType = xmlData.substring(i, i + 6).toUpperCase();
        if (!this.suppressValidationErr && identifierType !== "SYSTEM" && identifierType !== "PUBLIC") {
          throw new Error(`Expected SYSTEM or PUBLIC, found "${identifierType}"`);
        }
        i += identifierType.length;
        i = skipWhitespace(xmlData, i);
        let publicIdentifier = null;
        let systemIdentifier = null;
        if (identifierType === "PUBLIC") {
          [i, publicIdentifier] = this.readIdentifierVal(xmlData, i, "publicIdentifier");
          i = skipWhitespace(xmlData, i);
          if (xmlData[i] === '"' || xmlData[i] === "'") {
            [i, systemIdentifier] = this.readIdentifierVal(xmlData, i, "systemIdentifier");
          }
        } else if (identifierType === "SYSTEM") {
          [i, systemIdentifier] = this.readIdentifierVal(xmlData, i, "systemIdentifier");
          if (!this.suppressValidationErr && !systemIdentifier) {
            throw new Error("Missing mandatory system identifier for SYSTEM notation");
          }
        }
        return { notationName, publicIdentifier, systemIdentifier, index: --i };
      }
      readIdentifierVal(xmlData, i, type) {
        let identifierVal = "";
        const startChar = xmlData[i];
        if (startChar !== '"' && startChar !== "'") {
          throw new Error(`Expected quoted string, found "${startChar}"`);
        }
        i++;
        while (i < xmlData.length && xmlData[i] !== startChar) {
          identifierVal += xmlData[i];
          i++;
        }
        if (xmlData[i] !== startChar) {
          throw new Error(`Unterminated ${type} value`);
        }
        i++;
        return [i, identifierVal];
      }
      readElementExp(xmlData, i) {
        i = skipWhitespace(xmlData, i);
        let elementName = "";
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
          elementName += xmlData[i];
          i++;
        }
        if (!this.suppressValidationErr && !util.isName(elementName)) {
          throw new Error(`Invalid element name: "${elementName}"`);
        }
        i = skipWhitespace(xmlData, i);
        let contentModel = "";
        if (xmlData[i] === "E" && hasSeq(xmlData, "MPTY", i)) {
          i += 4;
        } else if (xmlData[i] === "A" && hasSeq(xmlData, "NY", i)) {
          i += 2;
        } else if (xmlData[i] === "(") {
          i++;
          while (i < xmlData.length && xmlData[i] !== ")") {
            contentModel += xmlData[i];
            i++;
          }
          if (xmlData[i] !== ")") {
            throw new Error("Unterminated content model");
          }
        } else if (!this.suppressValidationErr) {
          throw new Error(`Invalid Element Expression, found "${xmlData[i]}"`);
        }
        return {
          elementName,
          contentModel: contentModel.trim(),
          index: i
        };
      }
      readAttlistExp(xmlData, i) {
        i = skipWhitespace(xmlData, i);
        let elementName = "";
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
          elementName += xmlData[i];
          i++;
        }
        validateEntityName(elementName);
        i = skipWhitespace(xmlData, i);
        let attributeName = "";
        while (i < xmlData.length && !/\s/.test(xmlData[i])) {
          attributeName += xmlData[i];
          i++;
        }
        if (!validateEntityName(attributeName)) {
          throw new Error(`Invalid attribute name: "${attributeName}"`);
        }
        i = skipWhitespace(xmlData, i);
        let attributeType = "";
        if (xmlData.substring(i, i + 8).toUpperCase() === "NOTATION") {
          attributeType = "NOTATION";
          i += 8;
          i = skipWhitespace(xmlData, i);
          if (xmlData[i] !== "(") {
            throw new Error(`Expected '(', found "${xmlData[i]}"`);
          }
          i++;
          let allowedNotations = [];
          while (i < xmlData.length && xmlData[i] !== ")") {
            let notation = "";
            while (i < xmlData.length && xmlData[i] !== "|" && xmlData[i] !== ")") {
              notation += xmlData[i];
              i++;
            }
            notation = notation.trim();
            if (!validateEntityName(notation)) {
              throw new Error(`Invalid notation name: "${notation}"`);
            }
            allowedNotations.push(notation);
            if (xmlData[i] === "|") {
              i++;
              i = skipWhitespace(xmlData, i);
            }
          }
          if (xmlData[i] !== ")") {
            throw new Error("Unterminated list of notations");
          }
          i++;
          attributeType += " (" + allowedNotations.join("|") + ")";
        } else {
          while (i < xmlData.length && !/\s/.test(xmlData[i])) {
            attributeType += xmlData[i];
            i++;
          }
          const validTypes = ["CDATA", "ID", "IDREF", "IDREFS", "ENTITY", "ENTITIES", "NMTOKEN", "NMTOKENS"];
          if (!this.suppressValidationErr && !validTypes.includes(attributeType.toUpperCase())) {
            throw new Error(`Invalid attribute type: "${attributeType}"`);
          }
        }
        i = skipWhitespace(xmlData, i);
        let defaultValue = "";
        if (xmlData.substring(i, i + 8).toUpperCase() === "#REQUIRED") {
          defaultValue = "#REQUIRED";
          i += 8;
        } else if (xmlData.substring(i, i + 7).toUpperCase() === "#IMPLIED") {
          defaultValue = "#IMPLIED";
          i += 7;
        } else {
          [i, defaultValue] = this.readIdentifierVal(xmlData, i, "ATTLIST");
        }
        return {
          elementName,
          attributeName,
          attributeType,
          defaultValue,
          index: i
        };
      }
    };
    var skipWhitespace = (data, index) => {
      while (index < data.length && /\s/.test(data[index])) {
        index++;
      }
      return index;
    };
    function hasSeq(data, seq, i) {
      for (let j = 0; j < seq.length; j++) {
        if (seq[j] !== data[i + j + 1]) return false;
      }
      return true;
    }
    function validateEntityName(name) {
      if (util.isName(name))
        return name;
      else
        throw new Error(`Invalid entity name ${name}`);
    }
    module.exports = DocTypeReader;
  }
});

// ../../node_modules/.pnpm/strnum@1.1.2/node_modules/strnum/strnum.js
var require_strnum = __commonJS({
  "../../node_modules/.pnpm/strnum@1.1.2/node_modules/strnum/strnum.js"(exports, module) {
    var hexRegex = /^[-+]?0x[a-fA-F0-9]+$/;
    var numRegex = /^([\-\+])?(0*)([0-9]*(\.[0-9]*)?)$/;
    var consider = {
      hex: true,
      // oct: false,
      leadingZeros: true,
      decimalPoint: ".",
      eNotation: true
      //skipLike: /regex/
    };
    function toNumber(str, options = {}) {
      options = Object.assign({}, consider, options);
      if (!str || typeof str !== "string") return str;
      let trimmedStr = str.trim();
      if (options.skipLike !== void 0 && options.skipLike.test(trimmedStr)) return str;
      else if (str === "0") return 0;
      else if (options.hex && hexRegex.test(trimmedStr)) {
        return parse_int(trimmedStr, 16);
      } else if (trimmedStr.search(/[eE]/) !== -1) {
        const notation = trimmedStr.match(/^([-\+])?(0*)([0-9]*(\.[0-9]*)?[eE][-\+]?[0-9]+)$/);
        if (notation) {
          if (options.leadingZeros) {
            trimmedStr = (notation[1] || "") + notation[3];
          } else {
            if (notation[2] === "0" && notation[3][0] === ".") {
            } else {
              return str;
            }
          }
          return options.eNotation ? Number(trimmedStr) : str;
        } else {
          return str;
        }
      } else {
        const match = numRegex.exec(trimmedStr);
        if (match) {
          const sign = match[1];
          const leadingZeros = match[2];
          let numTrimmedByZeros = trimZeros(match[3]);
          if (!options.leadingZeros && leadingZeros.length > 0 && sign && trimmedStr[2] !== ".") return str;
          else if (!options.leadingZeros && leadingZeros.length > 0 && !sign && trimmedStr[1] !== ".") return str;
          else if (options.leadingZeros && leadingZeros === str) return 0;
          else {
            const num = Number(trimmedStr);
            const numStr = "" + num;
            if (numStr.search(/[eE]/) !== -1) {
              if (options.eNotation) return num;
              else return str;
            } else if (trimmedStr.indexOf(".") !== -1) {
              if (numStr === "0" && numTrimmedByZeros === "") return num;
              else if (numStr === numTrimmedByZeros) return num;
              else if (sign && numStr === "-" + numTrimmedByZeros) return num;
              else return str;
            }
            if (leadingZeros) {
              return numTrimmedByZeros === numStr || sign + numTrimmedByZeros === numStr ? num : str;
            } else {
              return trimmedStr === numStr || trimmedStr === sign + numStr ? num : str;
            }
          }
        } else {
          return str;
        }
      }
    }
    function trimZeros(numStr) {
      if (numStr && numStr.indexOf(".") !== -1) {
        numStr = numStr.replace(/0+$/, "");
        if (numStr === ".") numStr = "0";
        else if (numStr[0] === ".") numStr = "0" + numStr;
        else if (numStr[numStr.length - 1] === ".") numStr = numStr.substr(0, numStr.length - 1);
        return numStr;
      }
      return numStr;
    }
    function parse_int(numStr, base) {
      if (parseInt) return parseInt(numStr, base);
      else if (Number.parseInt) return Number.parseInt(numStr, base);
      else if (window && window.parseInt) return window.parseInt(numStr, base);
      else throw new Error("parseInt, Number.parseInt, window.parseInt are not supported");
    }
    module.exports = toNumber;
  }
});

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/ignoreAttributes.js
var require_ignoreAttributes = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/ignoreAttributes.js"(exports, module) {
    function getIgnoreAttributesFn(ignoreAttributes) {
      if (typeof ignoreAttributes === "function") {
        return ignoreAttributes;
      }
      if (Array.isArray(ignoreAttributes)) {
        return (attrName) => {
          for (const pattern of ignoreAttributes) {
            if (typeof pattern === "string" && attrName === pattern) {
              return true;
            }
            if (pattern instanceof RegExp && pattern.test(attrName)) {
              return true;
            }
          }
        };
      }
      return () => false;
    }
    module.exports = getIgnoreAttributesFn;
  }
});

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/OrderedObjParser.js
var require_OrderedObjParser = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/OrderedObjParser.js"(exports, module) {
    "use strict";
    var util = require_util();
    var xmlNode = require_xmlNode();
    var DocTypeReader = require_DocTypeReader();
    var toNumber = require_strnum();
    var getIgnoreAttributesFn = require_ignoreAttributes();
    var OrderedObjParser = class {
      constructor(options) {
        this.options = options;
        this.currentNode = null;
        this.tagsNodeStack = [];
        this.docTypeEntities = {};
        this.lastEntities = {
          "apos": { regex: /&(apos|#39|#x27);/g, val: "'" },
          "gt": { regex: /&(gt|#62|#x3E);/g, val: ">" },
          "lt": { regex: /&(lt|#60|#x3C);/g, val: "<" },
          "quot": { regex: /&(quot|#34|#x22);/g, val: '"' }
        };
        this.ampEntity = { regex: /&(amp|#38|#x26);/g, val: "&" };
        this.htmlEntities = {
          "space": { regex: /&(nbsp|#160);/g, val: " " },
          // "lt" : { regex: /&(lt|#60);/g, val: "<" },
          // "gt" : { regex: /&(gt|#62);/g, val: ">" },
          // "amp" : { regex: /&(amp|#38);/g, val: "&" },
          // "quot" : { regex: /&(quot|#34);/g, val: "\"" },
          // "apos" : { regex: /&(apos|#39);/g, val: "'" },
          "cent": { regex: /&(cent|#162);/g, val: "\xA2" },
          "pound": { regex: /&(pound|#163);/g, val: "\xA3" },
          "yen": { regex: /&(yen|#165);/g, val: "\xA5" },
          "euro": { regex: /&(euro|#8364);/g, val: "\u20AC" },
          "copyright": { regex: /&(copy|#169);/g, val: "\xA9" },
          "reg": { regex: /&(reg|#174);/g, val: "\xAE" },
          "inr": { regex: /&(inr|#8377);/g, val: "\u20B9" },
          "num_dec": { regex: /&#([0-9]{1,7});/g, val: (_, str) => fromCodePoint(str, 10, "&#") },
          "num_hex": { regex: /&#x([0-9a-fA-F]{1,6});/g, val: (_, str) => fromCodePoint(str, 16, "&#x") }
        };
        this.addExternalEntities = addExternalEntities;
        this.parseXml = parseXml;
        this.parseTextData = parseTextData;
        this.resolveNameSpace = resolveNameSpace;
        this.buildAttributesMap = buildAttributesMap;
        this.isItStopNode = isItStopNode;
        this.replaceEntitiesValue = replaceEntitiesValue;
        this.readStopNodeData = readStopNodeData;
        this.saveTextToParentTag = saveTextToParentTag;
        this.addChild = addChild;
        this.ignoreAttributesFn = getIgnoreAttributesFn(this.options.ignoreAttributes);
        this.entityExpansionCount = 0;
        this.currentExpandedLength = 0;
        if (this.options.stopNodes && this.options.stopNodes.length > 0) {
          this.stopNodesExact = /* @__PURE__ */ new Set();
          this.stopNodesWildcard = /* @__PURE__ */ new Set();
          for (let i = 0; i < this.options.stopNodes.length; i++) {
            const stopNodeExp = this.options.stopNodes[i];
            if (typeof stopNodeExp !== "string") continue;
            if (stopNodeExp.startsWith("*.")) {
              this.stopNodesWildcard.add(stopNodeExp.substring(2));
            } else {
              this.stopNodesExact.add(stopNodeExp);
            }
          }
        }
      }
    };
    function addExternalEntities(externalEntities) {
      const entKeys = Object.keys(externalEntities);
      for (let i = 0; i < entKeys.length; i++) {
        const ent = entKeys[i];
        const escaped = ent.replace(/[.\-+*:]/g, "\\.");
        this.lastEntities[ent] = {
          regex: new RegExp("&" + escaped + ";", "g"),
          val: externalEntities[ent]
        };
      }
    }
    function parseTextData(val, tagName, jPath, dontTrim, hasAttributes, isLeafNode, escapeEntities) {
      if (val !== void 0) {
        if (this.options.trimValues && !dontTrim) {
          val = val.trim();
        }
        if (val.length > 0) {
          if (!escapeEntities) val = this.replaceEntitiesValue(val, tagName, jPath);
          const newval = this.options.tagValueProcessor(tagName, val, jPath, hasAttributes, isLeafNode);
          if (newval === null || newval === void 0) {
            return val;
          } else if (typeof newval !== typeof val || newval !== val) {
            return newval;
          } else if (this.options.trimValues) {
            return parseValue(val, this.options.parseTagValue, this.options.numberParseOptions);
          } else {
            const trimmedVal = val.trim();
            if (trimmedVal === val) {
              return parseValue(val, this.options.parseTagValue, this.options.numberParseOptions);
            } else {
              return val;
            }
          }
        }
      }
    }
    function resolveNameSpace(tagname) {
      if (this.options.removeNSPrefix) {
        const tags = tagname.split(":");
        const prefix = tagname.charAt(0) === "/" ? "/" : "";
        if (tags[0] === "xmlns") {
          return "";
        }
        if (tags.length === 2) {
          tagname = prefix + tags[1];
        }
      }
      return tagname;
    }
    var attrsRegx = new RegExp(`([^\\s=]+)\\s*(=\\s*(['"])([\\s\\S]*?)\\3)?`, "gm");
    function buildAttributesMap(attrStr, jPath, tagName) {
      if (this.options.ignoreAttributes !== true && typeof attrStr === "string") {
        const matches = util.getAllMatches(attrStr, attrsRegx);
        const len = matches.length;
        const attrs = {};
        for (let i = 0; i < len; i++) {
          const attrName = this.resolveNameSpace(matches[i][1]);
          if (this.ignoreAttributesFn(attrName, jPath)) {
            continue;
          }
          let oldVal = matches[i][4];
          let aName = this.options.attributeNamePrefix + attrName;
          if (attrName.length) {
            if (this.options.transformAttributeName) {
              aName = this.options.transformAttributeName(aName);
            }
            aName = sanitizeName(aName, this.options);
            if (oldVal !== void 0) {
              if (this.options.trimValues) {
                oldVal = oldVal.trim();
              }
              oldVal = this.replaceEntitiesValue(oldVal, tagName, jPath);
              const newVal = this.options.attributeValueProcessor(attrName, oldVal, jPath);
              if (newVal === null || newVal === void 0) {
                attrs[aName] = oldVal;
              } else if (typeof newVal !== typeof oldVal || newVal !== oldVal) {
                attrs[aName] = newVal;
              } else {
                attrs[aName] = parseValue(
                  oldVal,
                  this.options.parseAttributeValue,
                  this.options.numberParseOptions
                );
              }
            } else if (this.options.allowBooleanAttributes) {
              attrs[aName] = true;
            }
          }
        }
        if (!Object.keys(attrs).length) {
          return;
        }
        if (this.options.attributesGroupName) {
          const attrCollection = {};
          attrCollection[this.options.attributesGroupName] = attrs;
          return attrCollection;
        }
        return attrs;
      }
    }
    var parseXml = function(xmlData) {
      xmlData = xmlData.replace(/\r\n?/g, "\n");
      const xmlObj = new xmlNode("!xml");
      let currentNode = xmlObj;
      let textData = "";
      let jPath = "";
      this.entityExpansionCount = 0;
      this.currentExpandedLength = 0;
      const docTypeReader = new DocTypeReader(this.options.processEntities);
      for (let i = 0; i < xmlData.length; i++) {
        const ch = xmlData[i];
        if (ch === "<") {
          if (xmlData[i + 1] === "/") {
            const closeIndex = findClosingIndex(xmlData, ">", i, "Closing Tag is not closed.");
            let tagName = xmlData.substring(i + 2, closeIndex).trim();
            if (this.options.removeNSPrefix) {
              const colonIndex = tagName.indexOf(":");
              if (colonIndex !== -1) {
                tagName = tagName.substr(colonIndex + 1);
              }
            }
            if (this.options.transformTagName) {
              tagName = this.options.transformTagName(tagName);
            }
            if (currentNode) {
              textData = this.saveTextToParentTag(textData, currentNode, jPath);
            }
            const lastTagName = jPath.substring(jPath.lastIndexOf(".") + 1);
            if (tagName && this.options.unpairedTags.indexOf(tagName) !== -1) {
              throw new Error(`Unpaired tag can not be used as closing tag: </${tagName}>`);
            }
            let propIndex = 0;
            if (lastTagName && this.options.unpairedTags.indexOf(lastTagName) !== -1) {
              propIndex = jPath.lastIndexOf(".", jPath.lastIndexOf(".") - 1);
              this.tagsNodeStack.pop();
            } else {
              propIndex = jPath.lastIndexOf(".");
            }
            jPath = jPath.substring(0, propIndex);
            currentNode = this.tagsNodeStack.pop();
            textData = "";
            i = closeIndex;
          } else if (xmlData[i + 1] === "?") {
            let tagData = readTagExp(xmlData, i, false, "?>");
            if (!tagData) throw new Error("Pi Tag is not closed.");
            textData = this.saveTextToParentTag(textData, currentNode, jPath);
            if (this.options.ignoreDeclaration && tagData.tagName === "?xml" || this.options.ignorePiTags) {
            } else {
              const childNode = new xmlNode(tagData.tagName);
              childNode.add(this.options.textNodeName, "");
              if (tagData.tagName !== tagData.tagExp && tagData.attrExpPresent) {
                childNode[":@"] = this.buildAttributesMap(tagData.tagExp, jPath, tagData.tagName);
              }
              this.addChild(currentNode, childNode, jPath, i);
            }
            i = tagData.closeIndex + 1;
          } else if (xmlData.substr(i + 1, 3) === "!--") {
            const endIndex = findClosingIndex(xmlData, "-->", i + 4, "Comment is not closed.");
            if (this.options.commentPropName) {
              const comment = xmlData.substring(i + 4, endIndex - 2);
              textData = this.saveTextToParentTag(textData, currentNode, jPath);
              currentNode.add(this.options.commentPropName, [{ [this.options.textNodeName]: comment }]);
            }
            i = endIndex;
          } else if (xmlData.substr(i + 1, 2) === "!D") {
            const result = docTypeReader.readDocType(xmlData, i);
            this.docTypeEntities = result.entities;
            i = result.i;
          } else if (xmlData.substr(i + 1, 2) === "![") {
            const closeIndex = findClosingIndex(xmlData, "]]>", i, "CDATA is not closed.") - 2;
            const tagExp = xmlData.substring(i + 9, closeIndex);
            textData = this.saveTextToParentTag(textData, currentNode, jPath);
            let val = this.parseTextData(tagExp, currentNode.tagname, jPath, true, false, true, true);
            if (val == void 0) val = "";
            if (this.options.cdataPropName) {
              currentNode.add(this.options.cdataPropName, [{ [this.options.textNodeName]: tagExp }]);
            } else {
              currentNode.add(this.options.textNodeName, val);
            }
            i = closeIndex + 2;
          } else {
            let result = readTagExp(xmlData, i, this.options.removeNSPrefix);
            let tagName = result.tagName;
            const rawTagName = result.rawTagName;
            let tagExp = result.tagExp;
            let attrExpPresent = result.attrExpPresent;
            let closeIndex = result.closeIndex;
            if (this.options.transformTagName) {
              const newTagName = this.options.transformTagName(tagName);
              if (tagExp === tagName) {
                tagExp = newTagName;
              }
              tagName = newTagName;
            }
            if (this.options.strictReservedNames && (tagName === this.options.commentPropName || tagName === this.options.cdataPropName || tagName === this.options.textNodeName || tagName === this.options.attributesGroupName)) {
              throw new Error(`Invalid tag name: ${tagName}`);
            }
            if (currentNode && textData) {
              if (currentNode.tagname !== "!xml") {
                textData = this.saveTextToParentTag(textData, currentNode, jPath, false);
              }
            }
            const lastTag = currentNode;
            if (lastTag && this.options.unpairedTags.indexOf(lastTag.tagname) !== -1) {
              currentNode = this.tagsNodeStack.pop();
              jPath = jPath.substring(0, jPath.lastIndexOf("."));
            }
            if (tagName !== xmlObj.tagname) {
              jPath += jPath ? "." + tagName : tagName;
            }
            const startIndex = i;
            if (this.isItStopNode(this.stopNodesExact, this.stopNodesWildcard, jPath, tagName)) {
              let tagContent = "";
              if (tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1) {
                if (tagName[tagName.length - 1] === "/") {
                  tagName = tagName.substr(0, tagName.length - 1);
                  jPath = jPath.substr(0, jPath.length - 1);
                  tagExp = tagName;
                } else {
                  tagExp = tagExp.substr(0, tagExp.length - 1);
                }
                i = result.closeIndex;
              } else if (this.options.unpairedTags.indexOf(tagName) !== -1) {
                i = result.closeIndex;
              } else {
                const result2 = this.readStopNodeData(xmlData, rawTagName, closeIndex + 1);
                if (!result2) throw new Error(`Unexpected end of ${rawTagName}`);
                i = result2.i;
                tagContent = result2.tagContent;
              }
              const childNode = new xmlNode(tagName);
              if (tagName !== tagExp && attrExpPresent) {
                childNode[":@"] = this.buildAttributesMap(tagExp, jPath, tagName);
              }
              if (tagContent) {
                tagContent = this.parseTextData(tagContent, tagName, jPath, true, attrExpPresent, true, true);
              }
              jPath = jPath.substr(0, jPath.lastIndexOf("."));
              childNode.add(this.options.textNodeName, tagContent);
              this.addChild(currentNode, childNode, jPath, startIndex);
            } else {
              if (tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1) {
                if (tagName[tagName.length - 1] === "/") {
                  tagName = tagName.substr(0, tagName.length - 1);
                  jPath = jPath.substr(0, jPath.length - 1);
                  tagExp = tagName;
                } else {
                  tagExp = tagExp.substr(0, tagExp.length - 1);
                }
                if (this.options.transformTagName) {
                  const newTagName = this.options.transformTagName(tagName);
                  if (tagExp === tagName) {
                    tagExp = newTagName;
                  }
                  tagName = newTagName;
                }
                const childNode = new xmlNode(tagName);
                if (tagName !== tagExp && attrExpPresent) {
                  childNode[":@"] = this.buildAttributesMap(tagExp, jPath, tagName);
                }
                this.addChild(currentNode, childNode, jPath, startIndex);
                jPath = jPath.substr(0, jPath.lastIndexOf("."));
              } else if (this.options.unpairedTags.indexOf(tagName) !== -1) {
                const childNode = new xmlNode(tagName);
                if (tagName !== tagExp && attrExpPresent) {
                  childNode[":@"] = this.buildAttributesMap(tagExp, jPath);
                }
                this.addChild(currentNode, childNode, jPath, startIndex);
                jPath = jPath.substr(0, jPath.lastIndexOf("."));
                i = result.closeIndex;
                continue;
              } else {
                const childNode = new xmlNode(tagName);
                if (this.tagsNodeStack.length > this.options.maxNestedTags) {
                  throw new Error("Maximum nested tags exceeded");
                }
                this.tagsNodeStack.push(currentNode);
                if (tagName !== tagExp && attrExpPresent) {
                  childNode[":@"] = this.buildAttributesMap(tagExp, jPath, tagName);
                }
                this.addChild(currentNode, childNode, jPath);
                currentNode = childNode;
              }
              textData = "";
              i = closeIndex;
            }
          }
        } else {
          textData += xmlData[i];
        }
      }
      return xmlObj.child;
    };
    function addChild(currentNode, childNode, jPath, startIndex) {
      if (!this.options.captureMetaData) startIndex = void 0;
      const result = this.options.updateTag(childNode.tagname, jPath, childNode[":@"]);
      if (result === false) {
      } else if (typeof result === "string") {
        childNode.tagname = result;
        currentNode.addChild(childNode, startIndex);
      } else {
        currentNode.addChild(childNode, startIndex);
      }
    }
    var replaceEntitiesValue = function(val, tagName, jPath) {
      if (val.indexOf("&") === -1) {
        return val;
      }
      const entityConfig = this.options.processEntities;
      if (!entityConfig.enabled) {
        return val;
      }
      if (entityConfig.allowedTags) {
        if (!entityConfig.allowedTags.includes(tagName)) {
          return val;
        }
      }
      if (entityConfig.tagFilter) {
        if (!entityConfig.tagFilter(tagName, jPath)) {
          return val;
        }
      }
      for (let entityName in this.docTypeEntities) {
        const entity = this.docTypeEntities[entityName];
        const matches = val.match(entity.regx);
        if (matches) {
          this.entityExpansionCount += matches.length;
          if (entityConfig.maxTotalExpansions && this.entityExpansionCount > entityConfig.maxTotalExpansions) {
            throw new Error(
              `Entity expansion limit exceeded: ${this.entityExpansionCount} > ${entityConfig.maxTotalExpansions}`
            );
          }
          const lengthBefore = val.length;
          val = val.replace(entity.regx, entity.val);
          if (entityConfig.maxExpandedLength) {
            this.currentExpandedLength += val.length - lengthBefore;
            if (this.currentExpandedLength > entityConfig.maxExpandedLength) {
              throw new Error(
                `Total expanded content size exceeded: ${this.currentExpandedLength} > ${entityConfig.maxExpandedLength}`
              );
            }
          }
        }
      }
      if (val.indexOf("&") === -1) return val;
      for (const entityName of Object.keys(this.lastEntities)) {
        const entity = this.lastEntities[entityName];
        const matches = val.match(entity.regex);
        if (matches) {
          this.entityExpansionCount += matches.length;
          if (entityConfig.maxTotalExpansions && this.entityExpansionCount > entityConfig.maxTotalExpansions) {
            throw new Error(
              `Entity expansion limit exceeded: ${this.entityExpansionCount} > ${entityConfig.maxTotalExpansions}`
            );
          }
        }
        val = val.replace(entity.regex, entity.val);
      }
      if (val.indexOf("&") === -1) return val;
      if (this.options.htmlEntities) {
        for (const entityName of Object.keys(this.htmlEntities)) {
          const entity = this.htmlEntities[entityName];
          const matches = val.match(entity.regex);
          if (matches) {
            this.entityExpansionCount += matches.length;
            if (entityConfig.maxTotalExpansions && this.entityExpansionCount > entityConfig.maxTotalExpansions) {
              throw new Error(
                `Entity expansion limit exceeded: ${this.entityExpansionCount} > ${entityConfig.maxTotalExpansions}`
              );
            }
          }
          val = val.replace(entity.regex, entity.val);
        }
      }
      val = val.replace(this.ampEntity.regex, this.ampEntity.val);
      return val;
    };
    function saveTextToParentTag(textData, parentNode, jPath, isLeafNode) {
      if (textData) {
        if (isLeafNode === void 0) isLeafNode = parentNode.child.length === 0;
        textData = this.parseTextData(
          textData,
          parentNode.tagname,
          jPath,
          false,
          parentNode[":@"] ? Object.keys(parentNode[":@"]).length !== 0 : false,
          isLeafNode
        );
        if (textData !== void 0 && textData !== "")
          parentNode.add(this.options.textNodeName, textData);
        textData = "";
      }
      return textData;
    }
    function isItStopNode(stopNodesExact, stopNodesWildcard, jPath, currentTagName) {
      if (stopNodesWildcard && stopNodesWildcard.has(currentTagName)) return true;
      if (stopNodesExact && stopNodesExact.has(jPath)) return true;
      return false;
    }
    function tagExpWithClosingIndex(xmlData, i, closingChar = ">") {
      let attrBoundary;
      let tagExp = "";
      for (let index = i; index < xmlData.length; index++) {
        let ch = xmlData[index];
        if (attrBoundary) {
          if (ch === attrBoundary) attrBoundary = "";
        } else if (ch === '"' || ch === "'") {
          attrBoundary = ch;
        } else if (ch === closingChar[0]) {
          if (closingChar[1]) {
            if (xmlData[index + 1] === closingChar[1]) {
              return {
                data: tagExp,
                index
              };
            }
          } else {
            return {
              data: tagExp,
              index
            };
          }
        } else if (ch === "	") {
          ch = " ";
        }
        tagExp += ch;
      }
    }
    function findClosingIndex(xmlData, str, i, errMsg) {
      const closingIndex = xmlData.indexOf(str, i);
      if (closingIndex === -1) {
        throw new Error(errMsg);
      } else {
        return closingIndex + str.length - 1;
      }
    }
    function readTagExp(xmlData, i, removeNSPrefix, closingChar = ">") {
      const result = tagExpWithClosingIndex(xmlData, i + 1, closingChar);
      if (!result) return;
      let tagExp = result.data;
      const closeIndex = result.index;
      const separatorIndex = tagExp.search(/\s/);
      let tagName = tagExp;
      let attrExpPresent = true;
      if (separatorIndex !== -1) {
        tagName = tagExp.substring(0, separatorIndex);
        tagExp = tagExp.substring(separatorIndex + 1).trimStart();
      }
      const rawTagName = tagName;
      if (removeNSPrefix) {
        const colonIndex = tagName.indexOf(":");
        if (colonIndex !== -1) {
          tagName = tagName.substr(colonIndex + 1);
          attrExpPresent = tagName !== result.data.substr(colonIndex + 1);
        }
      }
      return {
        tagName,
        tagExp,
        closeIndex,
        attrExpPresent,
        rawTagName
      };
    }
    function readStopNodeData(xmlData, tagName, i) {
      const startIndex = i;
      let openTagCount = 1;
      for (; i < xmlData.length; i++) {
        if (xmlData[i] === "<") {
          if (xmlData[i + 1] === "/") {
            const closeIndex = findClosingIndex(xmlData, ">", i, `${tagName} is not closed`);
            let closeTagName = xmlData.substring(i + 2, closeIndex).trim();
            if (closeTagName === tagName) {
              openTagCount--;
              if (openTagCount === 0) {
                return {
                  tagContent: xmlData.substring(startIndex, i),
                  i: closeIndex
                };
              }
            }
            i = closeIndex;
          } else if (xmlData[i + 1] === "?") {
            const closeIndex = findClosingIndex(xmlData, "?>", i + 1, "StopNode is not closed.");
            i = closeIndex;
          } else if (xmlData.substr(i + 1, 3) === "!--") {
            const closeIndex = findClosingIndex(xmlData, "-->", i + 3, "StopNode is not closed.");
            i = closeIndex;
          } else if (xmlData.substr(i + 1, 2) === "![") {
            const closeIndex = findClosingIndex(xmlData, "]]>", i, "StopNode is not closed.") - 2;
            i = closeIndex;
          } else {
            const tagData = readTagExp(xmlData, i, ">");
            if (tagData) {
              const openTagName = tagData && tagData.tagName;
              if (openTagName === tagName && tagData.tagExp[tagData.tagExp.length - 1] !== "/") {
                openTagCount++;
              }
              i = tagData.closeIndex;
            }
          }
        }
      }
    }
    function parseValue(val, shouldParse, options) {
      if (shouldParse && typeof val === "string") {
        const newval = val.trim();
        if (newval === "true") return true;
        else if (newval === "false") return false;
        else return toNumber(val, options);
      } else {
        if (util.isExist(val)) {
          return val;
        } else {
          return "";
        }
      }
    }
    function fromCodePoint(str, base, prefix) {
      const codePoint = Number.parseInt(str, base);
      if (codePoint >= 0 && codePoint <= 1114111) {
        return String.fromCodePoint(codePoint);
      } else {
        return prefix + str + ";";
      }
    }
    function sanitizeName(name, options) {
      if (util.criticalProperties.includes(name)) {
        throw new Error(`[SECURITY] Invalid name: "${name}" is a reserved JavaScript keyword that could cause prototype pollution`);
      } else if (util.DANGEROUS_PROPERTY_NAMES.includes(name)) {
        return options.onDangerousProperty(name);
      }
      return name;
    }
    module.exports = OrderedObjParser;
  }
});

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/node2json.js
var require_node2json = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/node2json.js"(exports) {
    "use strict";
    function prettify(node, options) {
      return compress(node, options);
    }
    function compress(arr, options, jPath) {
      let text;
      const compressedObj = {};
      for (let i = 0; i < arr.length; i++) {
        const tagObj = arr[i];
        const property = propName(tagObj);
        let newJpath = "";
        if (jPath === void 0) newJpath = property;
        else newJpath = jPath + "." + property;
        if (property === options.textNodeName) {
          if (text === void 0) text = tagObj[property];
          else text += "" + tagObj[property];
        } else if (property === void 0) {
          continue;
        } else if (tagObj[property]) {
          let val = compress(tagObj[property], options, newJpath);
          const isLeaf = isLeafTag(val, options);
          if (tagObj[":@"]) {
            assignAttributes(val, tagObj[":@"], newJpath, options);
          } else if (Object.keys(val).length === 1 && val[options.textNodeName] !== void 0 && !options.alwaysCreateTextNode) {
            val = val[options.textNodeName];
          } else if (Object.keys(val).length === 0) {
            if (options.alwaysCreateTextNode) val[options.textNodeName] = "";
            else val = "";
          }
          if (compressedObj[property] !== void 0 && compressedObj.hasOwnProperty(property)) {
            if (!Array.isArray(compressedObj[property])) {
              compressedObj[property] = [compressedObj[property]];
            }
            compressedObj[property].push(val);
          } else {
            if (options.isArray(property, newJpath, isLeaf)) {
              compressedObj[property] = [val];
            } else {
              compressedObj[property] = val;
            }
          }
        }
      }
      if (typeof text === "string") {
        if (text.length > 0) compressedObj[options.textNodeName] = text;
      } else if (text !== void 0) compressedObj[options.textNodeName] = text;
      return compressedObj;
    }
    function propName(obj) {
      const keys = Object.keys(obj);
      for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        if (key !== ":@") return key;
      }
    }
    function assignAttributes(obj, attrMap, jpath, options) {
      if (attrMap) {
        const keys = Object.keys(attrMap);
        const len = keys.length;
        for (let i = 0; i < len; i++) {
          const atrrName = keys[i];
          if (options.isArray(atrrName, jpath + "." + atrrName, true, true)) {
            obj[atrrName] = [attrMap[atrrName]];
          } else {
            obj[atrrName] = attrMap[atrrName];
          }
        }
      }
    }
    function isLeafTag(obj, options) {
      const { textNodeName } = options;
      const propCount = Object.keys(obj).length;
      if (propCount === 0) {
        return true;
      }
      if (propCount === 1 && (obj[textNodeName] || typeof obj[textNodeName] === "boolean" || obj[textNodeName] === 0)) {
        return true;
      }
      return false;
    }
    exports.prettify = prettify;
  }
});

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/XMLParser.js
var require_XMLParser = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlparser/XMLParser.js"(exports, module) {
    var { buildOptions } = require_OptionsBuilder();
    var OrderedObjParser = require_OrderedObjParser();
    var { prettify } = require_node2json();
    var validator = require_validator();
    var XMLParser2 = class {
      constructor(options) {
        this.externalEntities = {};
        this.options = buildOptions(options);
      }
      /**
       * Parse XML dats to JS object 
       * @param {string|Buffer} xmlData 
       * @param {boolean|Object} validationOption 
       */
      parse(xmlData, validationOption) {
        if (typeof xmlData === "string") {
        } else if (xmlData.toString) {
          xmlData = xmlData.toString();
        } else {
          throw new Error("XML data is accepted in String or Bytes[] form.");
        }
        if (validationOption) {
          if (validationOption === true) validationOption = {};
          const result = validator.validate(xmlData, validationOption);
          if (result !== true) {
            throw Error(`${result.err.msg}:${result.err.line}:${result.err.col}`);
          }
        }
        const orderedObjParser = new OrderedObjParser(this.options);
        orderedObjParser.addExternalEntities(this.externalEntities);
        const orderedResult = orderedObjParser.parseXml(xmlData);
        if (this.options.preserveOrder || orderedResult === void 0) return orderedResult;
        else return prettify(orderedResult, this.options);
      }
      /**
       * Add Entity which is not by default supported by this library
       * @param {string} key 
       * @param {string} value 
       */
      addEntity(key, value) {
        if (value.indexOf("&") !== -1) {
          throw new Error("Entity value can't have '&'");
        } else if (key.indexOf("&") !== -1 || key.indexOf(";") !== -1) {
          throw new Error("An entity must be set without '&' and ';'. Eg. use '#xD' for '&#xD;'");
        } else if (value === "&") {
          throw new Error("An entity with value '&' is not permitted");
        } else {
          this.externalEntities[key] = value;
        }
      }
    };
    module.exports = XMLParser2;
  }
});

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlbuilder/orderedJs2Xml.js
var require_orderedJs2Xml = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlbuilder/orderedJs2Xml.js"(exports, module) {
    var EOL = "\n";
    function toXml(jArray, options) {
      let indentation = "";
      if (options.format && options.indentBy.length > 0) {
        indentation = EOL;
      }
      return arrToStr(jArray, options, "", indentation);
    }
    function arrToStr(arr, options, jPath, indentation) {
      let xmlStr = "";
      let isPreviousElementTag = false;
      if (!Array.isArray(arr)) {
        if (arr !== void 0 && arr !== null) {
          let text = arr.toString();
          text = replaceEntitiesValue(text, options);
          return text;
        }
        return "";
      }
      for (let i = 0; i < arr.length; i++) {
        const tagObj = arr[i];
        const tagName = propName(tagObj);
        if (tagName === void 0) continue;
        let newJPath = "";
        if (jPath.length === 0) newJPath = tagName;
        else newJPath = `${jPath}.${tagName}`;
        if (tagName === options.textNodeName) {
          let tagText = tagObj[tagName];
          if (!isStopNode(newJPath, options)) {
            tagText = options.tagValueProcessor(tagName, tagText);
            tagText = replaceEntitiesValue(tagText, options);
          }
          if (isPreviousElementTag) {
            xmlStr += indentation;
          }
          xmlStr += tagText;
          isPreviousElementTag = false;
          continue;
        } else if (tagName === options.cdataPropName) {
          if (isPreviousElementTag) {
            xmlStr += indentation;
          }
          const cdataVal = String(tagObj[tagName][0][options.textNodeName]).replace(/\]\]>/g, "]]]]><![CDATA[>");
          xmlStr += `<![CDATA[${cdataVal}]]>`;
          isPreviousElementTag = false;
          continue;
        } else if (tagName === options.commentPropName) {
          const commentVal = String(tagObj[tagName][0][options.textNodeName]).replace(/--/g, "- -").replace(/-$/, "- ");
          xmlStr += indentation + `<!--${commentVal}-->`;
          isPreviousElementTag = true;
          continue;
        } else if (tagName[0] === "?") {
          const attStr2 = attr_to_str(tagObj[":@"], options);
          const tempInd = tagName === "?xml" ? "" : indentation;
          let piTextNodeName = tagObj[tagName][0][options.textNodeName];
          piTextNodeName = piTextNodeName.length !== 0 ? " " + piTextNodeName : "";
          xmlStr += tempInd + `<${tagName}${piTextNodeName}${attStr2}?>`;
          isPreviousElementTag = true;
          continue;
        }
        let newIdentation = indentation;
        if (newIdentation !== "") {
          newIdentation += options.indentBy;
        }
        const attStr = attr_to_str(tagObj[":@"], options);
        const tagStart = indentation + `<${tagName}${attStr}`;
        const tagValue = arrToStr(tagObj[tagName], options, newJPath, newIdentation);
        if (options.unpairedTags.indexOf(tagName) !== -1) {
          if (options.suppressUnpairedNode) xmlStr += tagStart + ">";
          else xmlStr += tagStart + "/>";
        } else if ((!tagValue || tagValue.length === 0) && options.suppressEmptyNode) {
          xmlStr += tagStart + "/>";
        } else if (tagValue && tagValue.endsWith(">")) {
          xmlStr += tagStart + `>${tagValue}${indentation}</${tagName}>`;
        } else {
          xmlStr += tagStart + ">";
          if (tagValue && indentation !== "" && (tagValue.includes("/>") || tagValue.includes("</"))) {
            xmlStr += indentation + options.indentBy + tagValue + indentation;
          } else {
            xmlStr += tagValue;
          }
          xmlStr += `</${tagName}>`;
        }
        isPreviousElementTag = true;
      }
      return xmlStr;
    }
    function propName(obj) {
      const keys = Object.keys(obj);
      for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        if (!Object.prototype.hasOwnProperty.call(obj, key)) continue;
        if (key !== ":@") return key;
      }
    }
    function attr_to_str(attrMap, options) {
      let attrStr = "";
      if (attrMap && !options.ignoreAttributes) {
        for (let attr in attrMap) {
          if (!Object.prototype.hasOwnProperty.call(attrMap, attr)) continue;
          let attrVal = options.attributeValueProcessor(attr, attrMap[attr]);
          attrVal = replaceEntitiesValue(attrVal, options);
          if (attrVal === true && options.suppressBooleanAttributes) {
            attrStr += ` ${attr.substr(options.attributeNamePrefix.length)}`;
          } else {
            attrStr += ` ${attr.substr(options.attributeNamePrefix.length)}="${attrVal}"`;
          }
        }
      }
      return attrStr;
    }
    function isStopNode(jPath, options) {
      jPath = jPath.substr(0, jPath.length - options.textNodeName.length - 1);
      let tagName = jPath.substr(jPath.lastIndexOf(".") + 1);
      for (let index in options.stopNodes) {
        if (options.stopNodes[index] === jPath || options.stopNodes[index] === "*." + tagName) return true;
      }
      return false;
    }
    function replaceEntitiesValue(textValue, options) {
      if (textValue && textValue.length > 0 && options.processEntities) {
        for (let i = 0; i < options.entities.length; i++) {
          const entity = options.entities[i];
          textValue = textValue.replace(entity.regex, entity.val);
        }
      }
      return textValue;
    }
    module.exports = toXml;
  }
});

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlbuilder/json2xml.js
var require_json2xml = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/xmlbuilder/json2xml.js"(exports, module) {
    "use strict";
    var buildFromOrderedJs = require_orderedJs2Xml();
    var getIgnoreAttributesFn = require_ignoreAttributes();
    var defaultOptions = {
      attributeNamePrefix: "@_",
      attributesGroupName: false,
      textNodeName: "#text",
      ignoreAttributes: true,
      cdataPropName: false,
      format: false,
      indentBy: "  ",
      suppressEmptyNode: false,
      suppressUnpairedNode: true,
      suppressBooleanAttributes: true,
      tagValueProcessor: function(key, a) {
        return a;
      },
      attributeValueProcessor: function(attrName, a) {
        return a;
      },
      preserveOrder: false,
      commentPropName: false,
      unpairedTags: [],
      entities: [
        { regex: new RegExp("&", "g"), val: "&amp;" },
        //it must be on top
        { regex: new RegExp(">", "g"), val: "&gt;" },
        { regex: new RegExp("<", "g"), val: "&lt;" },
        { regex: new RegExp("'", "g"), val: "&apos;" },
        { regex: new RegExp('"', "g"), val: "&quot;" }
      ],
      processEntities: true,
      stopNodes: [],
      // transformTagName: false,
      // transformAttributeName: false,
      oneListGroup: false
    };
    function Builder(options) {
      this.options = Object.assign({}, defaultOptions, options);
      if (this.options.ignoreAttributes === true || this.options.attributesGroupName) {
        this.isAttribute = function() {
          return false;
        };
      } else {
        this.ignoreAttributesFn = getIgnoreAttributesFn(this.options.ignoreAttributes);
        this.attrPrefixLen = this.options.attributeNamePrefix.length;
        this.isAttribute = isAttribute;
      }
      this.processTextOrObjNode = processTextOrObjNode;
      if (this.options.format) {
        this.indentate = indentate;
        this.tagEndChar = ">\n";
        this.newLine = "\n";
      } else {
        this.indentate = function() {
          return "";
        };
        this.tagEndChar = ">";
        this.newLine = "";
      }
    }
    Builder.prototype.build = function(jObj) {
      if (this.options.preserveOrder) {
        return buildFromOrderedJs(jObj, this.options);
      } else {
        if (Array.isArray(jObj) && this.options.arrayNodeName && this.options.arrayNodeName.length > 1) {
          jObj = {
            [this.options.arrayNodeName]: jObj
          };
        }
        return this.j2x(jObj, 0, []).val;
      }
    };
    Builder.prototype.j2x = function(jObj, level, ajPath) {
      let attrStr = "";
      let val = "";
      const jPath = ajPath.join(".");
      for (let key in jObj) {
        if (!Object.prototype.hasOwnProperty.call(jObj, key)) continue;
        if (typeof jObj[key] === "undefined") {
          if (this.isAttribute(key)) {
            val += "";
          }
        } else if (jObj[key] === null) {
          if (this.isAttribute(key)) {
            val += "";
          } else if (key === this.options.cdataPropName) {
            val += "";
          } else if (key[0] === "?") {
            val += this.indentate(level) + "<" + key + "?" + this.tagEndChar;
          } else {
            val += this.indentate(level) + "<" + key + "/" + this.tagEndChar;
          }
        } else if (jObj[key] instanceof Date) {
          val += this.buildTextValNode(jObj[key], key, "", level);
        } else if (typeof jObj[key] !== "object") {
          const attr = this.isAttribute(key);
          if (attr && !this.ignoreAttributesFn(attr, jPath)) {
            attrStr += this.buildAttrPairStr(attr, "" + jObj[key]);
          } else if (!attr) {
            if (key === this.options.textNodeName) {
              let newval = this.options.tagValueProcessor(key, "" + jObj[key]);
              val += this.replaceEntitiesValue(newval);
            } else {
              val += this.buildTextValNode(jObj[key], key, "", level);
            }
          }
        } else if (Array.isArray(jObj[key])) {
          const arrLen = jObj[key].length;
          let listTagVal = "";
          let listTagAttr = "";
          for (let j = 0; j < arrLen; j++) {
            const item = jObj[key][j];
            if (typeof item === "undefined") {
            } else if (item === null) {
              if (key[0] === "?") val += this.indentate(level) + "<" + key + "?" + this.tagEndChar;
              else val += this.indentate(level) + "<" + key + "/" + this.tagEndChar;
            } else if (typeof item === "object") {
              if (this.options.oneListGroup) {
                const result = this.j2x(item, level + 1, ajPath.concat(key));
                listTagVal += result.val;
                if (this.options.attributesGroupName && item.hasOwnProperty(this.options.attributesGroupName)) {
                  listTagAttr += result.attrStr;
                }
              } else {
                listTagVal += this.processTextOrObjNode(item, key, level, ajPath);
              }
            } else {
              if (this.options.oneListGroup) {
                let textValue = this.options.tagValueProcessor(key, item);
                textValue = this.replaceEntitiesValue(textValue);
                listTagVal += textValue;
              } else {
                listTagVal += this.buildTextValNode(item, key, "", level);
              }
            }
          }
          if (this.options.oneListGroup) {
            listTagVal = this.buildObjectNode(listTagVal, key, listTagAttr, level);
          }
          val += listTagVal;
        } else {
          if (this.options.attributesGroupName && key === this.options.attributesGroupName) {
            const Ks = Object.keys(jObj[key]);
            const L = Ks.length;
            for (let j = 0; j < L; j++) {
              attrStr += this.buildAttrPairStr(Ks[j], "" + jObj[key][Ks[j]]);
            }
          } else {
            val += this.processTextOrObjNode(jObj[key], key, level, ajPath);
          }
        }
      }
      return { attrStr, val };
    };
    Builder.prototype.buildAttrPairStr = function(attrName, val) {
      val = this.options.attributeValueProcessor(attrName, "" + val);
      val = this.replaceEntitiesValue(val);
      if (this.options.suppressBooleanAttributes && val === "true") {
        return " " + attrName;
      } else return " " + attrName + '="' + val + '"';
    };
    function processTextOrObjNode(object, key, level, ajPath) {
      const result = this.j2x(object, level + 1, ajPath.concat(key));
      if (object[this.options.textNodeName] !== void 0 && Object.keys(object).length === 1) {
        return this.buildTextValNode(object[this.options.textNodeName], key, result.attrStr, level);
      } else {
        return this.buildObjectNode(result.val, key, result.attrStr, level);
      }
    }
    Builder.prototype.buildObjectNode = function(val, key, attrStr, level) {
      if (val === "") {
        if (key[0] === "?") return this.indentate(level) + "<" + key + attrStr + "?" + this.tagEndChar;
        else {
          return this.indentate(level) + "<" + key + attrStr + this.closeTag(key) + this.tagEndChar;
        }
      } else {
        let tagEndExp = "</" + key + this.tagEndChar;
        let piClosingChar = "";
        if (key[0] === "?") {
          piClosingChar = "?";
          tagEndExp = "";
        }
        if ((attrStr || attrStr === "") && val.indexOf("<") === -1) {
          return this.indentate(level) + "<" + key + attrStr + piClosingChar + ">" + val + tagEndExp;
        } else if (this.options.commentPropName !== false && key === this.options.commentPropName && piClosingChar.length === 0) {
          const safeVal = String(val).replace(/--/g, "- -").replace(/-$/, "- ");
          return this.indentate(level) + `<!--${safeVal}-->` + this.newLine;
        } else {
          return this.indentate(level) + "<" + key + attrStr + piClosingChar + this.tagEndChar + val + this.indentate(level) + tagEndExp;
        }
      }
    };
    Builder.prototype.closeTag = function(key) {
      let closeTag = "";
      if (this.options.unpairedTags.indexOf(key) !== -1) {
        if (!this.options.suppressUnpairedNode) closeTag = "/";
      } else if (this.options.suppressEmptyNode) {
        closeTag = "/";
      } else {
        closeTag = `></${key}`;
      }
      return closeTag;
    };
    Builder.prototype.buildTextValNode = function(val, key, attrStr, level) {
      if (this.options.cdataPropName !== false && key === this.options.cdataPropName) {
        const safeVal = String(val).replace(/\]\]>/g, "]]]]><![CDATA[>");
        return this.indentate(level) + `<![CDATA[${safeVal}]]>` + this.newLine;
      } else if (this.options.commentPropName !== false && key === this.options.commentPropName) {
        const safeVal = String(val).replace(/--/g, "- -").replace(/-$/, "- ");
        return this.indentate(level) + `<!--${safeVal}-->` + this.newLine;
      } else if (key[0] === "?") {
        return this.indentate(level) + "<" + key + attrStr + "?" + this.tagEndChar;
      } else {
        let textValue = this.options.tagValueProcessor(key, val);
        textValue = this.replaceEntitiesValue(textValue);
        if (textValue === "") {
          return this.indentate(level) + "<" + key + attrStr + this.closeTag(key) + this.tagEndChar;
        } else {
          return this.indentate(level) + "<" + key + attrStr + ">" + textValue + "</" + key + this.tagEndChar;
        }
      }
    };
    Builder.prototype.replaceEntitiesValue = function(textValue) {
      if (textValue && textValue.length > 0 && this.options.processEntities) {
        for (let i = 0; i < this.options.entities.length; i++) {
          const entity = this.options.entities[i];
          textValue = textValue.replace(entity.regex, entity.val);
        }
      }
      return textValue;
    };
    function indentate(level) {
      return this.options.indentBy.repeat(level);
    }
    function isAttribute(name) {
      if (name.startsWith(this.options.attributeNamePrefix) && name !== this.options.textNodeName) {
        return name.substr(this.attrPrefixLen);
      } else {
        return false;
      }
    }
    module.exports = Builder;
  }
});

// ../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/fxp.js
var require_fxp = __commonJS({
  "../../node_modules/.pnpm/fast-xml-parser@4.5.7/node_modules/fast-xml-parser/src/fxp.js"(exports, module) {
    "use strict";
    var validator = require_validator();
    var XMLParser2 = require_XMLParser();
    var XMLBuilder = require_json2xml();
    module.exports = {
      XMLParser: XMLParser2,
      XMLValidator: validator,
      XMLBuilder
    };
  }
});

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/util.cjs
var require_util2 = __commonJS({
  "../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/util.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getParsedType = exports.ZodParsedType = exports.objectUtil = exports.util = void 0;
    var util;
    (function(util2) {
      util2.assertEqual = (_) => {
      };
      function assertIs(_arg) {
      }
      util2.assertIs = assertIs;
      function assertNever(_x) {
        throw new Error();
      }
      util2.assertNever = assertNever;
      util2.arrayToEnum = (items) => {
        const obj = {};
        for (const item of items) {
          obj[item] = item;
        }
        return obj;
      };
      util2.getValidEnumValues = (obj) => {
        const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
        const filtered = {};
        for (const k of validKeys) {
          filtered[k] = obj[k];
        }
        return util2.objectValues(filtered);
      };
      util2.objectValues = (obj) => {
        return util2.objectKeys(obj).map(function(e) {
          return obj[e];
        });
      };
      util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
        const keys = [];
        for (const key in object) {
          if (Object.prototype.hasOwnProperty.call(object, key)) {
            keys.push(key);
          }
        }
        return keys;
      };
      util2.find = (arr, checker) => {
        for (const item of arr) {
          if (checker(item))
            return item;
        }
        return void 0;
      };
      util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
      function joinValues(array, separator = " | ") {
        return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
      }
      util2.joinValues = joinValues;
      util2.jsonStringifyReplacer = (_, value) => {
        if (typeof value === "bigint") {
          return value.toString();
        }
        return value;
      };
    })(util || (exports.util = util = {}));
    var objectUtil;
    (function(objectUtil2) {
      objectUtil2.mergeShapes = (first, second) => {
        return {
          ...first,
          ...second
          // second overwrites first
        };
      };
    })(objectUtil || (exports.objectUtil = objectUtil = {}));
    exports.ZodParsedType = util.arrayToEnum([
      "string",
      "nan",
      "number",
      "integer",
      "float",
      "boolean",
      "date",
      "bigint",
      "symbol",
      "function",
      "undefined",
      "null",
      "array",
      "object",
      "unknown",
      "promise",
      "void",
      "never",
      "map",
      "set"
    ]);
    var getParsedType = (data) => {
      const t = typeof data;
      switch (t) {
        case "undefined":
          return exports.ZodParsedType.undefined;
        case "string":
          return exports.ZodParsedType.string;
        case "number":
          return Number.isNaN(data) ? exports.ZodParsedType.nan : exports.ZodParsedType.number;
        case "boolean":
          return exports.ZodParsedType.boolean;
        case "function":
          return exports.ZodParsedType.function;
        case "bigint":
          return exports.ZodParsedType.bigint;
        case "symbol":
          return exports.ZodParsedType.symbol;
        case "object":
          if (Array.isArray(data)) {
            return exports.ZodParsedType.array;
          }
          if (data === null) {
            return exports.ZodParsedType.null;
          }
          if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
            return exports.ZodParsedType.promise;
          }
          if (typeof Map !== "undefined" && data instanceof Map) {
            return exports.ZodParsedType.map;
          }
          if (typeof Set !== "undefined" && data instanceof Set) {
            return exports.ZodParsedType.set;
          }
          if (typeof Date !== "undefined" && data instanceof Date) {
            return exports.ZodParsedType.date;
          }
          return exports.ZodParsedType.object;
        default:
          return exports.ZodParsedType.unknown;
      }
    };
    exports.getParsedType = getParsedType;
  }
});

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/ZodError.cjs
var require_ZodError = __commonJS({
  "../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/ZodError.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ZodError = exports.quotelessJson = exports.ZodIssueCode = void 0;
    var util_js_1 = require_util2();
    exports.ZodIssueCode = util_js_1.util.arrayToEnum([
      "invalid_type",
      "invalid_literal",
      "custom",
      "invalid_union",
      "invalid_union_discriminator",
      "invalid_enum_value",
      "unrecognized_keys",
      "invalid_arguments",
      "invalid_return_type",
      "invalid_date",
      "invalid_string",
      "too_small",
      "too_big",
      "invalid_intersection_types",
      "not_multiple_of",
      "not_finite"
    ]);
    var quotelessJson = (obj) => {
      const json = JSON.stringify(obj, null, 2);
      return json.replace(/"([^"]+)":/g, "$1:");
    };
    exports.quotelessJson = quotelessJson;
    var ZodError = class _ZodError extends Error {
      get errors() {
        return this.issues;
      }
      constructor(issues) {
        super();
        this.issues = [];
        this.addIssue = (sub) => {
          this.issues = [...this.issues, sub];
        };
        this.addIssues = (subs = []) => {
          this.issues = [...this.issues, ...subs];
        };
        const actualProto = new.target.prototype;
        if (Object.setPrototypeOf) {
          Object.setPrototypeOf(this, actualProto);
        } else {
          this.__proto__ = actualProto;
        }
        this.name = "ZodError";
        this.issues = issues;
      }
      format(_mapper) {
        const mapper = _mapper || function(issue) {
          return issue.message;
        };
        const fieldErrors = { _errors: [] };
        const processError = (error) => {
          for (const issue of error.issues) {
            if (issue.code === "invalid_union") {
              issue.unionErrors.map(processError);
            } else if (issue.code === "invalid_return_type") {
              processError(issue.returnTypeError);
            } else if (issue.code === "invalid_arguments") {
              processError(issue.argumentsError);
            } else if (issue.path.length === 0) {
              fieldErrors._errors.push(mapper(issue));
            } else {
              let curr = fieldErrors;
              let i = 0;
              while (i < issue.path.length) {
                const el = issue.path[i];
                const terminal = i === issue.path.length - 1;
                if (!terminal) {
                  curr[el] = curr[el] || { _errors: [] };
                } else {
                  curr[el] = curr[el] || { _errors: [] };
                  curr[el]._errors.push(mapper(issue));
                }
                curr = curr[el];
                i++;
              }
            }
          }
        };
        processError(this);
        return fieldErrors;
      }
      static assert(value) {
        if (!(value instanceof _ZodError)) {
          throw new Error(`Not a ZodError: ${value}`);
        }
      }
      toString() {
        return this.message;
      }
      get message() {
        return JSON.stringify(this.issues, util_js_1.util.jsonStringifyReplacer, 2);
      }
      get isEmpty() {
        return this.issues.length === 0;
      }
      flatten(mapper = (issue) => issue.message) {
        const fieldErrors = {};
        const formErrors = [];
        for (const sub of this.issues) {
          if (sub.path.length > 0) {
            const firstEl = sub.path[0];
            fieldErrors[firstEl] = fieldErrors[firstEl] || [];
            fieldErrors[firstEl].push(mapper(sub));
          } else {
            formErrors.push(mapper(sub));
          }
        }
        return { formErrors, fieldErrors };
      }
      get formErrors() {
        return this.flatten();
      }
    };
    exports.ZodError = ZodError;
    ZodError.create = (issues) => {
      const error = new ZodError(issues);
      return error;
    };
  }
});

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/locales/en.cjs
var require_en = __commonJS({
  "../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/locales/en.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ZodError_js_1 = require_ZodError();
    var util_js_1 = require_util2();
    var errorMap = (issue, _ctx) => {
      let message;
      switch (issue.code) {
        case ZodError_js_1.ZodIssueCode.invalid_type:
          if (issue.received === util_js_1.ZodParsedType.undefined) {
            message = "Required";
          } else {
            message = `Expected ${issue.expected}, received ${issue.received}`;
          }
          break;
        case ZodError_js_1.ZodIssueCode.invalid_literal:
          message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util_js_1.util.jsonStringifyReplacer)}`;
          break;
        case ZodError_js_1.ZodIssueCode.unrecognized_keys:
          message = `Unrecognized key(s) in object: ${util_js_1.util.joinValues(issue.keys, ", ")}`;
          break;
        case ZodError_js_1.ZodIssueCode.invalid_union:
          message = `Invalid input`;
          break;
        case ZodError_js_1.ZodIssueCode.invalid_union_discriminator:
          message = `Invalid discriminator value. Expected ${util_js_1.util.joinValues(issue.options)}`;
          break;
        case ZodError_js_1.ZodIssueCode.invalid_enum_value:
          message = `Invalid enum value. Expected ${util_js_1.util.joinValues(issue.options)}, received '${issue.received}'`;
          break;
        case ZodError_js_1.ZodIssueCode.invalid_arguments:
          message = `Invalid function arguments`;
          break;
        case ZodError_js_1.ZodIssueCode.invalid_return_type:
          message = `Invalid function return type`;
          break;
        case ZodError_js_1.ZodIssueCode.invalid_date:
          message = `Invalid date`;
          break;
        case ZodError_js_1.ZodIssueCode.invalid_string:
          if (typeof issue.validation === "object") {
            if ("includes" in issue.validation) {
              message = `Invalid input: must include "${issue.validation.includes}"`;
              if (typeof issue.validation.position === "number") {
                message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
              }
            } else if ("startsWith" in issue.validation) {
              message = `Invalid input: must start with "${issue.validation.startsWith}"`;
            } else if ("endsWith" in issue.validation) {
              message = `Invalid input: must end with "${issue.validation.endsWith}"`;
            } else {
              util_js_1.util.assertNever(issue.validation);
            }
          } else if (issue.validation !== "regex") {
            message = `Invalid ${issue.validation}`;
          } else {
            message = "Invalid";
          }
          break;
        case ZodError_js_1.ZodIssueCode.too_small:
          if (issue.type === "array")
            message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
          else if (issue.type === "string")
            message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
          else if (issue.type === "number")
            message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
          else if (issue.type === "bigint")
            message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
          else if (issue.type === "date")
            message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
          else
            message = "Invalid input";
          break;
        case ZodError_js_1.ZodIssueCode.too_big:
          if (issue.type === "array")
            message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
          else if (issue.type === "string")
            message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
          else if (issue.type === "number")
            message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
          else if (issue.type === "bigint")
            message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
          else if (issue.type === "date")
            message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
          else
            message = "Invalid input";
          break;
        case ZodError_js_1.ZodIssueCode.custom:
          message = `Invalid input`;
          break;
        case ZodError_js_1.ZodIssueCode.invalid_intersection_types:
          message = `Intersection results could not be merged`;
          break;
        case ZodError_js_1.ZodIssueCode.not_multiple_of:
          message = `Number must be a multiple of ${issue.multipleOf}`;
          break;
        case ZodError_js_1.ZodIssueCode.not_finite:
          message = "Number must be finite";
          break;
        default:
          message = _ctx.defaultError;
          util_js_1.util.assertNever(issue);
      }
      return { message };
    };
    exports.default = errorMap;
  }
});

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/errors.cjs
var require_errors = __commonJS({
  "../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/errors.cjs"(exports) {
    "use strict";
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.defaultErrorMap = void 0;
    exports.setErrorMap = setErrorMap;
    exports.getErrorMap = getErrorMap;
    var en_js_1 = __importDefault(require_en());
    exports.defaultErrorMap = en_js_1.default;
    var overrideErrorMap = en_js_1.default;
    function setErrorMap(map) {
      overrideErrorMap = map;
    }
    function getErrorMap() {
      return overrideErrorMap;
    }
  }
});

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/parseUtil.cjs
var require_parseUtil = __commonJS({
  "../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/parseUtil.cjs"(exports) {
    "use strict";
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.isAsync = exports.isValid = exports.isDirty = exports.isAborted = exports.OK = exports.DIRTY = exports.INVALID = exports.ParseStatus = exports.EMPTY_PATH = exports.makeIssue = void 0;
    exports.addIssueToContext = addIssueToContext;
    var errors_js_1 = require_errors();
    var en_js_1 = __importDefault(require_en());
    var makeIssue = (params) => {
      const { data, path: path5, errorMaps, issueData } = params;
      const fullPath = [...path5, ...issueData.path || []];
      const fullIssue = {
        ...issueData,
        path: fullPath
      };
      if (issueData.message !== void 0) {
        return {
          ...issueData,
          path: fullPath,
          message: issueData.message
        };
      }
      let errorMessage = "";
      const maps = errorMaps.filter((m) => !!m).slice().reverse();
      for (const map of maps) {
        errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
      }
      return {
        ...issueData,
        path: fullPath,
        message: errorMessage
      };
    };
    exports.makeIssue = makeIssue;
    exports.EMPTY_PATH = [];
    function addIssueToContext(ctx, issueData) {
      const overrideMap = (0, errors_js_1.getErrorMap)();
      const issue = (0, exports.makeIssue)({
        issueData,
        data: ctx.data,
        path: ctx.path,
        errorMaps: [
          ctx.common.contextualErrorMap,
          // contextual error map is first priority
          ctx.schemaErrorMap,
          // then schema-bound map if available
          overrideMap,
          // then global override map
          overrideMap === en_js_1.default ? void 0 : en_js_1.default
          // then global default map
        ].filter((x) => !!x)
      });
      ctx.common.issues.push(issue);
    }
    var ParseStatus = class _ParseStatus {
      constructor() {
        this.value = "valid";
      }
      dirty() {
        if (this.value === "valid")
          this.value = "dirty";
      }
      abort() {
        if (this.value !== "aborted")
          this.value = "aborted";
      }
      static mergeArray(status, results) {
        const arrayValue = [];
        for (const s of results) {
          if (s.status === "aborted")
            return exports.INVALID;
          if (s.status === "dirty")
            status.dirty();
          arrayValue.push(s.value);
        }
        return { status: status.value, value: arrayValue };
      }
      static async mergeObjectAsync(status, pairs) {
        const syncPairs = [];
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          syncPairs.push({
            key,
            value
          });
        }
        return _ParseStatus.mergeObjectSync(status, syncPairs);
      }
      static mergeObjectSync(status, pairs) {
        const finalObject = {};
        for (const pair of pairs) {
          const { key, value } = pair;
          if (key.status === "aborted")
            return exports.INVALID;
          if (value.status === "aborted")
            return exports.INVALID;
          if (key.status === "dirty")
            status.dirty();
          if (value.status === "dirty")
            status.dirty();
          if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
            finalObject[key.value] = value.value;
          }
        }
        return { status: status.value, value: finalObject };
      }
    };
    exports.ParseStatus = ParseStatus;
    exports.INVALID = Object.freeze({
      status: "aborted"
    });
    var DIRTY = (value) => ({ status: "dirty", value });
    exports.DIRTY = DIRTY;
    var OK = (value) => ({ status: "valid", value });
    exports.OK = OK;
    var isAborted = (x) => x.status === "aborted";
    exports.isAborted = isAborted;
    var isDirty = (x) => x.status === "dirty";
    exports.isDirty = isDirty;
    var isValid = (x) => x.status === "valid";
    exports.isValid = isValid;
    var isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;
    exports.isAsync = isAsync;
  }
});

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/typeAliases.cjs
var require_typeAliases = __commonJS({
  "../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/typeAliases.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/errorUtil.cjs
var require_errorUtil = __commonJS({
  "../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/errorUtil.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.errorUtil = void 0;
    var errorUtil;
    (function(errorUtil2) {
      errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
      errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
    })(errorUtil || (exports.errorUtil = errorUtil = {}));
  }
});

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/types.cjs
var require_types = __commonJS({
  "../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/types.cjs"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.discriminatedUnion = exports.date = exports.boolean = exports.bigint = exports.array = exports.any = exports.coerce = exports.ZodFirstPartyTypeKind = exports.late = exports.ZodSchema = exports.Schema = exports.ZodReadonly = exports.ZodPipeline = exports.ZodBranded = exports.BRAND = exports.ZodNaN = exports.ZodCatch = exports.ZodDefault = exports.ZodNullable = exports.ZodOptional = exports.ZodTransformer = exports.ZodEffects = exports.ZodPromise = exports.ZodNativeEnum = exports.ZodEnum = exports.ZodLiteral = exports.ZodLazy = exports.ZodFunction = exports.ZodSet = exports.ZodMap = exports.ZodRecord = exports.ZodTuple = exports.ZodIntersection = exports.ZodDiscriminatedUnion = exports.ZodUnion = exports.ZodObject = exports.ZodArray = exports.ZodVoid = exports.ZodNever = exports.ZodUnknown = exports.ZodAny = exports.ZodNull = exports.ZodUndefined = exports.ZodSymbol = exports.ZodDate = exports.ZodBoolean = exports.ZodBigInt = exports.ZodNumber = exports.ZodString = exports.ZodType = void 0;
    exports.NEVER = exports.void = exports.unknown = exports.union = exports.undefined = exports.tuple = exports.transformer = exports.symbol = exports.string = exports.strictObject = exports.set = exports.record = exports.promise = exports.preprocess = exports.pipeline = exports.ostring = exports.optional = exports.onumber = exports.oboolean = exports.object = exports.number = exports.nullable = exports.null = exports.never = exports.nativeEnum = exports.nan = exports.map = exports.literal = exports.lazy = exports.intersection = exports.instanceof = exports.function = exports.enum = exports.effect = void 0;
    exports.datetimeRegex = datetimeRegex;
    exports.custom = custom;
    var ZodError_js_1 = require_ZodError();
    var errors_js_1 = require_errors();
    var errorUtil_js_1 = require_errorUtil();
    var parseUtil_js_1 = require_parseUtil();
    var util_js_1 = require_util2();
    var ParseInputLazyPath = class {
      constructor(parent, value, path5, key) {
        this._cachedPath = [];
        this.parent = parent;
        this.data = value;
        this._path = path5;
        this._key = key;
      }
      get path() {
        if (!this._cachedPath.length) {
          if (Array.isArray(this._key)) {
            this._cachedPath.push(...this._path, ...this._key);
          } else {
            this._cachedPath.push(...this._path, this._key);
          }
        }
        return this._cachedPath;
      }
    };
    var handleResult = (ctx, result) => {
      if ((0, parseUtil_js_1.isValid)(result)) {
        return { success: true, data: result.value };
      } else {
        if (!ctx.common.issues.length) {
          throw new Error("Validation failed but no issues detected.");
        }
        return {
          success: false,
          get error() {
            if (this._error)
              return this._error;
            const error = new ZodError_js_1.ZodError(ctx.common.issues);
            this._error = error;
            return this._error;
          }
        };
      }
    };
    function processCreateParams(params) {
      if (!params)
        return {};
      const { errorMap, invalid_type_error, required_error, description } = params;
      if (errorMap && (invalid_type_error || required_error)) {
        throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
      }
      if (errorMap)
        return { errorMap, description };
      const customMap = (iss, ctx) => {
        const { message } = params;
        if (iss.code === "invalid_enum_value") {
          return { message: message ?? ctx.defaultError };
        }
        if (typeof ctx.data === "undefined") {
          return { message: message ?? required_error ?? ctx.defaultError };
        }
        if (iss.code !== "invalid_type")
          return { message: ctx.defaultError };
        return { message: message ?? invalid_type_error ?? ctx.defaultError };
      };
      return { errorMap: customMap, description };
    }
    var ZodType = class {
      get description() {
        return this._def.description;
      }
      _getType(input) {
        return (0, util_js_1.getParsedType)(input.data);
      }
      _getOrReturnCtx(input, ctx) {
        return ctx || {
          common: input.parent.common,
          data: input.data,
          parsedType: (0, util_js_1.getParsedType)(input.data),
          schemaErrorMap: this._def.errorMap,
          path: input.path,
          parent: input.parent
        };
      }
      _processInputParams(input) {
        return {
          status: new parseUtil_js_1.ParseStatus(),
          ctx: {
            common: input.parent.common,
            data: input.data,
            parsedType: (0, util_js_1.getParsedType)(input.data),
            schemaErrorMap: this._def.errorMap,
            path: input.path,
            parent: input.parent
          }
        };
      }
      _parseSync(input) {
        const result = this._parse(input);
        if ((0, parseUtil_js_1.isAsync)(result)) {
          throw new Error("Synchronous parse encountered promise.");
        }
        return result;
      }
      _parseAsync(input) {
        const result = this._parse(input);
        return Promise.resolve(result);
      }
      parse(data, params) {
        const result = this.safeParse(data, params);
        if (result.success)
          return result.data;
        throw result.error;
      }
      safeParse(data, params) {
        const ctx = {
          common: {
            issues: [],
            async: params?.async ?? false,
            contextualErrorMap: params?.errorMap
          },
          path: params?.path || [],
          schemaErrorMap: this._def.errorMap,
          parent: null,
          data,
          parsedType: (0, util_js_1.getParsedType)(data)
        };
        const result = this._parseSync({ data, path: ctx.path, parent: ctx });
        return handleResult(ctx, result);
      }
      "~validate"(data) {
        const ctx = {
          common: {
            issues: [],
            async: !!this["~standard"].async
          },
          path: [],
          schemaErrorMap: this._def.errorMap,
          parent: null,
          data,
          parsedType: (0, util_js_1.getParsedType)(data)
        };
        if (!this["~standard"].async) {
          try {
            const result = this._parseSync({ data, path: [], parent: ctx });
            return (0, parseUtil_js_1.isValid)(result) ? {
              value: result.value
            } : {
              issues: ctx.common.issues
            };
          } catch (err) {
            if (err?.message?.toLowerCase()?.includes("encountered")) {
              this["~standard"].async = true;
            }
            ctx.common = {
              issues: [],
              async: true
            };
          }
        }
        return this._parseAsync({ data, path: [], parent: ctx }).then((result) => (0, parseUtil_js_1.isValid)(result) ? {
          value: result.value
        } : {
          issues: ctx.common.issues
        });
      }
      async parseAsync(data, params) {
        const result = await this.safeParseAsync(data, params);
        if (result.success)
          return result.data;
        throw result.error;
      }
      async safeParseAsync(data, params) {
        const ctx = {
          common: {
            issues: [],
            contextualErrorMap: params?.errorMap,
            async: true
          },
          path: params?.path || [],
          schemaErrorMap: this._def.errorMap,
          parent: null,
          data,
          parsedType: (0, util_js_1.getParsedType)(data)
        };
        const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
        const result = await ((0, parseUtil_js_1.isAsync)(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
        return handleResult(ctx, result);
      }
      refine(check, message) {
        const getIssueProperties = (val) => {
          if (typeof message === "string" || typeof message === "undefined") {
            return { message };
          } else if (typeof message === "function") {
            return message(val);
          } else {
            return message;
          }
        };
        return this._refinement((val, ctx) => {
          const result = check(val);
          const setError = () => ctx.addIssue({
            code: ZodError_js_1.ZodIssueCode.custom,
            ...getIssueProperties(val)
          });
          if (typeof Promise !== "undefined" && result instanceof Promise) {
            return result.then((data) => {
              if (!data) {
                setError();
                return false;
              } else {
                return true;
              }
            });
          }
          if (!result) {
            setError();
            return false;
          } else {
            return true;
          }
        });
      }
      refinement(check, refinementData) {
        return this._refinement((val, ctx) => {
          if (!check(val)) {
            ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
            return false;
          } else {
            return true;
          }
        });
      }
      _refinement(refinement) {
        return new ZodEffects({
          schema: this,
          typeName: ZodFirstPartyTypeKind.ZodEffects,
          effect: { type: "refinement", refinement }
        });
      }
      superRefine(refinement) {
        return this._refinement(refinement);
      }
      constructor(def) {
        this.spa = this.safeParseAsync;
        this._def = def;
        this.parse = this.parse.bind(this);
        this.safeParse = this.safeParse.bind(this);
        this.parseAsync = this.parseAsync.bind(this);
        this.safeParseAsync = this.safeParseAsync.bind(this);
        this.spa = this.spa.bind(this);
        this.refine = this.refine.bind(this);
        this.refinement = this.refinement.bind(this);
        this.superRefine = this.superRefine.bind(this);
        this.optional = this.optional.bind(this);
        this.nullable = this.nullable.bind(this);
        this.nullish = this.nullish.bind(this);
        this.array = this.array.bind(this);
        this.promise = this.promise.bind(this);
        this.or = this.or.bind(this);
        this.and = this.and.bind(this);
        this.transform = this.transform.bind(this);
        this.brand = this.brand.bind(this);
        this.default = this.default.bind(this);
        this.catch = this.catch.bind(this);
        this.describe = this.describe.bind(this);
        this.pipe = this.pipe.bind(this);
        this.readonly = this.readonly.bind(this);
        this.isNullable = this.isNullable.bind(this);
        this.isOptional = this.isOptional.bind(this);
        this["~standard"] = {
          version: 1,
          vendor: "zod",
          validate: (data) => this["~validate"](data)
        };
      }
      optional() {
        return ZodOptional.create(this, this._def);
      }
      nullable() {
        return ZodNullable.create(this, this._def);
      }
      nullish() {
        return this.nullable().optional();
      }
      array() {
        return ZodArray.create(this);
      }
      promise() {
        return ZodPromise.create(this, this._def);
      }
      or(option) {
        return ZodUnion.create([this, option], this._def);
      }
      and(incoming) {
        return ZodIntersection.create(this, incoming, this._def);
      }
      transform(transform) {
        return new ZodEffects({
          ...processCreateParams(this._def),
          schema: this,
          typeName: ZodFirstPartyTypeKind.ZodEffects,
          effect: { type: "transform", transform }
        });
      }
      default(def) {
        const defaultValueFunc = typeof def === "function" ? def : () => def;
        return new ZodDefault({
          ...processCreateParams(this._def),
          innerType: this,
          defaultValue: defaultValueFunc,
          typeName: ZodFirstPartyTypeKind.ZodDefault
        });
      }
      brand() {
        return new ZodBranded({
          typeName: ZodFirstPartyTypeKind.ZodBranded,
          type: this,
          ...processCreateParams(this._def)
        });
      }
      catch(def) {
        const catchValueFunc = typeof def === "function" ? def : () => def;
        return new ZodCatch({
          ...processCreateParams(this._def),
          innerType: this,
          catchValue: catchValueFunc,
          typeName: ZodFirstPartyTypeKind.ZodCatch
        });
      }
      describe(description) {
        const This = this.constructor;
        return new This({
          ...this._def,
          description
        });
      }
      pipe(target) {
        return ZodPipeline.create(this, target);
      }
      readonly() {
        return ZodReadonly.create(this);
      }
      isOptional() {
        return this.safeParse(void 0).success;
      }
      isNullable() {
        return this.safeParse(null).success;
      }
    };
    exports.ZodType = ZodType;
    exports.Schema = ZodType;
    exports.ZodSchema = ZodType;
    var cuidRegex = /^c[^\s-]{8,}$/i;
    var cuid2Regex = /^[0-9a-z]+$/;
    var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
    var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
    var nanoidRegex = /^[a-z0-9_-]{21}$/i;
    var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
    var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
    var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
    var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
    var emojiRegex;
    var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
    var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
    var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
    var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
    var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
    var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
    var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
    var dateRegex = new RegExp(`^${dateRegexSource}$`);
    function timeRegexSource(args2) {
      let secondsRegexSource = `[0-5]\\d`;
      if (args2.precision) {
        secondsRegexSource = `${secondsRegexSource}\\.\\d{${args2.precision}}`;
      } else if (args2.precision == null) {
        secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
      }
      const secondsQuantifier = args2.precision ? "+" : "?";
      return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
    }
    function timeRegex(args2) {
      return new RegExp(`^${timeRegexSource(args2)}$`);
    }
    function datetimeRegex(args2) {
      let regex = `${dateRegexSource}T${timeRegexSource(args2)}`;
      const opts = [];
      opts.push(args2.local ? `Z?` : `Z`);
      if (args2.offset)
        opts.push(`([+-]\\d{2}:?\\d{2})`);
      regex = `${regex}(${opts.join("|")})`;
      return new RegExp(`^${regex}$`);
    }
    function isValidIP(ip, version) {
      if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
        return true;
      }
      if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
        return true;
      }
      return false;
    }
    function isValidJWT(jwt, alg) {
      if (!jwtRegex.test(jwt))
        return false;
      try {
        const [header] = jwt.split(".");
        if (!header)
          return false;
        const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
        const decoded = JSON.parse(atob(base64));
        if (typeof decoded !== "object" || decoded === null)
          return false;
        if ("typ" in decoded && decoded?.typ !== "JWT")
          return false;
        if (!decoded.alg)
          return false;
        if (alg && decoded.alg !== alg)
          return false;
        return true;
      } catch {
        return false;
      }
    }
    function isValidCidr(ip, version) {
      if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
        return true;
      }
      if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
        return true;
      }
      return false;
    }
    var ZodString = class _ZodString extends ZodType {
      _parse(input) {
        if (this._def.coerce) {
          input.data = String(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== util_js_1.ZodParsedType.string) {
          const ctx2 = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx2, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.string,
            received: ctx2.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        const status = new parseUtil_js_1.ParseStatus();
        let ctx = void 0;
        for (const check of this._def.checks) {
          if (check.kind === "min") {
            if (input.data.length < check.value) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.too_small,
                minimum: check.value,
                type: "string",
                inclusive: true,
                exact: false,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "max") {
            if (input.data.length > check.value) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.too_big,
                maximum: check.value,
                type: "string",
                inclusive: true,
                exact: false,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "length") {
            const tooBig = input.data.length > check.value;
            const tooSmall = input.data.length < check.value;
            if (tooBig || tooSmall) {
              ctx = this._getOrReturnCtx(input, ctx);
              if (tooBig) {
                (0, parseUtil_js_1.addIssueToContext)(ctx, {
                  code: ZodError_js_1.ZodIssueCode.too_big,
                  maximum: check.value,
                  type: "string",
                  inclusive: true,
                  exact: true,
                  message: check.message
                });
              } else if (tooSmall) {
                (0, parseUtil_js_1.addIssueToContext)(ctx, {
                  code: ZodError_js_1.ZodIssueCode.too_small,
                  minimum: check.value,
                  type: "string",
                  inclusive: true,
                  exact: true,
                  message: check.message
                });
              }
              status.dirty();
            }
          } else if (check.kind === "email") {
            if (!emailRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "email",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "emoji") {
            if (!emojiRegex) {
              emojiRegex = new RegExp(_emojiRegex, "u");
            }
            if (!emojiRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "emoji",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "uuid") {
            if (!uuidRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "uuid",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "nanoid") {
            if (!nanoidRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "nanoid",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "cuid") {
            if (!cuidRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "cuid",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "cuid2") {
            if (!cuid2Regex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "cuid2",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "ulid") {
            if (!ulidRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "ulid",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "url") {
            try {
              new URL(input.data);
            } catch {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "url",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "regex") {
            check.regex.lastIndex = 0;
            const testResult = check.regex.test(input.data);
            if (!testResult) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "regex",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "trim") {
            input.data = input.data.trim();
          } else if (check.kind === "includes") {
            if (!input.data.includes(check.value, check.position)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                validation: { includes: check.value, position: check.position },
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "toLowerCase") {
            input.data = input.data.toLowerCase();
          } else if (check.kind === "toUpperCase") {
            input.data = input.data.toUpperCase();
          } else if (check.kind === "startsWith") {
            if (!input.data.startsWith(check.value)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                validation: { startsWith: check.value },
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "endsWith") {
            if (!input.data.endsWith(check.value)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                validation: { endsWith: check.value },
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "datetime") {
            const regex = datetimeRegex(check);
            if (!regex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                validation: "datetime",
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "date") {
            const regex = dateRegex;
            if (!regex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                validation: "date",
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "time") {
            const regex = timeRegex(check);
            if (!regex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                validation: "time",
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "duration") {
            if (!durationRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "duration",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "ip") {
            if (!isValidIP(input.data, check.version)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "ip",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "jwt") {
            if (!isValidJWT(input.data, check.alg)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "jwt",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "cidr") {
            if (!isValidCidr(input.data, check.version)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "cidr",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "base64") {
            if (!base64Regex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "base64",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "base64url") {
            if (!base64urlRegex.test(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                validation: "base64url",
                code: ZodError_js_1.ZodIssueCode.invalid_string,
                message: check.message
              });
              status.dirty();
            }
          } else {
            util_js_1.util.assertNever(check);
          }
        }
        return { status: status.value, value: input.data };
      }
      _regex(regex, validation, message) {
        return this.refinement((data) => regex.test(data), {
          validation,
          code: ZodError_js_1.ZodIssueCode.invalid_string,
          ...errorUtil_js_1.errorUtil.errToObj(message)
        });
      }
      _addCheck(check) {
        return new _ZodString({
          ...this._def,
          checks: [...this._def.checks, check]
        });
      }
      email(message) {
        return this._addCheck({ kind: "email", ...errorUtil_js_1.errorUtil.errToObj(message) });
      }
      url(message) {
        return this._addCheck({ kind: "url", ...errorUtil_js_1.errorUtil.errToObj(message) });
      }
      emoji(message) {
        return this._addCheck({ kind: "emoji", ...errorUtil_js_1.errorUtil.errToObj(message) });
      }
      uuid(message) {
        return this._addCheck({ kind: "uuid", ...errorUtil_js_1.errorUtil.errToObj(message) });
      }
      nanoid(message) {
        return this._addCheck({ kind: "nanoid", ...errorUtil_js_1.errorUtil.errToObj(message) });
      }
      cuid(message) {
        return this._addCheck({ kind: "cuid", ...errorUtil_js_1.errorUtil.errToObj(message) });
      }
      cuid2(message) {
        return this._addCheck({ kind: "cuid2", ...errorUtil_js_1.errorUtil.errToObj(message) });
      }
      ulid(message) {
        return this._addCheck({ kind: "ulid", ...errorUtil_js_1.errorUtil.errToObj(message) });
      }
      base64(message) {
        return this._addCheck({ kind: "base64", ...errorUtil_js_1.errorUtil.errToObj(message) });
      }
      base64url(message) {
        return this._addCheck({
          kind: "base64url",
          ...errorUtil_js_1.errorUtil.errToObj(message)
        });
      }
      jwt(options) {
        return this._addCheck({ kind: "jwt", ...errorUtil_js_1.errorUtil.errToObj(options) });
      }
      ip(options) {
        return this._addCheck({ kind: "ip", ...errorUtil_js_1.errorUtil.errToObj(options) });
      }
      cidr(options) {
        return this._addCheck({ kind: "cidr", ...errorUtil_js_1.errorUtil.errToObj(options) });
      }
      datetime(options) {
        if (typeof options === "string") {
          return this._addCheck({
            kind: "datetime",
            precision: null,
            offset: false,
            local: false,
            message: options
          });
        }
        return this._addCheck({
          kind: "datetime",
          precision: typeof options?.precision === "undefined" ? null : options?.precision,
          offset: options?.offset ?? false,
          local: options?.local ?? false,
          ...errorUtil_js_1.errorUtil.errToObj(options?.message)
        });
      }
      date(message) {
        return this._addCheck({ kind: "date", message });
      }
      time(options) {
        if (typeof options === "string") {
          return this._addCheck({
            kind: "time",
            precision: null,
            message: options
          });
        }
        return this._addCheck({
          kind: "time",
          precision: typeof options?.precision === "undefined" ? null : options?.precision,
          ...errorUtil_js_1.errorUtil.errToObj(options?.message)
        });
      }
      duration(message) {
        return this._addCheck({ kind: "duration", ...errorUtil_js_1.errorUtil.errToObj(message) });
      }
      regex(regex, message) {
        return this._addCheck({
          kind: "regex",
          regex,
          ...errorUtil_js_1.errorUtil.errToObj(message)
        });
      }
      includes(value, options) {
        return this._addCheck({
          kind: "includes",
          value,
          position: options?.position,
          ...errorUtil_js_1.errorUtil.errToObj(options?.message)
        });
      }
      startsWith(value, message) {
        return this._addCheck({
          kind: "startsWith",
          value,
          ...errorUtil_js_1.errorUtil.errToObj(message)
        });
      }
      endsWith(value, message) {
        return this._addCheck({
          kind: "endsWith",
          value,
          ...errorUtil_js_1.errorUtil.errToObj(message)
        });
      }
      min(minLength, message) {
        return this._addCheck({
          kind: "min",
          value: minLength,
          ...errorUtil_js_1.errorUtil.errToObj(message)
        });
      }
      max(maxLength, message) {
        return this._addCheck({
          kind: "max",
          value: maxLength,
          ...errorUtil_js_1.errorUtil.errToObj(message)
        });
      }
      length(len, message) {
        return this._addCheck({
          kind: "length",
          value: len,
          ...errorUtil_js_1.errorUtil.errToObj(message)
        });
      }
      /**
       * Equivalent to `.min(1)`
       */
      nonempty(message) {
        return this.min(1, errorUtil_js_1.errorUtil.errToObj(message));
      }
      trim() {
        return new _ZodString({
          ...this._def,
          checks: [...this._def.checks, { kind: "trim" }]
        });
      }
      toLowerCase() {
        return new _ZodString({
          ...this._def,
          checks: [...this._def.checks, { kind: "toLowerCase" }]
        });
      }
      toUpperCase() {
        return new _ZodString({
          ...this._def,
          checks: [...this._def.checks, { kind: "toUpperCase" }]
        });
      }
      get isDatetime() {
        return !!this._def.checks.find((ch) => ch.kind === "datetime");
      }
      get isDate() {
        return !!this._def.checks.find((ch) => ch.kind === "date");
      }
      get isTime() {
        return !!this._def.checks.find((ch) => ch.kind === "time");
      }
      get isDuration() {
        return !!this._def.checks.find((ch) => ch.kind === "duration");
      }
      get isEmail() {
        return !!this._def.checks.find((ch) => ch.kind === "email");
      }
      get isURL() {
        return !!this._def.checks.find((ch) => ch.kind === "url");
      }
      get isEmoji() {
        return !!this._def.checks.find((ch) => ch.kind === "emoji");
      }
      get isUUID() {
        return !!this._def.checks.find((ch) => ch.kind === "uuid");
      }
      get isNANOID() {
        return !!this._def.checks.find((ch) => ch.kind === "nanoid");
      }
      get isCUID() {
        return !!this._def.checks.find((ch) => ch.kind === "cuid");
      }
      get isCUID2() {
        return !!this._def.checks.find((ch) => ch.kind === "cuid2");
      }
      get isULID() {
        return !!this._def.checks.find((ch) => ch.kind === "ulid");
      }
      get isIP() {
        return !!this._def.checks.find((ch) => ch.kind === "ip");
      }
      get isCIDR() {
        return !!this._def.checks.find((ch) => ch.kind === "cidr");
      }
      get isBase64() {
        return !!this._def.checks.find((ch) => ch.kind === "base64");
      }
      get isBase64url() {
        return !!this._def.checks.find((ch) => ch.kind === "base64url");
      }
      get minLength() {
        let min = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "min") {
            if (min === null || ch.value > min)
              min = ch.value;
          }
        }
        return min;
      }
      get maxLength() {
        let max = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "max") {
            if (max === null || ch.value < max)
              max = ch.value;
          }
        }
        return max;
      }
    };
    exports.ZodString = ZodString;
    ZodString.create = (params) => {
      return new ZodString({
        checks: [],
        typeName: ZodFirstPartyTypeKind.ZodString,
        coerce: params?.coerce ?? false,
        ...processCreateParams(params)
      });
    };
    function floatSafeRemainder(val, step) {
      const valDecCount = (val.toString().split(".")[1] || "").length;
      const stepDecCount = (step.toString().split(".")[1] || "").length;
      const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
      const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
      const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
      return valInt % stepInt / 10 ** decCount;
    }
    var ZodNumber = class _ZodNumber extends ZodType {
      constructor() {
        super(...arguments);
        this.min = this.gte;
        this.max = this.lte;
        this.step = this.multipleOf;
      }
      _parse(input) {
        if (this._def.coerce) {
          input.data = Number(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== util_js_1.ZodParsedType.number) {
          const ctx2 = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx2, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.number,
            received: ctx2.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        let ctx = void 0;
        const status = new parseUtil_js_1.ParseStatus();
        for (const check of this._def.checks) {
          if (check.kind === "int") {
            if (!util_js_1.util.isInteger(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.invalid_type,
                expected: "integer",
                received: "float",
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "min") {
            const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
            if (tooSmall) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.too_small,
                minimum: check.value,
                type: "number",
                inclusive: check.inclusive,
                exact: false,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "max") {
            const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
            if (tooBig) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.too_big,
                maximum: check.value,
                type: "number",
                inclusive: check.inclusive,
                exact: false,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "multipleOf") {
            if (floatSafeRemainder(input.data, check.value) !== 0) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.not_multiple_of,
                multipleOf: check.value,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "finite") {
            if (!Number.isFinite(input.data)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.not_finite,
                message: check.message
              });
              status.dirty();
            }
          } else {
            util_js_1.util.assertNever(check);
          }
        }
        return { status: status.value, value: input.data };
      }
      gte(value, message) {
        return this.setLimit("min", value, true, errorUtil_js_1.errorUtil.toString(message));
      }
      gt(value, message) {
        return this.setLimit("min", value, false, errorUtil_js_1.errorUtil.toString(message));
      }
      lte(value, message) {
        return this.setLimit("max", value, true, errorUtil_js_1.errorUtil.toString(message));
      }
      lt(value, message) {
        return this.setLimit("max", value, false, errorUtil_js_1.errorUtil.toString(message));
      }
      setLimit(kind, value, inclusive, message) {
        return new _ZodNumber({
          ...this._def,
          checks: [
            ...this._def.checks,
            {
              kind,
              value,
              inclusive,
              message: errorUtil_js_1.errorUtil.toString(message)
            }
          ]
        });
      }
      _addCheck(check) {
        return new _ZodNumber({
          ...this._def,
          checks: [...this._def.checks, check]
        });
      }
      int(message) {
        return this._addCheck({
          kind: "int",
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      positive(message) {
        return this._addCheck({
          kind: "min",
          value: 0,
          inclusive: false,
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      negative(message) {
        return this._addCheck({
          kind: "max",
          value: 0,
          inclusive: false,
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      nonpositive(message) {
        return this._addCheck({
          kind: "max",
          value: 0,
          inclusive: true,
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      nonnegative(message) {
        return this._addCheck({
          kind: "min",
          value: 0,
          inclusive: true,
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      multipleOf(value, message) {
        return this._addCheck({
          kind: "multipleOf",
          value,
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      finite(message) {
        return this._addCheck({
          kind: "finite",
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      safe(message) {
        return this._addCheck({
          kind: "min",
          inclusive: true,
          value: Number.MIN_SAFE_INTEGER,
          message: errorUtil_js_1.errorUtil.toString(message)
        })._addCheck({
          kind: "max",
          inclusive: true,
          value: Number.MAX_SAFE_INTEGER,
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      get minValue() {
        let min = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "min") {
            if (min === null || ch.value > min)
              min = ch.value;
          }
        }
        return min;
      }
      get maxValue() {
        let max = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "max") {
            if (max === null || ch.value < max)
              max = ch.value;
          }
        }
        return max;
      }
      get isInt() {
        return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util_js_1.util.isInteger(ch.value));
      }
      get isFinite() {
        let max = null;
        let min = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
            return true;
          } else if (ch.kind === "min") {
            if (min === null || ch.value > min)
              min = ch.value;
          } else if (ch.kind === "max") {
            if (max === null || ch.value < max)
              max = ch.value;
          }
        }
        return Number.isFinite(min) && Number.isFinite(max);
      }
    };
    exports.ZodNumber = ZodNumber;
    ZodNumber.create = (params) => {
      return new ZodNumber({
        checks: [],
        typeName: ZodFirstPartyTypeKind.ZodNumber,
        coerce: params?.coerce || false,
        ...processCreateParams(params)
      });
    };
    var ZodBigInt = class _ZodBigInt extends ZodType {
      constructor() {
        super(...arguments);
        this.min = this.gte;
        this.max = this.lte;
      }
      _parse(input) {
        if (this._def.coerce) {
          try {
            input.data = BigInt(input.data);
          } catch {
            return this._getInvalidInput(input);
          }
        }
        const parsedType = this._getType(input);
        if (parsedType !== util_js_1.ZodParsedType.bigint) {
          return this._getInvalidInput(input);
        }
        let ctx = void 0;
        const status = new parseUtil_js_1.ParseStatus();
        for (const check of this._def.checks) {
          if (check.kind === "min") {
            const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
            if (tooSmall) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.too_small,
                type: "bigint",
                minimum: check.value,
                inclusive: check.inclusive,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "max") {
            const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
            if (tooBig) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.too_big,
                type: "bigint",
                maximum: check.value,
                inclusive: check.inclusive,
                message: check.message
              });
              status.dirty();
            }
          } else if (check.kind === "multipleOf") {
            if (input.data % check.value !== BigInt(0)) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.not_multiple_of,
                multipleOf: check.value,
                message: check.message
              });
              status.dirty();
            }
          } else {
            util_js_1.util.assertNever(check);
          }
        }
        return { status: status.value, value: input.data };
      }
      _getInvalidInput(input) {
        const ctx = this._getOrReturnCtx(input);
        (0, parseUtil_js_1.addIssueToContext)(ctx, {
          code: ZodError_js_1.ZodIssueCode.invalid_type,
          expected: util_js_1.ZodParsedType.bigint,
          received: ctx.parsedType
        });
        return parseUtil_js_1.INVALID;
      }
      gte(value, message) {
        return this.setLimit("min", value, true, errorUtil_js_1.errorUtil.toString(message));
      }
      gt(value, message) {
        return this.setLimit("min", value, false, errorUtil_js_1.errorUtil.toString(message));
      }
      lte(value, message) {
        return this.setLimit("max", value, true, errorUtil_js_1.errorUtil.toString(message));
      }
      lt(value, message) {
        return this.setLimit("max", value, false, errorUtil_js_1.errorUtil.toString(message));
      }
      setLimit(kind, value, inclusive, message) {
        return new _ZodBigInt({
          ...this._def,
          checks: [
            ...this._def.checks,
            {
              kind,
              value,
              inclusive,
              message: errorUtil_js_1.errorUtil.toString(message)
            }
          ]
        });
      }
      _addCheck(check) {
        return new _ZodBigInt({
          ...this._def,
          checks: [...this._def.checks, check]
        });
      }
      positive(message) {
        return this._addCheck({
          kind: "min",
          value: BigInt(0),
          inclusive: false,
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      negative(message) {
        return this._addCheck({
          kind: "max",
          value: BigInt(0),
          inclusive: false,
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      nonpositive(message) {
        return this._addCheck({
          kind: "max",
          value: BigInt(0),
          inclusive: true,
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      nonnegative(message) {
        return this._addCheck({
          kind: "min",
          value: BigInt(0),
          inclusive: true,
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      multipleOf(value, message) {
        return this._addCheck({
          kind: "multipleOf",
          value,
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      get minValue() {
        let min = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "min") {
            if (min === null || ch.value > min)
              min = ch.value;
          }
        }
        return min;
      }
      get maxValue() {
        let max = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "max") {
            if (max === null || ch.value < max)
              max = ch.value;
          }
        }
        return max;
      }
    };
    exports.ZodBigInt = ZodBigInt;
    ZodBigInt.create = (params) => {
      return new ZodBigInt({
        checks: [],
        typeName: ZodFirstPartyTypeKind.ZodBigInt,
        coerce: params?.coerce ?? false,
        ...processCreateParams(params)
      });
    };
    var ZodBoolean = class extends ZodType {
      _parse(input) {
        if (this._def.coerce) {
          input.data = Boolean(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== util_js_1.ZodParsedType.boolean) {
          const ctx = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.boolean,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        return (0, parseUtil_js_1.OK)(input.data);
      }
    };
    exports.ZodBoolean = ZodBoolean;
    ZodBoolean.create = (params) => {
      return new ZodBoolean({
        typeName: ZodFirstPartyTypeKind.ZodBoolean,
        coerce: params?.coerce || false,
        ...processCreateParams(params)
      });
    };
    var ZodDate = class _ZodDate extends ZodType {
      _parse(input) {
        if (this._def.coerce) {
          input.data = new Date(input.data);
        }
        const parsedType = this._getType(input);
        if (parsedType !== util_js_1.ZodParsedType.date) {
          const ctx2 = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx2, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.date,
            received: ctx2.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        if (Number.isNaN(input.data.getTime())) {
          const ctx2 = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx2, {
            code: ZodError_js_1.ZodIssueCode.invalid_date
          });
          return parseUtil_js_1.INVALID;
        }
        const status = new parseUtil_js_1.ParseStatus();
        let ctx = void 0;
        for (const check of this._def.checks) {
          if (check.kind === "min") {
            if (input.data.getTime() < check.value) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.too_small,
                message: check.message,
                inclusive: true,
                exact: false,
                minimum: check.value,
                type: "date"
              });
              status.dirty();
            }
          } else if (check.kind === "max") {
            if (input.data.getTime() > check.value) {
              ctx = this._getOrReturnCtx(input, ctx);
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.too_big,
                message: check.message,
                inclusive: true,
                exact: false,
                maximum: check.value,
                type: "date"
              });
              status.dirty();
            }
          } else {
            util_js_1.util.assertNever(check);
          }
        }
        return {
          status: status.value,
          value: new Date(input.data.getTime())
        };
      }
      _addCheck(check) {
        return new _ZodDate({
          ...this._def,
          checks: [...this._def.checks, check]
        });
      }
      min(minDate, message) {
        return this._addCheck({
          kind: "min",
          value: minDate.getTime(),
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      max(maxDate, message) {
        return this._addCheck({
          kind: "max",
          value: maxDate.getTime(),
          message: errorUtil_js_1.errorUtil.toString(message)
        });
      }
      get minDate() {
        let min = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "min") {
            if (min === null || ch.value > min)
              min = ch.value;
          }
        }
        return min != null ? new Date(min) : null;
      }
      get maxDate() {
        let max = null;
        for (const ch of this._def.checks) {
          if (ch.kind === "max") {
            if (max === null || ch.value < max)
              max = ch.value;
          }
        }
        return max != null ? new Date(max) : null;
      }
    };
    exports.ZodDate = ZodDate;
    ZodDate.create = (params) => {
      return new ZodDate({
        checks: [],
        coerce: params?.coerce || false,
        typeName: ZodFirstPartyTypeKind.ZodDate,
        ...processCreateParams(params)
      });
    };
    var ZodSymbol = class extends ZodType {
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== util_js_1.ZodParsedType.symbol) {
          const ctx = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.symbol,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        return (0, parseUtil_js_1.OK)(input.data);
      }
    };
    exports.ZodSymbol = ZodSymbol;
    ZodSymbol.create = (params) => {
      return new ZodSymbol({
        typeName: ZodFirstPartyTypeKind.ZodSymbol,
        ...processCreateParams(params)
      });
    };
    var ZodUndefined = class extends ZodType {
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== util_js_1.ZodParsedType.undefined) {
          const ctx = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.undefined,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        return (0, parseUtil_js_1.OK)(input.data);
      }
    };
    exports.ZodUndefined = ZodUndefined;
    ZodUndefined.create = (params) => {
      return new ZodUndefined({
        typeName: ZodFirstPartyTypeKind.ZodUndefined,
        ...processCreateParams(params)
      });
    };
    var ZodNull = class extends ZodType {
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== util_js_1.ZodParsedType.null) {
          const ctx = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.null,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        return (0, parseUtil_js_1.OK)(input.data);
      }
    };
    exports.ZodNull = ZodNull;
    ZodNull.create = (params) => {
      return new ZodNull({
        typeName: ZodFirstPartyTypeKind.ZodNull,
        ...processCreateParams(params)
      });
    };
    var ZodAny = class extends ZodType {
      constructor() {
        super(...arguments);
        this._any = true;
      }
      _parse(input) {
        return (0, parseUtil_js_1.OK)(input.data);
      }
    };
    exports.ZodAny = ZodAny;
    ZodAny.create = (params) => {
      return new ZodAny({
        typeName: ZodFirstPartyTypeKind.ZodAny,
        ...processCreateParams(params)
      });
    };
    var ZodUnknown = class extends ZodType {
      constructor() {
        super(...arguments);
        this._unknown = true;
      }
      _parse(input) {
        return (0, parseUtil_js_1.OK)(input.data);
      }
    };
    exports.ZodUnknown = ZodUnknown;
    ZodUnknown.create = (params) => {
      return new ZodUnknown({
        typeName: ZodFirstPartyTypeKind.ZodUnknown,
        ...processCreateParams(params)
      });
    };
    var ZodNever = class extends ZodType {
      _parse(input) {
        const ctx = this._getOrReturnCtx(input);
        (0, parseUtil_js_1.addIssueToContext)(ctx, {
          code: ZodError_js_1.ZodIssueCode.invalid_type,
          expected: util_js_1.ZodParsedType.never,
          received: ctx.parsedType
        });
        return parseUtil_js_1.INVALID;
      }
    };
    exports.ZodNever = ZodNever;
    ZodNever.create = (params) => {
      return new ZodNever({
        typeName: ZodFirstPartyTypeKind.ZodNever,
        ...processCreateParams(params)
      });
    };
    var ZodVoid = class extends ZodType {
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== util_js_1.ZodParsedType.undefined) {
          const ctx = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.void,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        return (0, parseUtil_js_1.OK)(input.data);
      }
    };
    exports.ZodVoid = ZodVoid;
    ZodVoid.create = (params) => {
      return new ZodVoid({
        typeName: ZodFirstPartyTypeKind.ZodVoid,
        ...processCreateParams(params)
      });
    };
    var ZodArray = class _ZodArray extends ZodType {
      _parse(input) {
        const { ctx, status } = this._processInputParams(input);
        const def = this._def;
        if (ctx.parsedType !== util_js_1.ZodParsedType.array) {
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.array,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        if (def.exactLength !== null) {
          const tooBig = ctx.data.length > def.exactLength.value;
          const tooSmall = ctx.data.length < def.exactLength.value;
          if (tooBig || tooSmall) {
            (0, parseUtil_js_1.addIssueToContext)(ctx, {
              code: tooBig ? ZodError_js_1.ZodIssueCode.too_big : ZodError_js_1.ZodIssueCode.too_small,
              minimum: tooSmall ? def.exactLength.value : void 0,
              maximum: tooBig ? def.exactLength.value : void 0,
              type: "array",
              inclusive: true,
              exact: true,
              message: def.exactLength.message
            });
            status.dirty();
          }
        }
        if (def.minLength !== null) {
          if (ctx.data.length < def.minLength.value) {
            (0, parseUtil_js_1.addIssueToContext)(ctx, {
              code: ZodError_js_1.ZodIssueCode.too_small,
              minimum: def.minLength.value,
              type: "array",
              inclusive: true,
              exact: false,
              message: def.minLength.message
            });
            status.dirty();
          }
        }
        if (def.maxLength !== null) {
          if (ctx.data.length > def.maxLength.value) {
            (0, parseUtil_js_1.addIssueToContext)(ctx, {
              code: ZodError_js_1.ZodIssueCode.too_big,
              maximum: def.maxLength.value,
              type: "array",
              inclusive: true,
              exact: false,
              message: def.maxLength.message
            });
            status.dirty();
          }
        }
        if (ctx.common.async) {
          return Promise.all([...ctx.data].map((item, i) => {
            return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
          })).then((result2) => {
            return parseUtil_js_1.ParseStatus.mergeArray(status, result2);
          });
        }
        const result = [...ctx.data].map((item, i) => {
          return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
        });
        return parseUtil_js_1.ParseStatus.mergeArray(status, result);
      }
      get element() {
        return this._def.type;
      }
      min(minLength, message) {
        return new _ZodArray({
          ...this._def,
          minLength: { value: minLength, message: errorUtil_js_1.errorUtil.toString(message) }
        });
      }
      max(maxLength, message) {
        return new _ZodArray({
          ...this._def,
          maxLength: { value: maxLength, message: errorUtil_js_1.errorUtil.toString(message) }
        });
      }
      length(len, message) {
        return new _ZodArray({
          ...this._def,
          exactLength: { value: len, message: errorUtil_js_1.errorUtil.toString(message) }
        });
      }
      nonempty(message) {
        return this.min(1, message);
      }
    };
    exports.ZodArray = ZodArray;
    ZodArray.create = (schema, params) => {
      return new ZodArray({
        type: schema,
        minLength: null,
        maxLength: null,
        exactLength: null,
        typeName: ZodFirstPartyTypeKind.ZodArray,
        ...processCreateParams(params)
      });
    };
    function deepPartialify(schema) {
      if (schema instanceof ZodObject) {
        const newShape = {};
        for (const key in schema.shape) {
          const fieldSchema = schema.shape[key];
          newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
        }
        return new ZodObject({
          ...schema._def,
          shape: () => newShape
        });
      } else if (schema instanceof ZodArray) {
        return new ZodArray({
          ...schema._def,
          type: deepPartialify(schema.element)
        });
      } else if (schema instanceof ZodOptional) {
        return ZodOptional.create(deepPartialify(schema.unwrap()));
      } else if (schema instanceof ZodNullable) {
        return ZodNullable.create(deepPartialify(schema.unwrap()));
      } else if (schema instanceof ZodTuple) {
        return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
      } else {
        return schema;
      }
    }
    var ZodObject = class _ZodObject extends ZodType {
      constructor() {
        super(...arguments);
        this._cached = null;
        this.nonstrict = this.passthrough;
        this.augment = this.extend;
      }
      _getCached() {
        if (this._cached !== null)
          return this._cached;
        const shape = this._def.shape();
        const keys = util_js_1.util.objectKeys(shape);
        this._cached = { shape, keys };
        return this._cached;
      }
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== util_js_1.ZodParsedType.object) {
          const ctx2 = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx2, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.object,
            received: ctx2.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        const { status, ctx } = this._processInputParams(input);
        const { shape, keys: shapeKeys } = this._getCached();
        const extraKeys = [];
        if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
          for (const key in ctx.data) {
            if (!shapeKeys.includes(key)) {
              extraKeys.push(key);
            }
          }
        }
        const pairs = [];
        for (const key of shapeKeys) {
          const keyValidator = shape[key];
          const value = ctx.data[key];
          pairs.push({
            key: { status: "valid", value: key },
            value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
            alwaysSet: key in ctx.data
          });
        }
        if (this._def.catchall instanceof ZodNever) {
          const unknownKeys = this._def.unknownKeys;
          if (unknownKeys === "passthrough") {
            for (const key of extraKeys) {
              pairs.push({
                key: { status: "valid", value: key },
                value: { status: "valid", value: ctx.data[key] }
              });
            }
          } else if (unknownKeys === "strict") {
            if (extraKeys.length > 0) {
              (0, parseUtil_js_1.addIssueToContext)(ctx, {
                code: ZodError_js_1.ZodIssueCode.unrecognized_keys,
                keys: extraKeys
              });
              status.dirty();
            }
          } else if (unknownKeys === "strip") {
          } else {
            throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
          }
        } else {
          const catchall = this._def.catchall;
          for (const key of extraKeys) {
            const value = ctx.data[key];
            pairs.push({
              key: { status: "valid", value: key },
              value: catchall._parse(
                new ParseInputLazyPath(ctx, value, ctx.path, key)
                //, ctx.child(key), value, getParsedType(value)
              ),
              alwaysSet: key in ctx.data
            });
          }
        }
        if (ctx.common.async) {
          return Promise.resolve().then(async () => {
            const syncPairs = [];
            for (const pair of pairs) {
              const key = await pair.key;
              const value = await pair.value;
              syncPairs.push({
                key,
                value,
                alwaysSet: pair.alwaysSet
              });
            }
            return syncPairs;
          }).then((syncPairs) => {
            return parseUtil_js_1.ParseStatus.mergeObjectSync(status, syncPairs);
          });
        } else {
          return parseUtil_js_1.ParseStatus.mergeObjectSync(status, pairs);
        }
      }
      get shape() {
        return this._def.shape();
      }
      strict(message) {
        errorUtil_js_1.errorUtil.errToObj;
        return new _ZodObject({
          ...this._def,
          unknownKeys: "strict",
          ...message !== void 0 ? {
            errorMap: (issue, ctx) => {
              const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
              if (issue.code === "unrecognized_keys")
                return {
                  message: errorUtil_js_1.errorUtil.errToObj(message).message ?? defaultError
                };
              return {
                message: defaultError
              };
            }
          } : {}
        });
      }
      strip() {
        return new _ZodObject({
          ...this._def,
          unknownKeys: "strip"
        });
      }
      passthrough() {
        return new _ZodObject({
          ...this._def,
          unknownKeys: "passthrough"
        });
      }
      // const AugmentFactory =
      //   <Def extends ZodObjectDef>(def: Def) =>
      //   <Augmentation extends ZodRawShape>(
      //     augmentation: Augmentation
      //   ): ZodObject<
      //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
      //     Def["unknownKeys"],
      //     Def["catchall"]
      //   > => {
      //     return new ZodObject({
      //       ...def,
      //       shape: () => ({
      //         ...def.shape(),
      //         ...augmentation,
      //       }),
      //     }) as any;
      //   };
      extend(augmentation) {
        return new _ZodObject({
          ...this._def,
          shape: () => ({
            ...this._def.shape(),
            ...augmentation
          })
        });
      }
      /**
       * Prior to zod@1.0.12 there was a bug in the
       * inferred type of merged objects. Please
       * upgrade if you are experiencing issues.
       */
      merge(merging) {
        const merged = new _ZodObject({
          unknownKeys: merging._def.unknownKeys,
          catchall: merging._def.catchall,
          shape: () => ({
            ...this._def.shape(),
            ...merging._def.shape()
          }),
          typeName: ZodFirstPartyTypeKind.ZodObject
        });
        return merged;
      }
      // merge<
      //   Incoming extends AnyZodObject,
      //   Augmentation extends Incoming["shape"],
      //   NewOutput extends {
      //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
      //       ? Augmentation[k]["_output"]
      //       : k extends keyof Output
      //       ? Output[k]
      //       : never;
      //   },
      //   NewInput extends {
      //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
      //       ? Augmentation[k]["_input"]
      //       : k extends keyof Input
      //       ? Input[k]
      //       : never;
      //   }
      // >(
      //   merging: Incoming
      // ): ZodObject<
      //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
      //   Incoming["_def"]["unknownKeys"],
      //   Incoming["_def"]["catchall"],
      //   NewOutput,
      //   NewInput
      // > {
      //   const merged: any = new ZodObject({
      //     unknownKeys: merging._def.unknownKeys,
      //     catchall: merging._def.catchall,
      //     shape: () =>
      //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
      //     typeName: ZodFirstPartyTypeKind.ZodObject,
      //   }) as any;
      //   return merged;
      // }
      setKey(key, schema) {
        return this.augment({ [key]: schema });
      }
      // merge<Incoming extends AnyZodObject>(
      //   merging: Incoming
      // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
      // ZodObject<
      //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
      //   Incoming["_def"]["unknownKeys"],
      //   Incoming["_def"]["catchall"]
      // > {
      //   // const mergedShape = objectUtil.mergeShapes(
      //   //   this._def.shape(),
      //   //   merging._def.shape()
      //   // );
      //   const merged: any = new ZodObject({
      //     unknownKeys: merging._def.unknownKeys,
      //     catchall: merging._def.catchall,
      //     shape: () =>
      //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
      //     typeName: ZodFirstPartyTypeKind.ZodObject,
      //   }) as any;
      //   return merged;
      // }
      catchall(index) {
        return new _ZodObject({
          ...this._def,
          catchall: index
        });
      }
      pick(mask) {
        const shape = {};
        for (const key of util_js_1.util.objectKeys(mask)) {
          if (mask[key] && this.shape[key]) {
            shape[key] = this.shape[key];
          }
        }
        return new _ZodObject({
          ...this._def,
          shape: () => shape
        });
      }
      omit(mask) {
        const shape = {};
        for (const key of util_js_1.util.objectKeys(this.shape)) {
          if (!mask[key]) {
            shape[key] = this.shape[key];
          }
        }
        return new _ZodObject({
          ...this._def,
          shape: () => shape
        });
      }
      /**
       * @deprecated
       */
      deepPartial() {
        return deepPartialify(this);
      }
      partial(mask) {
        const newShape = {};
        for (const key of util_js_1.util.objectKeys(this.shape)) {
          const fieldSchema = this.shape[key];
          if (mask && !mask[key]) {
            newShape[key] = fieldSchema;
          } else {
            newShape[key] = fieldSchema.optional();
          }
        }
        return new _ZodObject({
          ...this._def,
          shape: () => newShape
        });
      }
      required(mask) {
        const newShape = {};
        for (const key of util_js_1.util.objectKeys(this.shape)) {
          if (mask && !mask[key]) {
            newShape[key] = this.shape[key];
          } else {
            const fieldSchema = this.shape[key];
            let newField = fieldSchema;
            while (newField instanceof ZodOptional) {
              newField = newField._def.innerType;
            }
            newShape[key] = newField;
          }
        }
        return new _ZodObject({
          ...this._def,
          shape: () => newShape
        });
      }
      keyof() {
        return createZodEnum(util_js_1.util.objectKeys(this.shape));
      }
    };
    exports.ZodObject = ZodObject;
    ZodObject.create = (shape, params) => {
      return new ZodObject({
        shape: () => shape,
        unknownKeys: "strip",
        catchall: ZodNever.create(),
        typeName: ZodFirstPartyTypeKind.ZodObject,
        ...processCreateParams(params)
      });
    };
    ZodObject.strictCreate = (shape, params) => {
      return new ZodObject({
        shape: () => shape,
        unknownKeys: "strict",
        catchall: ZodNever.create(),
        typeName: ZodFirstPartyTypeKind.ZodObject,
        ...processCreateParams(params)
      });
    };
    ZodObject.lazycreate = (shape, params) => {
      return new ZodObject({
        shape,
        unknownKeys: "strip",
        catchall: ZodNever.create(),
        typeName: ZodFirstPartyTypeKind.ZodObject,
        ...processCreateParams(params)
      });
    };
    var ZodUnion = class extends ZodType {
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        const options = this._def.options;
        function handleResults(results) {
          for (const result of results) {
            if (result.result.status === "valid") {
              return result.result;
            }
          }
          for (const result of results) {
            if (result.result.status === "dirty") {
              ctx.common.issues.push(...result.ctx.common.issues);
              return result.result;
            }
          }
          const unionErrors = results.map((result) => new ZodError_js_1.ZodError(result.ctx.common.issues));
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_union,
            unionErrors
          });
          return parseUtil_js_1.INVALID;
        }
        if (ctx.common.async) {
          return Promise.all(options.map(async (option) => {
            const childCtx = {
              ...ctx,
              common: {
                ...ctx.common,
                issues: []
              },
              parent: null
            };
            return {
              result: await option._parseAsync({
                data: ctx.data,
                path: ctx.path,
                parent: childCtx
              }),
              ctx: childCtx
            };
          })).then(handleResults);
        } else {
          let dirty = void 0;
          const issues = [];
          for (const option of options) {
            const childCtx = {
              ...ctx,
              common: {
                ...ctx.common,
                issues: []
              },
              parent: null
            };
            const result = option._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: childCtx
            });
            if (result.status === "valid") {
              return result;
            } else if (result.status === "dirty" && !dirty) {
              dirty = { result, ctx: childCtx };
            }
            if (childCtx.common.issues.length) {
              issues.push(childCtx.common.issues);
            }
          }
          if (dirty) {
            ctx.common.issues.push(...dirty.ctx.common.issues);
            return dirty.result;
          }
          const unionErrors = issues.map((issues2) => new ZodError_js_1.ZodError(issues2));
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_union,
            unionErrors
          });
          return parseUtil_js_1.INVALID;
        }
      }
      get options() {
        return this._def.options;
      }
    };
    exports.ZodUnion = ZodUnion;
    ZodUnion.create = (types, params) => {
      return new ZodUnion({
        options: types,
        typeName: ZodFirstPartyTypeKind.ZodUnion,
        ...processCreateParams(params)
      });
    };
    var getDiscriminator = (type) => {
      if (type instanceof ZodLazy) {
        return getDiscriminator(type.schema);
      } else if (type instanceof ZodEffects) {
        return getDiscriminator(type.innerType());
      } else if (type instanceof ZodLiteral) {
        return [type.value];
      } else if (type instanceof ZodEnum) {
        return type.options;
      } else if (type instanceof ZodNativeEnum) {
        return util_js_1.util.objectValues(type.enum);
      } else if (type instanceof ZodDefault) {
        return getDiscriminator(type._def.innerType);
      } else if (type instanceof ZodUndefined) {
        return [void 0];
      } else if (type instanceof ZodNull) {
        return [null];
      } else if (type instanceof ZodOptional) {
        return [void 0, ...getDiscriminator(type.unwrap())];
      } else if (type instanceof ZodNullable) {
        return [null, ...getDiscriminator(type.unwrap())];
      } else if (type instanceof ZodBranded) {
        return getDiscriminator(type.unwrap());
      } else if (type instanceof ZodReadonly) {
        return getDiscriminator(type.unwrap());
      } else if (type instanceof ZodCatch) {
        return getDiscriminator(type._def.innerType);
      } else {
        return [];
      }
    };
    var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        if (ctx.parsedType !== util_js_1.ZodParsedType.object) {
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.object,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        const discriminator = this.discriminator;
        const discriminatorValue = ctx.data[discriminator];
        const option = this.optionsMap.get(discriminatorValue);
        if (!option) {
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_union_discriminator,
            options: Array.from(this.optionsMap.keys()),
            path: [discriminator]
          });
          return parseUtil_js_1.INVALID;
        }
        if (ctx.common.async) {
          return option._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
        } else {
          return option._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
        }
      }
      get discriminator() {
        return this._def.discriminator;
      }
      get options() {
        return this._def.options;
      }
      get optionsMap() {
        return this._def.optionsMap;
      }
      /**
       * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
       * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
       * have a different value for each object in the union.
       * @param discriminator the name of the discriminator property
       * @param types an array of object schemas
       * @param params
       */
      static create(discriminator, options, params) {
        const optionsMap = /* @__PURE__ */ new Map();
        for (const type of options) {
          const discriminatorValues = getDiscriminator(type.shape[discriminator]);
          if (!discriminatorValues.length) {
            throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
          }
          for (const value of discriminatorValues) {
            if (optionsMap.has(value)) {
              throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
            }
            optionsMap.set(value, type);
          }
        }
        return new _ZodDiscriminatedUnion({
          typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
          discriminator,
          options,
          optionsMap,
          ...processCreateParams(params)
        });
      }
    };
    exports.ZodDiscriminatedUnion = ZodDiscriminatedUnion;
    function mergeValues(a, b) {
      const aType = (0, util_js_1.getParsedType)(a);
      const bType = (0, util_js_1.getParsedType)(b);
      if (a === b) {
        return { valid: true, data: a };
      } else if (aType === util_js_1.ZodParsedType.object && bType === util_js_1.ZodParsedType.object) {
        const bKeys = util_js_1.util.objectKeys(b);
        const sharedKeys = util_js_1.util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
        const newObj = { ...a, ...b };
        for (const key of sharedKeys) {
          const sharedValue = mergeValues(a[key], b[key]);
          if (!sharedValue.valid) {
            return { valid: false };
          }
          newObj[key] = sharedValue.data;
        }
        return { valid: true, data: newObj };
      } else if (aType === util_js_1.ZodParsedType.array && bType === util_js_1.ZodParsedType.array) {
        if (a.length !== b.length) {
          return { valid: false };
        }
        const newArray = [];
        for (let index = 0; index < a.length; index++) {
          const itemA = a[index];
          const itemB = b[index];
          const sharedValue = mergeValues(itemA, itemB);
          if (!sharedValue.valid) {
            return { valid: false };
          }
          newArray.push(sharedValue.data);
        }
        return { valid: true, data: newArray };
      } else if (aType === util_js_1.ZodParsedType.date && bType === util_js_1.ZodParsedType.date && +a === +b) {
        return { valid: true, data: a };
      } else {
        return { valid: false };
      }
    }
    var ZodIntersection = class extends ZodType {
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        const handleParsed = (parsedLeft, parsedRight) => {
          if ((0, parseUtil_js_1.isAborted)(parsedLeft) || (0, parseUtil_js_1.isAborted)(parsedRight)) {
            return parseUtil_js_1.INVALID;
          }
          const merged = mergeValues(parsedLeft.value, parsedRight.value);
          if (!merged.valid) {
            (0, parseUtil_js_1.addIssueToContext)(ctx, {
              code: ZodError_js_1.ZodIssueCode.invalid_intersection_types
            });
            return parseUtil_js_1.INVALID;
          }
          if ((0, parseUtil_js_1.isDirty)(parsedLeft) || (0, parseUtil_js_1.isDirty)(parsedRight)) {
            status.dirty();
          }
          return { status: status.value, value: merged.data };
        };
        if (ctx.common.async) {
          return Promise.all([
            this._def.left._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            }),
            this._def.right._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            })
          ]).then(([left, right]) => handleParsed(left, right));
        } else {
          return handleParsed(this._def.left._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }), this._def.right._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }));
        }
      }
    };
    exports.ZodIntersection = ZodIntersection;
    ZodIntersection.create = (left, right, params) => {
      return new ZodIntersection({
        left,
        right,
        typeName: ZodFirstPartyTypeKind.ZodIntersection,
        ...processCreateParams(params)
      });
    };
    var ZodTuple = class _ZodTuple extends ZodType {
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== util_js_1.ZodParsedType.array) {
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.array,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        if (ctx.data.length < this._def.items.length) {
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.too_small,
            minimum: this._def.items.length,
            inclusive: true,
            exact: false,
            type: "array"
          });
          return parseUtil_js_1.INVALID;
        }
        const rest = this._def.rest;
        if (!rest && ctx.data.length > this._def.items.length) {
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.too_big,
            maximum: this._def.items.length,
            inclusive: true,
            exact: false,
            type: "array"
          });
          status.dirty();
        }
        const items = [...ctx.data].map((item, itemIndex) => {
          const schema = this._def.items[itemIndex] || this._def.rest;
          if (!schema)
            return null;
          return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
        }).filter((x) => !!x);
        if (ctx.common.async) {
          return Promise.all(items).then((results) => {
            return parseUtil_js_1.ParseStatus.mergeArray(status, results);
          });
        } else {
          return parseUtil_js_1.ParseStatus.mergeArray(status, items);
        }
      }
      get items() {
        return this._def.items;
      }
      rest(rest) {
        return new _ZodTuple({
          ...this._def,
          rest
        });
      }
    };
    exports.ZodTuple = ZodTuple;
    ZodTuple.create = (schemas, params) => {
      if (!Array.isArray(schemas)) {
        throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
      }
      return new ZodTuple({
        items: schemas,
        typeName: ZodFirstPartyTypeKind.ZodTuple,
        rest: null,
        ...processCreateParams(params)
      });
    };
    var ZodRecord = class _ZodRecord extends ZodType {
      get keySchema() {
        return this._def.keyType;
      }
      get valueSchema() {
        return this._def.valueType;
      }
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== util_js_1.ZodParsedType.object) {
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.object,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        const pairs = [];
        const keyType = this._def.keyType;
        const valueType = this._def.valueType;
        for (const key in ctx.data) {
          pairs.push({
            key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
            value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
            alwaysSet: key in ctx.data
          });
        }
        if (ctx.common.async) {
          return parseUtil_js_1.ParseStatus.mergeObjectAsync(status, pairs);
        } else {
          return parseUtil_js_1.ParseStatus.mergeObjectSync(status, pairs);
        }
      }
      get element() {
        return this._def.valueType;
      }
      static create(first, second, third) {
        if (second instanceof ZodType) {
          return new _ZodRecord({
            keyType: first,
            valueType: second,
            typeName: ZodFirstPartyTypeKind.ZodRecord,
            ...processCreateParams(third)
          });
        }
        return new _ZodRecord({
          keyType: ZodString.create(),
          valueType: first,
          typeName: ZodFirstPartyTypeKind.ZodRecord,
          ...processCreateParams(second)
        });
      }
    };
    exports.ZodRecord = ZodRecord;
    var ZodMap = class extends ZodType {
      get keySchema() {
        return this._def.keyType;
      }
      get valueSchema() {
        return this._def.valueType;
      }
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== util_js_1.ZodParsedType.map) {
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.map,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        const keyType = this._def.keyType;
        const valueType = this._def.valueType;
        const pairs = [...ctx.data.entries()].map(([key, value], index) => {
          return {
            key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
            value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
          };
        });
        if (ctx.common.async) {
          const finalMap = /* @__PURE__ */ new Map();
          return Promise.resolve().then(async () => {
            for (const pair of pairs) {
              const key = await pair.key;
              const value = await pair.value;
              if (key.status === "aborted" || value.status === "aborted") {
                return parseUtil_js_1.INVALID;
              }
              if (key.status === "dirty" || value.status === "dirty") {
                status.dirty();
              }
              finalMap.set(key.value, value.value);
            }
            return { status: status.value, value: finalMap };
          });
        } else {
          const finalMap = /* @__PURE__ */ new Map();
          for (const pair of pairs) {
            const key = pair.key;
            const value = pair.value;
            if (key.status === "aborted" || value.status === "aborted") {
              return parseUtil_js_1.INVALID;
            }
            if (key.status === "dirty" || value.status === "dirty") {
              status.dirty();
            }
            finalMap.set(key.value, value.value);
          }
          return { status: status.value, value: finalMap };
        }
      }
    };
    exports.ZodMap = ZodMap;
    ZodMap.create = (keyType, valueType, params) => {
      return new ZodMap({
        valueType,
        keyType,
        typeName: ZodFirstPartyTypeKind.ZodMap,
        ...processCreateParams(params)
      });
    };
    var ZodSet = class _ZodSet extends ZodType {
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.parsedType !== util_js_1.ZodParsedType.set) {
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.set,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        const def = this._def;
        if (def.minSize !== null) {
          if (ctx.data.size < def.minSize.value) {
            (0, parseUtil_js_1.addIssueToContext)(ctx, {
              code: ZodError_js_1.ZodIssueCode.too_small,
              minimum: def.minSize.value,
              type: "set",
              inclusive: true,
              exact: false,
              message: def.minSize.message
            });
            status.dirty();
          }
        }
        if (def.maxSize !== null) {
          if (ctx.data.size > def.maxSize.value) {
            (0, parseUtil_js_1.addIssueToContext)(ctx, {
              code: ZodError_js_1.ZodIssueCode.too_big,
              maximum: def.maxSize.value,
              type: "set",
              inclusive: true,
              exact: false,
              message: def.maxSize.message
            });
            status.dirty();
          }
        }
        const valueType = this._def.valueType;
        function finalizeSet(elements2) {
          const parsedSet = /* @__PURE__ */ new Set();
          for (const element of elements2) {
            if (element.status === "aborted")
              return parseUtil_js_1.INVALID;
            if (element.status === "dirty")
              status.dirty();
            parsedSet.add(element.value);
          }
          return { status: status.value, value: parsedSet };
        }
        const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
        if (ctx.common.async) {
          return Promise.all(elements).then((elements2) => finalizeSet(elements2));
        } else {
          return finalizeSet(elements);
        }
      }
      min(minSize, message) {
        return new _ZodSet({
          ...this._def,
          minSize: { value: minSize, message: errorUtil_js_1.errorUtil.toString(message) }
        });
      }
      max(maxSize, message) {
        return new _ZodSet({
          ...this._def,
          maxSize: { value: maxSize, message: errorUtil_js_1.errorUtil.toString(message) }
        });
      }
      size(size, message) {
        return this.min(size, message).max(size, message);
      }
      nonempty(message) {
        return this.min(1, message);
      }
    };
    exports.ZodSet = ZodSet;
    ZodSet.create = (valueType, params) => {
      return new ZodSet({
        valueType,
        minSize: null,
        maxSize: null,
        typeName: ZodFirstPartyTypeKind.ZodSet,
        ...processCreateParams(params)
      });
    };
    var ZodFunction = class _ZodFunction extends ZodType {
      constructor() {
        super(...arguments);
        this.validate = this.implement;
      }
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        if (ctx.parsedType !== util_js_1.ZodParsedType.function) {
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.function,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        function makeArgsIssue(args2, error) {
          return (0, parseUtil_js_1.makeIssue)({
            data: args2,
            path: ctx.path,
            errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, (0, errors_js_1.getErrorMap)(), errors_js_1.defaultErrorMap].filter((x) => !!x),
            issueData: {
              code: ZodError_js_1.ZodIssueCode.invalid_arguments,
              argumentsError: error
            }
          });
        }
        function makeReturnsIssue(returns, error) {
          return (0, parseUtil_js_1.makeIssue)({
            data: returns,
            path: ctx.path,
            errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, (0, errors_js_1.getErrorMap)(), errors_js_1.defaultErrorMap].filter((x) => !!x),
            issueData: {
              code: ZodError_js_1.ZodIssueCode.invalid_return_type,
              returnTypeError: error
            }
          });
        }
        const params = { errorMap: ctx.common.contextualErrorMap };
        const fn = ctx.data;
        if (this._def.returns instanceof ZodPromise) {
          const me = this;
          return (0, parseUtil_js_1.OK)(async function(...args2) {
            const error = new ZodError_js_1.ZodError([]);
            const parsedArgs = await me._def.args.parseAsync(args2, params).catch((e) => {
              error.addIssue(makeArgsIssue(args2, e));
              throw error;
            });
            const result = await Reflect.apply(fn, this, parsedArgs);
            const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
              error.addIssue(makeReturnsIssue(result, e));
              throw error;
            });
            return parsedReturns;
          });
        } else {
          const me = this;
          return (0, parseUtil_js_1.OK)(function(...args2) {
            const parsedArgs = me._def.args.safeParse(args2, params);
            if (!parsedArgs.success) {
              throw new ZodError_js_1.ZodError([makeArgsIssue(args2, parsedArgs.error)]);
            }
            const result = Reflect.apply(fn, this, parsedArgs.data);
            const parsedReturns = me._def.returns.safeParse(result, params);
            if (!parsedReturns.success) {
              throw new ZodError_js_1.ZodError([makeReturnsIssue(result, parsedReturns.error)]);
            }
            return parsedReturns.data;
          });
        }
      }
      parameters() {
        return this._def.args;
      }
      returnType() {
        return this._def.returns;
      }
      args(...items) {
        return new _ZodFunction({
          ...this._def,
          args: ZodTuple.create(items).rest(ZodUnknown.create())
        });
      }
      returns(returnType) {
        return new _ZodFunction({
          ...this._def,
          returns: returnType
        });
      }
      implement(func) {
        const validatedFunc = this.parse(func);
        return validatedFunc;
      }
      strictImplement(func) {
        const validatedFunc = this.parse(func);
        return validatedFunc;
      }
      static create(args2, returns, params) {
        return new _ZodFunction({
          args: args2 ? args2 : ZodTuple.create([]).rest(ZodUnknown.create()),
          returns: returns || ZodUnknown.create(),
          typeName: ZodFirstPartyTypeKind.ZodFunction,
          ...processCreateParams(params)
        });
      }
    };
    exports.ZodFunction = ZodFunction;
    var ZodLazy = class extends ZodType {
      get schema() {
        return this._def.getter();
      }
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        const lazySchema = this._def.getter();
        return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
      }
    };
    exports.ZodLazy = ZodLazy;
    ZodLazy.create = (getter, params) => {
      return new ZodLazy({
        getter,
        typeName: ZodFirstPartyTypeKind.ZodLazy,
        ...processCreateParams(params)
      });
    };
    var ZodLiteral = class extends ZodType {
      _parse(input) {
        if (input.data !== this._def.value) {
          const ctx = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            received: ctx.data,
            code: ZodError_js_1.ZodIssueCode.invalid_literal,
            expected: this._def.value
          });
          return parseUtil_js_1.INVALID;
        }
        return { status: "valid", value: input.data };
      }
      get value() {
        return this._def.value;
      }
    };
    exports.ZodLiteral = ZodLiteral;
    ZodLiteral.create = (value, params) => {
      return new ZodLiteral({
        value,
        typeName: ZodFirstPartyTypeKind.ZodLiteral,
        ...processCreateParams(params)
      });
    };
    function createZodEnum(values, params) {
      return new ZodEnum({
        values,
        typeName: ZodFirstPartyTypeKind.ZodEnum,
        ...processCreateParams(params)
      });
    }
    var ZodEnum = class _ZodEnum extends ZodType {
      _parse(input) {
        if (typeof input.data !== "string") {
          const ctx = this._getOrReturnCtx(input);
          const expectedValues = this._def.values;
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            expected: util_js_1.util.joinValues(expectedValues),
            received: ctx.parsedType,
            code: ZodError_js_1.ZodIssueCode.invalid_type
          });
          return parseUtil_js_1.INVALID;
        }
        if (!this._cache) {
          this._cache = new Set(this._def.values);
        }
        if (!this._cache.has(input.data)) {
          const ctx = this._getOrReturnCtx(input);
          const expectedValues = this._def.values;
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            received: ctx.data,
            code: ZodError_js_1.ZodIssueCode.invalid_enum_value,
            options: expectedValues
          });
          return parseUtil_js_1.INVALID;
        }
        return (0, parseUtil_js_1.OK)(input.data);
      }
      get options() {
        return this._def.values;
      }
      get enum() {
        const enumValues = {};
        for (const val of this._def.values) {
          enumValues[val] = val;
        }
        return enumValues;
      }
      get Values() {
        const enumValues = {};
        for (const val of this._def.values) {
          enumValues[val] = val;
        }
        return enumValues;
      }
      get Enum() {
        const enumValues = {};
        for (const val of this._def.values) {
          enumValues[val] = val;
        }
        return enumValues;
      }
      extract(values, newDef = this._def) {
        return _ZodEnum.create(values, {
          ...this._def,
          ...newDef
        });
      }
      exclude(values, newDef = this._def) {
        return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
          ...this._def,
          ...newDef
        });
      }
    };
    exports.ZodEnum = ZodEnum;
    ZodEnum.create = createZodEnum;
    var ZodNativeEnum = class extends ZodType {
      _parse(input) {
        const nativeEnumValues = util_js_1.util.getValidEnumValues(this._def.values);
        const ctx = this._getOrReturnCtx(input);
        if (ctx.parsedType !== util_js_1.ZodParsedType.string && ctx.parsedType !== util_js_1.ZodParsedType.number) {
          const expectedValues = util_js_1.util.objectValues(nativeEnumValues);
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            expected: util_js_1.util.joinValues(expectedValues),
            received: ctx.parsedType,
            code: ZodError_js_1.ZodIssueCode.invalid_type
          });
          return parseUtil_js_1.INVALID;
        }
        if (!this._cache) {
          this._cache = new Set(util_js_1.util.getValidEnumValues(this._def.values));
        }
        if (!this._cache.has(input.data)) {
          const expectedValues = util_js_1.util.objectValues(nativeEnumValues);
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            received: ctx.data,
            code: ZodError_js_1.ZodIssueCode.invalid_enum_value,
            options: expectedValues
          });
          return parseUtil_js_1.INVALID;
        }
        return (0, parseUtil_js_1.OK)(input.data);
      }
      get enum() {
        return this._def.values;
      }
    };
    exports.ZodNativeEnum = ZodNativeEnum;
    ZodNativeEnum.create = (values, params) => {
      return new ZodNativeEnum({
        values,
        typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
        ...processCreateParams(params)
      });
    };
    var ZodPromise = class extends ZodType {
      unwrap() {
        return this._def.type;
      }
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        if (ctx.parsedType !== util_js_1.ZodParsedType.promise && ctx.common.async === false) {
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.promise,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        const promisified = ctx.parsedType === util_js_1.ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
        return (0, parseUtil_js_1.OK)(promisified.then((data) => {
          return this._def.type.parseAsync(data, {
            path: ctx.path,
            errorMap: ctx.common.contextualErrorMap
          });
        }));
      }
    };
    exports.ZodPromise = ZodPromise;
    ZodPromise.create = (schema, params) => {
      return new ZodPromise({
        type: schema,
        typeName: ZodFirstPartyTypeKind.ZodPromise,
        ...processCreateParams(params)
      });
    };
    var ZodEffects = class extends ZodType {
      innerType() {
        return this._def.schema;
      }
      sourceType() {
        return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
      }
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        const effect = this._def.effect || null;
        const checkCtx = {
          addIssue: (arg) => {
            (0, parseUtil_js_1.addIssueToContext)(ctx, arg);
            if (arg.fatal) {
              status.abort();
            } else {
              status.dirty();
            }
          },
          get path() {
            return ctx.path;
          }
        };
        checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
        if (effect.type === "preprocess") {
          const processed = effect.transform(ctx.data, checkCtx);
          if (ctx.common.async) {
            return Promise.resolve(processed).then(async (processed2) => {
              if (status.value === "aborted")
                return parseUtil_js_1.INVALID;
              const result = await this._def.schema._parseAsync({
                data: processed2,
                path: ctx.path,
                parent: ctx
              });
              if (result.status === "aborted")
                return parseUtil_js_1.INVALID;
              if (result.status === "dirty")
                return (0, parseUtil_js_1.DIRTY)(result.value);
              if (status.value === "dirty")
                return (0, parseUtil_js_1.DIRTY)(result.value);
              return result;
            });
          } else {
            if (status.value === "aborted")
              return parseUtil_js_1.INVALID;
            const result = this._def.schema._parseSync({
              data: processed,
              path: ctx.path,
              parent: ctx
            });
            if (result.status === "aborted")
              return parseUtil_js_1.INVALID;
            if (result.status === "dirty")
              return (0, parseUtil_js_1.DIRTY)(result.value);
            if (status.value === "dirty")
              return (0, parseUtil_js_1.DIRTY)(result.value);
            return result;
          }
        }
        if (effect.type === "refinement") {
          const executeRefinement = (acc) => {
            const result = effect.refinement(acc, checkCtx);
            if (ctx.common.async) {
              return Promise.resolve(result);
            }
            if (result instanceof Promise) {
              throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
            }
            return acc;
          };
          if (ctx.common.async === false) {
            const inner = this._def.schema._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
            if (inner.status === "aborted")
              return parseUtil_js_1.INVALID;
            if (inner.status === "dirty")
              status.dirty();
            executeRefinement(inner.value);
            return { status: status.value, value: inner.value };
          } else {
            return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
              if (inner.status === "aborted")
                return parseUtil_js_1.INVALID;
              if (inner.status === "dirty")
                status.dirty();
              return executeRefinement(inner.value).then(() => {
                return { status: status.value, value: inner.value };
              });
            });
          }
        }
        if (effect.type === "transform") {
          if (ctx.common.async === false) {
            const base = this._def.schema._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
            if (!(0, parseUtil_js_1.isValid)(base))
              return parseUtil_js_1.INVALID;
            const result = effect.transform(base.value, checkCtx);
            if (result instanceof Promise) {
              throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
            }
            return { status: status.value, value: result };
          } else {
            return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
              if (!(0, parseUtil_js_1.isValid)(base))
                return parseUtil_js_1.INVALID;
              return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
                status: status.value,
                value: result
              }));
            });
          }
        }
        util_js_1.util.assertNever(effect);
      }
    };
    exports.ZodEffects = ZodEffects;
    exports.ZodTransformer = ZodEffects;
    ZodEffects.create = (schema, effect, params) => {
      return new ZodEffects({
        schema,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect,
        ...processCreateParams(params)
      });
    };
    ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
      return new ZodEffects({
        schema,
        effect: { type: "preprocess", transform: preprocess },
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        ...processCreateParams(params)
      });
    };
    var ZodOptional = class extends ZodType {
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType === util_js_1.ZodParsedType.undefined) {
          return (0, parseUtil_js_1.OK)(void 0);
        }
        return this._def.innerType._parse(input);
      }
      unwrap() {
        return this._def.innerType;
      }
    };
    exports.ZodOptional = ZodOptional;
    ZodOptional.create = (type, params) => {
      return new ZodOptional({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodOptional,
        ...processCreateParams(params)
      });
    };
    var ZodNullable = class extends ZodType {
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType === util_js_1.ZodParsedType.null) {
          return (0, parseUtil_js_1.OK)(null);
        }
        return this._def.innerType._parse(input);
      }
      unwrap() {
        return this._def.innerType;
      }
    };
    exports.ZodNullable = ZodNullable;
    ZodNullable.create = (type, params) => {
      return new ZodNullable({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodNullable,
        ...processCreateParams(params)
      });
    };
    var ZodDefault = class extends ZodType {
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        let data = ctx.data;
        if (ctx.parsedType === util_js_1.ZodParsedType.undefined) {
          data = this._def.defaultValue();
        }
        return this._def.innerType._parse({
          data,
          path: ctx.path,
          parent: ctx
        });
      }
      removeDefault() {
        return this._def.innerType;
      }
    };
    exports.ZodDefault = ZodDefault;
    ZodDefault.create = (type, params) => {
      return new ZodDefault({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodDefault,
        defaultValue: typeof params.default === "function" ? params.default : () => params.default,
        ...processCreateParams(params)
      });
    };
    var ZodCatch = class extends ZodType {
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        const newCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          }
        };
        const result = this._def.innerType._parse({
          data: newCtx.data,
          path: newCtx.path,
          parent: {
            ...newCtx
          }
        });
        if ((0, parseUtil_js_1.isAsync)(result)) {
          return result.then((result2) => {
            return {
              status: "valid",
              value: result2.status === "valid" ? result2.value : this._def.catchValue({
                get error() {
                  return new ZodError_js_1.ZodError(newCtx.common.issues);
                },
                input: newCtx.data
              })
            };
          });
        } else {
          return {
            status: "valid",
            value: result.status === "valid" ? result.value : this._def.catchValue({
              get error() {
                return new ZodError_js_1.ZodError(newCtx.common.issues);
              },
              input: newCtx.data
            })
          };
        }
      }
      removeCatch() {
        return this._def.innerType;
      }
    };
    exports.ZodCatch = ZodCatch;
    ZodCatch.create = (type, params) => {
      return new ZodCatch({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodCatch,
        catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
        ...processCreateParams(params)
      });
    };
    var ZodNaN = class extends ZodType {
      _parse(input) {
        const parsedType = this._getType(input);
        if (parsedType !== util_js_1.ZodParsedType.nan) {
          const ctx = this._getOrReturnCtx(input);
          (0, parseUtil_js_1.addIssueToContext)(ctx, {
            code: ZodError_js_1.ZodIssueCode.invalid_type,
            expected: util_js_1.ZodParsedType.nan,
            received: ctx.parsedType
          });
          return parseUtil_js_1.INVALID;
        }
        return { status: "valid", value: input.data };
      }
    };
    exports.ZodNaN = ZodNaN;
    ZodNaN.create = (params) => {
      return new ZodNaN({
        typeName: ZodFirstPartyTypeKind.ZodNaN,
        ...processCreateParams(params)
      });
    };
    exports.BRAND = Symbol("zod_brand");
    var ZodBranded = class extends ZodType {
      _parse(input) {
        const { ctx } = this._processInputParams(input);
        const data = ctx.data;
        return this._def.type._parse({
          data,
          path: ctx.path,
          parent: ctx
        });
      }
      unwrap() {
        return this._def.type;
      }
    };
    exports.ZodBranded = ZodBranded;
    var ZodPipeline = class _ZodPipeline extends ZodType {
      _parse(input) {
        const { status, ctx } = this._processInputParams(input);
        if (ctx.common.async) {
          const handleAsync = async () => {
            const inResult = await this._def.in._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
            if (inResult.status === "aborted")
              return parseUtil_js_1.INVALID;
            if (inResult.status === "dirty") {
              status.dirty();
              return (0, parseUtil_js_1.DIRTY)(inResult.value);
            } else {
              return this._def.out._parseAsync({
                data: inResult.value,
                path: ctx.path,
                parent: ctx
              });
            }
          };
          return handleAsync();
        } else {
          const inResult = this._def.in._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inResult.status === "aborted")
            return parseUtil_js_1.INVALID;
          if (inResult.status === "dirty") {
            status.dirty();
            return {
              status: "dirty",
              value: inResult.value
            };
          } else {
            return this._def.out._parseSync({
              data: inResult.value,
              path: ctx.path,
              parent: ctx
            });
          }
        }
      }
      static create(a, b) {
        return new _ZodPipeline({
          in: a,
          out: b,
          typeName: ZodFirstPartyTypeKind.ZodPipeline
        });
      }
    };
    exports.ZodPipeline = ZodPipeline;
    var ZodReadonly = class extends ZodType {
      _parse(input) {
        const result = this._def.innerType._parse(input);
        const freeze = (data) => {
          if ((0, parseUtil_js_1.isValid)(data)) {
            data.value = Object.freeze(data.value);
          }
          return data;
        };
        return (0, parseUtil_js_1.isAsync)(result) ? result.then((data) => freeze(data)) : freeze(result);
      }
      unwrap() {
        return this._def.innerType;
      }
    };
    exports.ZodReadonly = ZodReadonly;
    ZodReadonly.create = (type, params) => {
      return new ZodReadonly({
        innerType: type,
        typeName: ZodFirstPartyTypeKind.ZodReadonly,
        ...processCreateParams(params)
      });
    };
    function cleanParams(params, data) {
      const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
      const p2 = typeof p === "string" ? { message: p } : p;
      return p2;
    }
    function custom(check, _params = {}, fatal) {
      if (check)
        return ZodAny.create().superRefine((data, ctx) => {
          const r = check(data);
          if (r instanceof Promise) {
            return r.then((r2) => {
              if (!r2) {
                const params = cleanParams(_params, data);
                const _fatal = params.fatal ?? fatal ?? true;
                ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
              }
            });
          }
          if (!r) {
            const params = cleanParams(_params, data);
            const _fatal = params.fatal ?? fatal ?? true;
            ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
          }
          return;
        });
      return ZodAny.create();
    }
    exports.late = {
      object: ZodObject.lazycreate
    };
    var ZodFirstPartyTypeKind;
    (function(ZodFirstPartyTypeKind2) {
      ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
      ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
      ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
      ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
      ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
      ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
      ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
      ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
      ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
      ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
      ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
      ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
      ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
      ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
      ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
      ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
      ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
      ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
      ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
      ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
      ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
      ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
      ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
      ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
      ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
      ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
      ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
      ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
      ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
      ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
      ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
      ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
      ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
      ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
      ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
      ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
    })(ZodFirstPartyTypeKind || (exports.ZodFirstPartyTypeKind = ZodFirstPartyTypeKind = {}));
    var instanceOfType = (cls, params = {
      message: `Input not instance of ${cls.name}`
    }) => custom((data) => data instanceof cls, params);
    exports.instanceof = instanceOfType;
    var stringType = ZodString.create;
    exports.string = stringType;
    var numberType = ZodNumber.create;
    exports.number = numberType;
    var nanType = ZodNaN.create;
    exports.nan = nanType;
    var bigIntType = ZodBigInt.create;
    exports.bigint = bigIntType;
    var booleanType = ZodBoolean.create;
    exports.boolean = booleanType;
    var dateType = ZodDate.create;
    exports.date = dateType;
    var symbolType = ZodSymbol.create;
    exports.symbol = symbolType;
    var undefinedType = ZodUndefined.create;
    exports.undefined = undefinedType;
    var nullType = ZodNull.create;
    exports.null = nullType;
    var anyType = ZodAny.create;
    exports.any = anyType;
    var unknownType = ZodUnknown.create;
    exports.unknown = unknownType;
    var neverType = ZodNever.create;
    exports.never = neverType;
    var voidType = ZodVoid.create;
    exports.void = voidType;
    var arrayType = ZodArray.create;
    exports.array = arrayType;
    var objectType = ZodObject.create;
    exports.object = objectType;
    var strictObjectType = ZodObject.strictCreate;
    exports.strictObject = strictObjectType;
    var unionType = ZodUnion.create;
    exports.union = unionType;
    var discriminatedUnionType = ZodDiscriminatedUnion.create;
    exports.discriminatedUnion = discriminatedUnionType;
    var intersectionType = ZodIntersection.create;
    exports.intersection = intersectionType;
    var tupleType = ZodTuple.create;
    exports.tuple = tupleType;
    var recordType = ZodRecord.create;
    exports.record = recordType;
    var mapType = ZodMap.create;
    exports.map = mapType;
    var setType = ZodSet.create;
    exports.set = setType;
    var functionType = ZodFunction.create;
    exports.function = functionType;
    var lazyType = ZodLazy.create;
    exports.lazy = lazyType;
    var literalType = ZodLiteral.create;
    exports.literal = literalType;
    var enumType = ZodEnum.create;
    exports.enum = enumType;
    var nativeEnumType = ZodNativeEnum.create;
    exports.nativeEnum = nativeEnumType;
    var promiseType = ZodPromise.create;
    exports.promise = promiseType;
    var effectsType = ZodEffects.create;
    exports.effect = effectsType;
    exports.transformer = effectsType;
    var optionalType = ZodOptional.create;
    exports.optional = optionalType;
    var nullableType = ZodNullable.create;
    exports.nullable = nullableType;
    var preprocessType = ZodEffects.createWithPreprocess;
    exports.preprocess = preprocessType;
    var pipelineType = ZodPipeline.create;
    exports.pipeline = pipelineType;
    var ostring = () => stringType().optional();
    exports.ostring = ostring;
    var onumber = () => numberType().optional();
    exports.onumber = onumber;
    var oboolean = () => booleanType().optional();
    exports.oboolean = oboolean;
    exports.coerce = {
      string: (arg) => ZodString.create({ ...arg, coerce: true }),
      number: (arg) => ZodNumber.create({ ...arg, coerce: true }),
      boolean: (arg) => ZodBoolean.create({
        ...arg,
        coerce: true
      }),
      bigint: (arg) => ZodBigInt.create({ ...arg, coerce: true }),
      date: (arg) => ZodDate.create({ ...arg, coerce: true })
    };
    exports.NEVER = parseUtil_js_1.INVALID;
  }
});

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/external.cjs
var require_external = __commonJS({
  "../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/external.cjs"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    } : function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    __exportStar(require_errors(), exports);
    __exportStar(require_parseUtil(), exports);
    __exportStar(require_typeAliases(), exports);
    __exportStar(require_util2(), exports);
    __exportStar(require_types(), exports);
    __exportStar(require_ZodError(), exports);
  }
});

// ../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/index.cjs
var require_zod = __commonJS({
  "../../node_modules/.pnpm/zod@3.25.76/node_modules/zod/index.cjs"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    } : function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    });
    var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    } : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports && exports.__importStar || function(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) {
        for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
      }
      __setModuleDefault(result, mod);
      return result;
    };
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.z = void 0;
    var z = __importStar(require_external());
    exports.z = z;
    __exportStar(require_external(), exports);
    exports.default = z;
  }
});

// ../../packages/shared/dist/types.js
var require_types2 = __commonJS({
  "../../packages/shared/dist/types.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.NotificationSchema = exports.TaskSchema = exports.AgingBucketSchema = exports.AgentSchema = exports.OutboxItemSchema = exports.ActivityEventSchema = exports.ReplyThreadSchema = exports.ReminderMessageSchema = exports.ReminderRuleSchema = exports.TemplateKeySchema = exports.NotebookSchema = exports.NotebookRowSchema = exports.CellSchema = exports.NotebookColumnSchema = exports.ColumnTypeSchema = exports.ChallanSchema = exports.ChallanLineSchema = exports.QueueStatusSchema = exports.StockBalanceSchema = exports.StockItemSchema = exports.GodownSchema = exports.LedgerLineSchema = exports.BillSchema = exports.PartySchema = exports.UserSchema = exports.CompanySchema = exports.TenantSchema = exports.RoleSchema = void 0;
    var zod_1 = require_zod();
    exports.RoleSchema = zod_1.z.enum([
      "dev",
      "owner",
      "admin",
      "accounts",
      "sales",
      "stock_keeper",
      "viewer"
    ]);
    exports.TenantSchema = zod_1.z.object({
      id: zod_1.z.string(),
      name: zod_1.z.string(),
      ownerName: zod_1.z.string(),
      ownerPhone: zod_1.z.string(),
      status: zod_1.z.enum(["active", "inactive"]).default("active"),
      plan: zod_1.z.string().optional(),
      maxCompanies: zod_1.z.number().int().optional(),
      maxUsers: zod_1.z.number().int().optional(),
      trialEndsAt: zod_1.z.string().optional(),
      isDemo: zod_1.z.boolean().optional(),
      createdAt: zod_1.z.string()
    });
    exports.CompanySchema = zod_1.z.object({
      id: zod_1.z.string(),
      tenantId: zod_1.z.string(),
      name: zod_1.z.string(),
      tallyName: zod_1.z.string(),
      financialYear: zod_1.z.string(),
      gstin: zod_1.z.string().optional(),
      address: zod_1.z.string().optional(),
      phone: zod_1.z.string().optional(),
      lastSyncedAt: zod_1.z.string(),
      agentStatus: zod_1.z.enum(["online", "offline"])
    });
    exports.UserSchema = zod_1.z.object({
      id: zod_1.z.string(),
      tenantId: zod_1.z.string(),
      name: zod_1.z.string(),
      phone: zod_1.z.string(),
      pin: zod_1.z.string().optional(),
      role: exports.RoleSchema,
      customRoleName: zod_1.z.string().optional(),
      customPermissions: zod_1.z.array(zod_1.z.string()).optional(),
      companyIds: zod_1.z.union([zod_1.z.array(zod_1.z.string()), zod_1.z.literal("all")]),
      active: zod_1.z.boolean()
    });
    exports.PartySchema = zod_1.z.object({
      id: zod_1.z.string(),
      tenantId: zod_1.z.string(),
      companyId: zod_1.z.string(),
      name: zod_1.z.string(),
      city: zod_1.z.string(),
      phones: zod_1.z.array(zod_1.z.string()),
      gstin: zod_1.z.string().optional(),
      creditDays: zod_1.z.number().int().nonnegative(),
      collectorId: zod_1.z.string().optional(),
      remindersPaused: zod_1.z.boolean(),
      notes: zod_1.z.string(),
      promiseToPay: zod_1.z.string().optional(),
      closingBalance: zod_1.z.number().int().optional()
    });
    exports.BillSchema = zod_1.z.object({
      id: zod_1.z.string(),
      companyId: zod_1.z.string(),
      partyId: zod_1.z.string(),
      billNo: zod_1.z.string(),
      date: zod_1.z.string(),
      dueDate: zod_1.z.string(),
      dueDays: zod_1.z.number().int().optional(),
      amount: zod_1.z.number().int(),
      pending: zod_1.z.number().int(),
      source: zod_1.z.enum(["tally_bill", "estimated"])
    });
    exports.LedgerLineSchema = zod_1.z.object({
      date: zod_1.z.string(),
      particulars: zod_1.z.string(),
      voucherType: zod_1.z.enum(["Sales", "Receipt", "Journal", "Credit Note"]),
      voucherNo: zod_1.z.string(),
      debit: zod_1.z.number().int(),
      credit: zod_1.z.number().int()
    });
    exports.GodownSchema = zod_1.z.object({
      id: zod_1.z.string(),
      companyId: zod_1.z.string(),
      name: zod_1.z.string()
    });
    exports.StockItemSchema = zod_1.z.object({
      id: zod_1.z.string(),
      companyId: zod_1.z.string(),
      name: zod_1.z.string(),
      partNo: zod_1.z.string().optional(),
      unit: zod_1.z.string().min(1),
      group: zod_1.z.string(),
      rate: zod_1.z.number().int(),
      purchaseRate: zod_1.z.number().int().optional(),
      reorderLevel: zod_1.z.number(),
      alias: zod_1.z.string().optional(),
      hsnCode: zod_1.z.string().optional(),
      gstRate: zod_1.z.number().optional(),
      description: zod_1.z.string().optional(),
      customValues: zod_1.z.record(zod_1.z.string(), zod_1.z.string()).optional()
    });
    exports.StockBalanceSchema = zod_1.z.object({
      itemId: zod_1.z.string(),
      godownId: zod_1.z.string(),
      qty: zod_1.z.number()
    });
    exports.QueueStatusSchema = zod_1.z.enum(["draft", "queued", "synced", "failed", "cancelled"]);
    exports.ChallanLineSchema = zod_1.z.object({
      itemId: zod_1.z.string(),
      description: zod_1.z.string(),
      qty: zod_1.z.number(),
      unit: zod_1.z.string(),
      rate: zod_1.z.number().int(),
      amount: zod_1.z.number().int(),
      hsnCode: zod_1.z.string().optional(),
      gstRate: zod_1.z.number().optional()
    });
    exports.ChallanSchema = zod_1.z.object({
      id: zod_1.z.string(),
      companyId: zod_1.z.string(),
      type: zod_1.z.enum(["sales", "purchase", "delivery"]),
      number: zod_1.z.string(),
      date: zod_1.z.string(),
      partyId: zod_1.z.string(),
      godownId: zod_1.z.string().optional(),
      lines: zod_1.z.array(exports.ChallanLineSchema),
      vehicleNo: zod_1.z.string().optional(),
      lrNo: zod_1.z.string().optional(),
      transporter: zod_1.z.string().optional(),
      narration: zod_1.z.string().optional(),
      status: exports.QueueStatusSchema,
      failureReason: zod_1.z.string().optional(),
      createdBy: zod_1.z.string()
    });
    exports.ColumnTypeSchema = zod_1.z.enum([
      "text",
      "number",
      "date",
      "party",
      "item",
      "computed"
    ]);
    exports.NotebookColumnSchema = zod_1.z.object({
      id: zod_1.z.string(),
      key: zod_1.z.string(),
      title: zod_1.z.string(),
      type: exports.ColumnTypeSchema,
      decimals: zod_1.z.number().optional(),
      formula: zod_1.z.string().optional(),
      total: zod_1.z.enum(["sum", "avg", "count", "min", "max"]).nullable().optional()
    });
    exports.CellSchema = zod_1.z.object({
      raw: zod_1.z.string(),
      value: zod_1.z.string().optional(),
      error: zod_1.z.string().optional()
    });
    exports.NotebookRowSchema = zod_1.z.object({
      id: zod_1.z.string(),
      cells: zod_1.z.record(zod_1.z.string(), exports.CellSchema),
      linkedPartyId: zod_1.z.string().optional(),
      linkedItemId: zod_1.z.string().optional()
    });
    exports.NotebookSchema = zod_1.z.object({
      id: zod_1.z.string(),
      companyId: zod_1.z.string(),
      userId: zod_1.z.string().optional(),
      title: zod_1.z.string(),
      columns: zod_1.z.array(exports.NotebookColumnSchema),
      rows: zod_1.z.array(exports.NotebookRowSchema),
      updatedAt: zod_1.z.string(),
      updatedBy: zod_1.z.string()
    });
    exports.TemplateKeySchema = zod_1.z.enum([
      "due_soon",
      "due_today",
      "overdue",
      "payment_received"
    ]);
    exports.ReminderRuleSchema = zod_1.z.object({
      tenantId: zod_1.z.string(),
      enabled: zod_1.z.boolean(),
      whatsappEnabled: zod_1.z.boolean().default(false),
      defaultDueDays: zod_1.z.number().int().default(30),
      steps: zod_1.z.array(zod_1.z.object({
        offsetDays: zod_1.z.number(),
        template: exports.TemplateKeySchema,
        enabled: zod_1.z.boolean()
      })),
      quietHours: zod_1.z.object({
        from: zod_1.z.string(),
        to: zod_1.z.string(),
        days: zod_1.z.array(zod_1.z.number())
      }),
      minAmount: zod_1.z.number().int(),
      stopWhenPaid: zod_1.z.literal(true)
    });
    exports.ReminderMessageSchema = zod_1.z.object({
      id: zod_1.z.string(),
      companyId: zod_1.z.string(),
      partyId: zod_1.z.string(),
      billId: zod_1.z.string().optional(),
      template: exports.TemplateKeySchema,
      sentAt: zod_1.z.string(),
      status: zod_1.z.enum(["queued", "sent", "delivered", "read", "failed"]),
      failureReason: zod_1.z.string().optional()
    });
    exports.ReplyThreadSchema = zod_1.z.object({
      id: zod_1.z.string(),
      companyId: zod_1.z.string(),
      partyId: zod_1.z.string(),
      unread: zod_1.z.number().int(),
      lastCustomerMessageAt: zod_1.z.string(),
      messages: zod_1.z.array(zod_1.z.object({
        from: zod_1.z.enum(["customer", "us"]),
        text: zod_1.z.string(),
        at: zod_1.z.string()
      }))
    });
    exports.ActivityEventSchema = zod_1.z.object({
      id: zod_1.z.string(),
      tenantId: zod_1.z.string(),
      companyId: zod_1.z.string().optional(),
      actorId: zod_1.z.string(),
      action: zod_1.z.string(),
      target: zod_1.z.string(),
      at: zod_1.z.string(),
      device: zod_1.z.enum(["iPhone", "Android", "Desktop", "Agent"])
    });
    exports.OutboxItemSchema = zod_1.z.object({
      id: zod_1.z.string(),
      companyId: zod_1.z.string(),
      kind: zod_1.z.enum(["stock_journal", "challan", "receipt"]),
      refId: zod_1.z.string(),
      status: exports.QueueStatusSchema,
      attempts: zod_1.z.number().int(),
      lastError: zod_1.z.string().optional()
    });
    exports.AgentSchema = zod_1.z.object({
      version: zod_1.z.string(),
      status: zod_1.z.enum(["online", "offline"]),
      lastSeenAt: zod_1.z.string(),
      pairingCode: zod_1.z.string().optional(),
      pairingExpiresAt: zod_1.z.string().optional(),
      tallyStatus: zod_1.z.enum(["online", "offline"]).optional(),
      tallyError: zod_1.z.string().optional(),
      tallyPort: zod_1.z.number().optional(),
      openTallyCompanies: zod_1.z.array(zod_1.z.string()).optional(),
      agentApiKey: zod_1.z.string().optional()
    });
    exports.AgingBucketSchema = zod_1.z.enum([
      "not_due",
      "d1_30",
      "d31_60",
      "d61_90",
      "d90_plus"
    ]);
    exports.TaskSchema = zod_1.z.object({
      id: zod_1.z.string(),
      companyId: zod_1.z.string(),
      title: zod_1.z.string(),
      description: zod_1.z.string().optional(),
      assignedToUserId: zod_1.z.string(),
      assignedByUserId: zod_1.z.string(),
      challanId: zod_1.z.string().optional(),
      photoUrl: zod_1.z.string().optional(),
      status: zod_1.z.enum(["pending", "in_progress", "completed"]),
      priority: zod_1.z.enum(["normal", "high", "urgent"]).default("normal"),
      createdAt: zod_1.z.string(),
      completedAt: zod_1.z.string().optional()
    });
    exports.NotificationSchema = zod_1.z.object({
      id: zod_1.z.string(),
      userId: zod_1.z.string(),
      companyId: zod_1.z.string(),
      title: zod_1.z.string(),
      body: zod_1.z.string(),
      taskId: zod_1.z.string().optional(),
      challanId: zod_1.z.string().optional(),
      photoUrl: zod_1.z.string().optional(),
      read: zod_1.z.boolean(),
      createdAt: zod_1.z.string()
    });
  }
});

// ../../packages/shared/dist/money.js
var require_money = __commonJS({
  "../../packages/shared/dist/money.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.rupeesToPaise = rupeesToPaise2;
    exports.paiseToRupees = paiseToRupees;
    exports.formatINR = formatINR2;
    exports.numberToIndianWords = numberToIndianWords;
    function rupeesToPaise2(rupees) {
      return Math.round(rupees * 100);
    }
    function paiseToRupees(paise) {
      return paise / 100;
    }
    function formatINR2(paise, options = {}) {
      const { showDecimals = false, drCr = false, symbol = true } = options;
      const isCredit = paise < 0;
      const absPaise = Math.abs(paise);
      const rupees = absPaise / 100;
      const formatter = new Intl.NumberFormat("en-IN", {
        minimumFractionDigits: showDecimals ? 2 : 0,
        maximumFractionDigits: showDecimals ? 2 : 0
      });
      const formattedNum = formatter.format(rupees);
      const prefix = symbol ? "\u20B9" : "";
      if (drCr) {
        const suffix = isCredit ? " Cr" : " Dr";
        return `${prefix}${formattedNum}${suffix}`;
      }
      const sign = isCredit ? "-" : "";
      return `${sign}${prefix}${formattedNum}`;
    }
    function numberToIndianWords(paise) {
      const rupees = Math.floor(Math.abs(paise) / 100);
      if (rupees === 0)
        return "Rupees Zero Only";
      const ones = [
        "",
        "One",
        "Two",
        "Three",
        "Four",
        "Five",
        "Six",
        "Seven",
        "Eight",
        "Nine",
        "Ten",
        "Eleven",
        "Twelve",
        "Thirteen",
        "Fourteen",
        "Fifteen",
        "Sixteen",
        "Seventeen",
        "Eighteen",
        "Nineteen"
      ];
      const tens = [
        "",
        "",
        "Twenty",
        "Thirty",
        "Forty",
        "Fifty",
        "Sixty",
        "Seventy",
        "Eighty",
        "Ninety"
      ];
      function convertTwoDigits(num) {
        if (num === 0)
          return "";
        if (num < 20)
          return ones[num];
        const t = Math.floor(num / 10);
        const o = num % 10;
        return tens[t] + (o > 0 ? " " + ones[o] : "");
      }
      function convertThreeDigits(num) {
        const h = Math.floor(num / 100);
        const rest = num % 100;
        let res = "";
        if (h > 0) {
          res += ones[h] + " Hundred";
          if (rest > 0)
            res += " ";
        }
        if (rest > 0) {
          res += convertTwoDigits(rest);
        }
        return res;
      }
      const crore = Math.floor(rupees / 1e7);
      const lakh = Math.floor(rupees % 1e7 / 1e5);
      const thousand = Math.floor(rupees % 1e5 / 1e3);
      const hundredAndBelow = rupees % 1e3;
      let words = "Rupees ";
      if (crore > 0) {
        words += convertTwoDigits(crore) + " Crore ";
      }
      if (lakh > 0) {
        words += convertTwoDigits(lakh) + " Lakh ";
      }
      if (thousand > 0) {
        words += convertTwoDigits(thousand) + " Thousand ";
      }
      if (hundredAndBelow > 0) {
        words += convertThreeDigits(hundredAndBelow) + " ";
      }
      words += "Only";
      return words.trim();
    }
  }
});

// ../../packages/shared/dist/aging.js
var require_aging = __commonJS({
  "../../packages/shared/dist/aging.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getTodayIST = getTodayIST;
    exports.getFinancialYearShort = getFinancialYearShort;
    exports.parseISODate = parseISODate;
    exports.getDaysOverdue = getDaysOverdue2;
    exports.getAgingBucket = getAgingBucket;
    exports.calculateAgingSummary = calculateAgingSummary;
    function getTodayIST(now = /* @__PURE__ */ new Date()) {
      const istOffsetMs = (5 * 60 + 30) * 60 * 1e3;
      return new Date(now.getTime() + istOffsetMs).toISOString().slice(0, 10);
    }
    function getFinancialYearShort(financialYear, dateStr) {
      if (financialYear && typeof financialYear === "string") {
        const m = financialYear.trim().match(/(\d{2,4})\s*-\s*(\d{2,4})/);
        if (m && m[1] && m[2]) {
          const start2 = m[1].slice(-2);
          const end2 = m[2].slice(-2);
          return `${start2}-${end2}`;
        }
      }
      const ref = dateStr ? parseISODate(dateStr) : parseISODate(getTodayIST());
      const year = ref.getUTCFullYear();
      const month = ref.getUTCMonth() + 1;
      const fyStart = month >= 4 ? year : year - 1;
      const fyEnd = fyStart + 1;
      return `${String(fyStart).slice(-2)}-${String(fyEnd).slice(-2)}`;
    }
    function parseISODate(dateStr) {
      const clean = (dateStr || "").slice(0, 10);
      const [year, month, day] = clean.split("-").map(Number);
      return new Date(Date.UTC(year || 2026, (month || 1) - 1, day || 1));
    }
    function getDaysOverdue2(dueDate, today = getTodayIST()) {
      const due = parseISODate(dueDate);
      const current = parseISODate(today);
      const diffMs = current.getTime() - due.getTime();
      return Math.floor(diffMs / (1e3 * 60 * 60 * 24));
    }
    function getAgingBucket(dueDate, today = getTodayIST()) {
      const days = getDaysOverdue2(dueDate, today);
      if (days <= 0)
        return "not_due";
      if (days <= 30)
        return "d1_30";
      if (days <= 60)
        return "d31_60";
      if (days <= 90)
        return "d61_90";
      return "d90_plus";
    }
    function calculateAgingSummary(bills, today) {
      const byBucket = {
        not_due: { count: 0, amount: 0 },
        d1_30: { count: 0, amount: 0 },
        d31_60: { count: 0, amount: 0 },
        d61_90: { count: 0, amount: 0 },
        d90_plus: { count: 0, amount: 0 }
      };
      let total = 0;
      let overdue = 0;
      for (const bill of bills) {
        const amount = bill.pending;
        total += amount;
        if (amount <= 0)
          continue;
        const bucket = getAgingBucket(bill.dueDate, today);
        const bucketEntry = byBucket[bucket];
        if (bucketEntry) {
          bucketEntry.count += 1;
          bucketEntry.amount += amount;
        }
        if (bucket !== "not_due") {
          overdue += amount;
        }
      }
      const notDue = byBucket.not_due.amount;
      const late1to30 = byBucket.d1_30.amount;
      const over30 = byBucket.d31_60.amount + byBucket.d61_90.amount + byBucket.d90_plus.amount;
      return {
        total,
        overdue,
        notDue,
        late1to30,
        over30,
        byBucket
      };
    }
  }
});

// ../../packages/shared/dist/fifo.js
var require_fifo = __commonJS({
  "../../packages/shared/dist/fifo.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.estimateOpenBills = estimateOpenBills;
    function addDays(dateStr, days) {
      const [year, month, day] = dateStr.split("-").map(Number);
      const date = new Date(Date.UTC(year ?? 2026, (month ?? 1) - 1, (day ?? 1) + days));
      return date.toISOString().slice(0, 10);
    }
    function estimateOpenBills(invoices, receipts, options) {
      const sortedInvoices = [...invoices].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      let remainingReceiptPool = receipts.reduce((sum, r) => sum + r.amount, 0);
      const openBills = [];
      for (const inv of sortedInvoices) {
        if (remainingReceiptPool >= inv.amount) {
          remainingReceiptPool -= inv.amount;
        } else {
          const pendingAmount = inv.amount - remainingReceiptPool;
          remainingReceiptPool = 0;
          const dueDate = inv.dueDate ?? addDays(inv.date, options.defaultCreditDays ?? 30);
          openBills.push({
            id: inv.id,
            companyId: options.companyId,
            partyId: options.partyId,
            billNo: inv.billNo,
            date: inv.date,
            dueDate,
            amount: inv.amount,
            pending: pendingAmount,
            source: "estimated"
          });
        }
      }
      return openBills;
    }
  }
});

// ../../packages/shared/dist/permissions.js
var require_permissions = __commonJS({
  "../../packages/shared/dist/permissions.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CUSTOM_ROLE_PERMISSIONS = exports.ROLE_PERMISSIONS = exports.PLATFORM_PERMISSION_KEYS = exports.ADMIN_PERMISSION_KEYS = exports.OPERATIONAL_PERMISSION_KEYS = exports.PERMISSION_KEYS = void 0;
    exports.setCustomPermissions = setCustomPermissions;
    exports.can = can;
    exports.PERMISSION_KEYS = [
      "dashboard.view",
      "ledgers.view",
      "reminders.view",
      "reminders.send",
      "reminders.configure",
      "party.edit",
      "stock.view",
      "stock.adjust",
      "challan.view",
      "challan.create",
      "notebook.view",
      "notebook.edit",
      "activity.view",
      "tally.write",
      "tally.write.stock",
      "settings.manage",
      "users.manage",
      "clients.manage"
    ];
    exports.OPERATIONAL_PERMISSION_KEYS = [
      "dashboard.view",
      "ledgers.view",
      "reminders.view",
      "reminders.send",
      "reminders.configure",
      "party.edit",
      "stock.view",
      "stock.adjust",
      "challan.view",
      "challan.create",
      "notebook.view",
      "notebook.edit",
      "activity.view",
      "tally.write",
      "tally.write.stock"
    ];
    exports.ADMIN_PERMISSION_KEYS = [
      "settings.manage",
      "users.manage"
    ];
    exports.PLATFORM_PERMISSION_KEYS = [
      "clients.manage"
    ];
    exports.ROLE_PERMISSIONS = {
      dev: {
        "dashboard.view": true,
        "ledgers.view": true,
        "reminders.view": true,
        "reminders.send": true,
        "reminders.configure": true,
        "party.edit": true,
        "stock.view": true,
        "stock.adjust": true,
        "challan.view": true,
        "challan.create": true,
        "notebook.view": true,
        "notebook.edit": true,
        "activity.view": true,
        "tally.write": true,
        "tally.write.stock": true,
        "settings.manage": true,
        "users.manage": true,
        "clients.manage": true
      },
      owner: {
        "dashboard.view": true,
        "ledgers.view": true,
        "reminders.view": true,
        "reminders.send": true,
        "reminders.configure": true,
        "party.edit": true,
        "stock.view": true,
        "stock.adjust": true,
        "challan.view": true,
        "challan.create": true,
        "notebook.view": true,
        "notebook.edit": true,
        "activity.view": true,
        "tally.write": true,
        "tally.write.stock": true,
        "settings.manage": true,
        "users.manage": true,
        "clients.manage": false
      },
      admin: {
        "dashboard.view": true,
        "ledgers.view": true,
        "reminders.view": true,
        "reminders.send": true,
        "reminders.configure": true,
        "party.edit": true,
        "stock.view": true,
        "stock.adjust": true,
        "challan.view": true,
        "challan.create": true,
        "notebook.view": true,
        "notebook.edit": true,
        "activity.view": true,
        "tally.write": true,
        "tally.write.stock": true,
        "settings.manage": true,
        "users.manage": false,
        "clients.manage": false
      },
      accounts: {
        "dashboard.view": true,
        "ledgers.view": true,
        "reminders.view": true,
        "reminders.send": true,
        "reminders.configure": true,
        "party.edit": true,
        "stock.view": true,
        "stock.adjust": false,
        "challan.view": true,
        "challan.create": false,
        "notebook.view": true,
        "notebook.edit": true,
        "activity.view": true,
        "tally.write": true,
        "tally.write.stock": false,
        "settings.manage": false,
        "users.manage": false,
        "clients.manage": false
      },
      sales: {
        "dashboard.view": true,
        "ledgers.view": true,
        "reminders.view": true,
        "reminders.send": false,
        "reminders.configure": false,
        "party.edit": false,
        "stock.view": true,
        "stock.adjust": false,
        "challan.view": true,
        "challan.create": true,
        "notebook.view": true,
        "notebook.edit": true,
        "activity.view": false,
        "tally.write": false,
        "tally.write.stock": false,
        "settings.manage": false,
        "users.manage": false,
        "clients.manage": false
      },
      stock_keeper: {
        "dashboard.view": true,
        "ledgers.view": false,
        "reminders.view": false,
        "reminders.send": false,
        "reminders.configure": false,
        "party.edit": false,
        "stock.view": true,
        "stock.adjust": true,
        "challan.view": true,
        "challan.create": true,
        "notebook.view": false,
        "notebook.edit": false,
        "activity.view": false,
        "tally.write": false,
        "tally.write.stock": true,
        "settings.manage": false,
        "users.manage": false,
        "clients.manage": false
      },
      viewer: {
        "dashboard.view": true,
        "ledgers.view": true,
        "reminders.view": true,
        "reminders.send": false,
        "reminders.configure": false,
        "party.edit": false,
        "stock.view": true,
        "stock.adjust": false,
        "challan.view": true,
        "challan.create": false,
        "notebook.view": true,
        "notebook.edit": false,
        "activity.view": false,
        "tally.write": false,
        "tally.write.stock": false,
        "settings.manage": false,
        "users.manage": false,
        "clients.manage": false
      }
    };
    function cloneRolePermissions(source) {
      return Object.fromEntries(Object.entries(source).map(([role, perms]) => [role, { ...perms }]));
    }
    exports.CUSTOM_ROLE_PERMISSIONS = cloneRolePermissions(exports.ROLE_PERMISSIONS);
    function setCustomPermissions(perms) {
      exports.CUSTOM_ROLE_PERMISSIONS = cloneRolePermissions(perms);
    }
    function can(roleOrUser, permission) {
      if (!roleOrUser)
        return false;
      if (typeof roleOrUser === "string") {
        const role = roleOrUser;
        if (permission === "clients.manage" && role !== "dev")
          return false;
        const rolePerms2 = exports.CUSTOM_ROLE_PERMISSIONS[role] || exports.ROLE_PERMISSIONS[role];
        return rolePerms2 ? rolePerms2[permission] === true : false;
      }
      const u = roleOrUser;
      if (u.role === "dev")
        return true;
      if (permission === "clients.manage")
        return false;
      if (Array.isArray(u.customPermissions)) {
        return u.customPermissions.includes(permission);
      }
      const rolePerms = exports.CUSTOM_ROLE_PERMISSIONS[u.role] || exports.ROLE_PERMISSIONS[u.role];
      return rolePerms ? rolePerms[permission] === true : false;
    }
  }
});

// ../../node_modules/.pnpm/decimal.js@10.6.0/node_modules/decimal.js/decimal.js
var require_decimal = __commonJS({
  "../../node_modules/.pnpm/decimal.js@10.6.0/node_modules/decimal.js/decimal.js"(exports, module) {
    (function(globalScope) {
      "use strict";
      var EXP_LIMIT = 9e15, MAX_DIGITS = 1e9, NUMERALS = "0123456789abcdef", LN10 = "2.3025850929940456840179914546843642076011014886287729760333279009675726096773524802359972050895982983419677840422862486334095254650828067566662873690987816894829072083255546808437998948262331985283935053089653777326288461633662222876982198867465436674744042432743651550489343149393914796194044002221051017141748003688084012647080685567743216228355220114804663715659121373450747856947683463616792101806445070648000277502684916746550586856935673420670581136429224554405758925724208241314695689016758940256776311356919292033376587141660230105703089634572075440370847469940168269282808481184289314848524948644871927809676271275775397027668605952496716674183485704422507197965004714951050492214776567636938662976979522110718264549734772662425709429322582798502585509785265383207606726317164309505995087807523710333101197857547331541421808427543863591778117054309827482385045648019095610299291824318237525357709750539565187697510374970888692180205189339507238539205144634197265287286965110862571492198849978748873771345686209167058", PI = "3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679821480865132823066470938446095505822317253594081284811174502841027019385211055596446229489549303819644288109756659334461284756482337867831652712019091456485669234603486104543266482133936072602491412737245870066063155881748815209209628292540917153643678925903600113305305488204665213841469519415116094330572703657595919530921861173819326117931051185480744623799627495673518857527248912279381830119491298336733624406566430860213949463952247371907021798609437027705392171762931767523846748184676694051320005681271452635608277857713427577896091736371787214684409012249534301465495853710507922796892589235420199561121290219608640344181598136297747713099605187072113499999983729780499510597317328160963185950244594553469083026425223082533446850352619311881710100031378387528865875332083814206171776691473035982534904287554687311595628638823537875937519577818577805321712268066130019278766111959092164201989380952572010654858632789", DEFAULTS = {
        // These values must be integers within the stated ranges (inclusive).
        // Most of these values can be changed at run-time using the `Decimal.config` method.
        // The maximum number of significant digits of the result of a calculation or base conversion.
        // E.g. `Decimal.config({ precision: 20 });`
        precision: 20,
        // 1 to MAX_DIGITS
        // The rounding mode used when rounding to `precision`.
        //
        // ROUND_UP         0 Away from zero.
        // ROUND_DOWN       1 Towards zero.
        // ROUND_CEIL       2 Towards +Infinity.
        // ROUND_FLOOR      3 Towards -Infinity.
        // ROUND_HALF_UP    4 Towards nearest neighbour. If equidistant, up.
        // ROUND_HALF_DOWN  5 Towards nearest neighbour. If equidistant, down.
        // ROUND_HALF_EVEN  6 Towards nearest neighbour. If equidistant, towards even neighbour.
        // ROUND_HALF_CEIL  7 Towards nearest neighbour. If equidistant, towards +Infinity.
        // ROUND_HALF_FLOOR 8 Towards nearest neighbour. If equidistant, towards -Infinity.
        //
        // E.g.
        // `Decimal.rounding = 4;`
        // `Decimal.rounding = Decimal.ROUND_HALF_UP;`
        rounding: 4,
        // 0 to 8
        // The modulo mode used when calculating the modulus: a mod n.
        // The quotient (q = a / n) is calculated according to the corresponding rounding mode.
        // The remainder (r) is calculated as: r = a - n * q.
        //
        // UP         0 The remainder is positive if the dividend is negative, else is negative.
        // DOWN       1 The remainder has the same sign as the dividend (JavaScript %).
        // FLOOR      3 The remainder has the same sign as the divisor (Python %).
        // HALF_EVEN  6 The IEEE 754 remainder function.
        // EUCLID     9 Euclidian division. q = sign(n) * floor(a / abs(n)). Always positive.
        //
        // Truncated division (1), floored division (3), the IEEE 754 remainder (6), and Euclidian
        // division (9) are commonly used for the modulus operation. The other rounding modes can also
        // be used, but they may not give useful results.
        modulo: 1,
        // 0 to 9
        // The exponent value at and beneath which `toString` returns exponential notation.
        // JavaScript numbers: -7
        toExpNeg: -7,
        // 0 to -EXP_LIMIT
        // The exponent value at and above which `toString` returns exponential notation.
        // JavaScript numbers: 21
        toExpPos: 21,
        // 0 to EXP_LIMIT
        // The minimum exponent value, beneath which underflow to zero occurs.
        // JavaScript numbers: -324  (5e-324)
        minE: -EXP_LIMIT,
        // -1 to -EXP_LIMIT
        // The maximum exponent value, above which overflow to Infinity occurs.
        // JavaScript numbers: 308  (1.7976931348623157e+308)
        maxE: EXP_LIMIT,
        // 1 to EXP_LIMIT
        // Whether to use cryptographically-secure random number generation, if available.
        crypto: false
        // true/false
      }, Decimal, inexact, noConflict, quadrant, external = true, decimalError = "[DecimalError] ", invalidArgument = decimalError + "Invalid argument: ", precisionLimitExceeded = decimalError + "Precision limit exceeded", cryptoUnavailable = decimalError + "crypto unavailable", tag = "[object Decimal]", mathfloor = Math.floor, mathpow = Math.pow, isBinary = /^0b([01]+(\.[01]*)?|\.[01]+)(p[+-]?\d+)?$/i, isHex = /^0x([0-9a-f]+(\.[0-9a-f]*)?|\.[0-9a-f]+)(p[+-]?\d+)?$/i, isOctal = /^0o([0-7]+(\.[0-7]*)?|\.[0-7]+)(p[+-]?\d+)?$/i, isDecimal = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i, BASE = 1e7, LOG_BASE = 7, MAX_SAFE_INTEGER = 9007199254740991, LN10_PRECISION = LN10.length - 1, PI_PRECISION = PI.length - 1, P = { toStringTag: tag };
      P.absoluteValue = P.abs = function() {
        var x = new this.constructor(this);
        if (x.s < 0) x.s = 1;
        return finalise(x);
      };
      P.ceil = function() {
        return finalise(new this.constructor(this), this.e + 1, 2);
      };
      P.clampedTo = P.clamp = function(min2, max2) {
        var k, x = this, Ctor = x.constructor;
        min2 = new Ctor(min2);
        max2 = new Ctor(max2);
        if (!min2.s || !max2.s) return new Ctor(NaN);
        if (min2.gt(max2)) throw Error(invalidArgument + max2);
        k = x.cmp(min2);
        return k < 0 ? min2 : x.cmp(max2) > 0 ? max2 : new Ctor(x);
      };
      P.comparedTo = P.cmp = function(y) {
        var i, j, xdL, ydL, x = this, xd = x.d, yd = (y = new x.constructor(y)).d, xs = x.s, ys = y.s;
        if (!xd || !yd) {
          return !xs || !ys ? NaN : xs !== ys ? xs : xd === yd ? 0 : !xd ^ xs < 0 ? 1 : -1;
        }
        if (!xd[0] || !yd[0]) return xd[0] ? xs : yd[0] ? -ys : 0;
        if (xs !== ys) return xs;
        if (x.e !== y.e) return x.e > y.e ^ xs < 0 ? 1 : -1;
        xdL = xd.length;
        ydL = yd.length;
        for (i = 0, j = xdL < ydL ? xdL : ydL; i < j; ++i) {
          if (xd[i] !== yd[i]) return xd[i] > yd[i] ^ xs < 0 ? 1 : -1;
        }
        return xdL === ydL ? 0 : xdL > ydL ^ xs < 0 ? 1 : -1;
      };
      P.cosine = P.cos = function() {
        var pr, rm, x = this, Ctor = x.constructor;
        if (!x.d) return new Ctor(NaN);
        if (!x.d[0]) return new Ctor(1);
        pr = Ctor.precision;
        rm = Ctor.rounding;
        Ctor.precision = pr + Math.max(x.e, x.sd()) + LOG_BASE;
        Ctor.rounding = 1;
        x = cosine(Ctor, toLessThanHalfPi(Ctor, x));
        Ctor.precision = pr;
        Ctor.rounding = rm;
        return finalise(quadrant == 2 || quadrant == 3 ? x.neg() : x, pr, rm, true);
      };
      P.cubeRoot = P.cbrt = function() {
        var e, m, n, r, rep, s, sd, t, t3, t3plusx, x = this, Ctor = x.constructor;
        if (!x.isFinite() || x.isZero()) return new Ctor(x);
        external = false;
        s = x.s * mathpow(x.s * x, 1 / 3);
        if (!s || Math.abs(s) == 1 / 0) {
          n = digitsToString(x.d);
          e = x.e;
          if (s = (e - n.length + 1) % 3) n += s == 1 || s == -2 ? "0" : "00";
          s = mathpow(n, 1 / 3);
          e = mathfloor((e + 1) / 3) - (e % 3 == (e < 0 ? -1 : 2));
          if (s == 1 / 0) {
            n = "5e" + e;
          } else {
            n = s.toExponential();
            n = n.slice(0, n.indexOf("e") + 1) + e;
          }
          r = new Ctor(n);
          r.s = x.s;
        } else {
          r = new Ctor(s.toString());
        }
        sd = (e = Ctor.precision) + 3;
        for (; ; ) {
          t = r;
          t3 = t.times(t).times(t);
          t3plusx = t3.plus(x);
          r = divide(t3plusx.plus(x).times(t), t3plusx.plus(t3), sd + 2, 1);
          if (digitsToString(t.d).slice(0, sd) === (n = digitsToString(r.d)).slice(0, sd)) {
            n = n.slice(sd - 3, sd + 1);
            if (n == "9999" || !rep && n == "4999") {
              if (!rep) {
                finalise(t, e + 1, 0);
                if (t.times(t).times(t).eq(x)) {
                  r = t;
                  break;
                }
              }
              sd += 4;
              rep = 1;
            } else {
              if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
                finalise(r, e + 1, 1);
                m = !r.times(r).times(r).eq(x);
              }
              break;
            }
          }
        }
        external = true;
        return finalise(r, e, Ctor.rounding, m);
      };
      P.decimalPlaces = P.dp = function() {
        var w, d = this.d, n = NaN;
        if (d) {
          w = d.length - 1;
          n = (w - mathfloor(this.e / LOG_BASE)) * LOG_BASE;
          w = d[w];
          if (w) for (; w % 10 == 0; w /= 10) n--;
          if (n < 0) n = 0;
        }
        return n;
      };
      P.dividedBy = P.div = function(y) {
        return divide(this, new this.constructor(y));
      };
      P.dividedToIntegerBy = P.divToInt = function(y) {
        var x = this, Ctor = x.constructor;
        return finalise(divide(x, new Ctor(y), 0, 1, 1), Ctor.precision, Ctor.rounding);
      };
      P.equals = P.eq = function(y) {
        return this.cmp(y) === 0;
      };
      P.floor = function() {
        return finalise(new this.constructor(this), this.e + 1, 3);
      };
      P.greaterThan = P.gt = function(y) {
        return this.cmp(y) > 0;
      };
      P.greaterThanOrEqualTo = P.gte = function(y) {
        var k = this.cmp(y);
        return k == 1 || k === 0;
      };
      P.hyperbolicCosine = P.cosh = function() {
        var k, n, pr, rm, len, x = this, Ctor = x.constructor, one = new Ctor(1);
        if (!x.isFinite()) return new Ctor(x.s ? 1 / 0 : NaN);
        if (x.isZero()) return one;
        pr = Ctor.precision;
        rm = Ctor.rounding;
        Ctor.precision = pr + Math.max(x.e, x.sd()) + 4;
        Ctor.rounding = 1;
        len = x.d.length;
        if (len < 32) {
          k = Math.ceil(len / 3);
          n = (1 / tinyPow(4, k)).toString();
        } else {
          k = 16;
          n = "2.3283064365386962890625e-10";
        }
        x = taylorSeries(Ctor, 1, x.times(n), new Ctor(1), true);
        var cosh2_x, i = k, d8 = new Ctor(8);
        for (; i--; ) {
          cosh2_x = x.times(x);
          x = one.minus(cosh2_x.times(d8.minus(cosh2_x.times(d8))));
        }
        return finalise(x, Ctor.precision = pr, Ctor.rounding = rm, true);
      };
      P.hyperbolicSine = P.sinh = function() {
        var k, pr, rm, len, x = this, Ctor = x.constructor;
        if (!x.isFinite() || x.isZero()) return new Ctor(x);
        pr = Ctor.precision;
        rm = Ctor.rounding;
        Ctor.precision = pr + Math.max(x.e, x.sd()) + 4;
        Ctor.rounding = 1;
        len = x.d.length;
        if (len < 3) {
          x = taylorSeries(Ctor, 2, x, x, true);
        } else {
          k = 1.4 * Math.sqrt(len);
          k = k > 16 ? 16 : k | 0;
          x = x.times(1 / tinyPow(5, k));
          x = taylorSeries(Ctor, 2, x, x, true);
          var sinh2_x, d5 = new Ctor(5), d16 = new Ctor(16), d20 = new Ctor(20);
          for (; k--; ) {
            sinh2_x = x.times(x);
            x = x.times(d5.plus(sinh2_x.times(d16.times(sinh2_x).plus(d20))));
          }
        }
        Ctor.precision = pr;
        Ctor.rounding = rm;
        return finalise(x, pr, rm, true);
      };
      P.hyperbolicTangent = P.tanh = function() {
        var pr, rm, x = this, Ctor = x.constructor;
        if (!x.isFinite()) return new Ctor(x.s);
        if (x.isZero()) return new Ctor(x);
        pr = Ctor.precision;
        rm = Ctor.rounding;
        Ctor.precision = pr + 7;
        Ctor.rounding = 1;
        return divide(x.sinh(), x.cosh(), Ctor.precision = pr, Ctor.rounding = rm);
      };
      P.inverseCosine = P.acos = function() {
        var x = this, Ctor = x.constructor, k = x.abs().cmp(1), pr = Ctor.precision, rm = Ctor.rounding;
        if (k !== -1) {
          return k === 0 ? x.isNeg() ? getPi(Ctor, pr, rm) : new Ctor(0) : new Ctor(NaN);
        }
        if (x.isZero()) return getPi(Ctor, pr + 4, rm).times(0.5);
        Ctor.precision = pr + 6;
        Ctor.rounding = 1;
        x = new Ctor(1).minus(x).div(x.plus(1)).sqrt().atan();
        Ctor.precision = pr;
        Ctor.rounding = rm;
        return x.times(2);
      };
      P.inverseHyperbolicCosine = P.acosh = function() {
        var pr, rm, x = this, Ctor = x.constructor;
        if (x.lte(1)) return new Ctor(x.eq(1) ? 0 : NaN);
        if (!x.isFinite()) return new Ctor(x);
        pr = Ctor.precision;
        rm = Ctor.rounding;
        Ctor.precision = pr + Math.max(Math.abs(x.e), x.sd()) + 4;
        Ctor.rounding = 1;
        external = false;
        x = x.times(x).minus(1).sqrt().plus(x);
        external = true;
        Ctor.precision = pr;
        Ctor.rounding = rm;
        return x.ln();
      };
      P.inverseHyperbolicSine = P.asinh = function() {
        var pr, rm, x = this, Ctor = x.constructor;
        if (!x.isFinite() || x.isZero()) return new Ctor(x);
        pr = Ctor.precision;
        rm = Ctor.rounding;
        Ctor.precision = pr + 2 * Math.max(Math.abs(x.e), x.sd()) + 6;
        Ctor.rounding = 1;
        external = false;
        x = x.times(x).plus(1).sqrt().plus(x);
        external = true;
        Ctor.precision = pr;
        Ctor.rounding = rm;
        return x.ln();
      };
      P.inverseHyperbolicTangent = P.atanh = function() {
        var pr, rm, wpr, xsd, x = this, Ctor = x.constructor;
        if (!x.isFinite()) return new Ctor(NaN);
        if (x.e >= 0) return new Ctor(x.abs().eq(1) ? x.s / 0 : x.isZero() ? x : NaN);
        pr = Ctor.precision;
        rm = Ctor.rounding;
        xsd = x.sd();
        if (Math.max(xsd, pr) < 2 * -x.e - 1) return finalise(new Ctor(x), pr, rm, true);
        Ctor.precision = wpr = xsd - x.e;
        x = divide(x.plus(1), new Ctor(1).minus(x), wpr + pr, 1);
        Ctor.precision = pr + 4;
        Ctor.rounding = 1;
        x = x.ln();
        Ctor.precision = pr;
        Ctor.rounding = rm;
        return x.times(0.5);
      };
      P.inverseSine = P.asin = function() {
        var halfPi, k, pr, rm, x = this, Ctor = x.constructor;
        if (x.isZero()) return new Ctor(x);
        k = x.abs().cmp(1);
        pr = Ctor.precision;
        rm = Ctor.rounding;
        if (k !== -1) {
          if (k === 0) {
            halfPi = getPi(Ctor, pr + 4, rm).times(0.5);
            halfPi.s = x.s;
            return halfPi;
          }
          return new Ctor(NaN);
        }
        Ctor.precision = pr + 6;
        Ctor.rounding = 1;
        x = x.div(new Ctor(1).minus(x.times(x)).sqrt().plus(1)).atan();
        Ctor.precision = pr;
        Ctor.rounding = rm;
        return x.times(2);
      };
      P.inverseTangent = P.atan = function() {
        var i, j, k, n, px, t, r, wpr, x2, x = this, Ctor = x.constructor, pr = Ctor.precision, rm = Ctor.rounding;
        if (!x.isFinite()) {
          if (!x.s) return new Ctor(NaN);
          if (pr + 4 <= PI_PRECISION) {
            r = getPi(Ctor, pr + 4, rm).times(0.5);
            r.s = x.s;
            return r;
          }
        } else if (x.isZero()) {
          return new Ctor(x);
        } else if (x.abs().eq(1) && pr + 4 <= PI_PRECISION) {
          r = getPi(Ctor, pr + 4, rm).times(0.25);
          r.s = x.s;
          return r;
        }
        Ctor.precision = wpr = pr + 10;
        Ctor.rounding = 1;
        k = Math.min(28, wpr / LOG_BASE + 2 | 0);
        for (i = k; i; --i) x = x.div(x.times(x).plus(1).sqrt().plus(1));
        external = false;
        j = Math.ceil(wpr / LOG_BASE);
        n = 1;
        x2 = x.times(x);
        r = new Ctor(x);
        px = x;
        for (; i !== -1; ) {
          px = px.times(x2);
          t = r.minus(px.div(n += 2));
          px = px.times(x2);
          r = t.plus(px.div(n += 2));
          if (r.d[j] !== void 0) for (i = j; r.d[i] === t.d[i] && i--; ) ;
        }
        if (k) r = r.times(2 << k - 1);
        external = true;
        return finalise(r, Ctor.precision = pr, Ctor.rounding = rm, true);
      };
      P.isFinite = function() {
        return !!this.d;
      };
      P.isInteger = P.isInt = function() {
        return !!this.d && mathfloor(this.e / LOG_BASE) > this.d.length - 2;
      };
      P.isNaN = function() {
        return !this.s;
      };
      P.isNegative = P.isNeg = function() {
        return this.s < 0;
      };
      P.isPositive = P.isPos = function() {
        return this.s > 0;
      };
      P.isZero = function() {
        return !!this.d && this.d[0] === 0;
      };
      P.lessThan = P.lt = function(y) {
        return this.cmp(y) < 0;
      };
      P.lessThanOrEqualTo = P.lte = function(y) {
        return this.cmp(y) < 1;
      };
      P.logarithm = P.log = function(base) {
        var isBase10, d, denominator, k, inf, num, sd, r, arg = this, Ctor = arg.constructor, pr = Ctor.precision, rm = Ctor.rounding, guard = 5;
        if (base == null) {
          base = new Ctor(10);
          isBase10 = true;
        } else {
          base = new Ctor(base);
          d = base.d;
          if (base.s < 0 || !d || !d[0] || base.eq(1)) return new Ctor(NaN);
          isBase10 = base.eq(10);
        }
        d = arg.d;
        if (arg.s < 0 || !d || !d[0] || arg.eq(1)) {
          return new Ctor(d && !d[0] ? -1 / 0 : arg.s != 1 ? NaN : d ? 0 : 1 / 0);
        }
        if (isBase10) {
          if (d.length > 1) {
            inf = true;
          } else {
            for (k = d[0]; k % 10 === 0; ) k /= 10;
            inf = k !== 1;
          }
        }
        external = false;
        sd = pr + guard;
        num = naturalLogarithm(arg, sd);
        denominator = isBase10 ? getLn10(Ctor, sd + 10) : naturalLogarithm(base, sd);
        r = divide(num, denominator, sd, 1);
        if (checkRoundingDigits(r.d, k = pr, rm)) {
          do {
            sd += 10;
            num = naturalLogarithm(arg, sd);
            denominator = isBase10 ? getLn10(Ctor, sd + 10) : naturalLogarithm(base, sd);
            r = divide(num, denominator, sd, 1);
            if (!inf) {
              if (+digitsToString(r.d).slice(k + 1, k + 15) + 1 == 1e14) {
                r = finalise(r, pr + 1, 0);
              }
              break;
            }
          } while (checkRoundingDigits(r.d, k += 10, rm));
        }
        external = true;
        return finalise(r, pr, rm);
      };
      P.minus = P.sub = function(y) {
        var d, e, i, j, k, len, pr, rm, xd, xe, xLTy, yd, x = this, Ctor = x.constructor;
        y = new Ctor(y);
        if (!x.d || !y.d) {
          if (!x.s || !y.s) y = new Ctor(NaN);
          else if (x.d) y.s = -y.s;
          else y = new Ctor(y.d || x.s !== y.s ? x : NaN);
          return y;
        }
        if (x.s != y.s) {
          y.s = -y.s;
          return x.plus(y);
        }
        xd = x.d;
        yd = y.d;
        pr = Ctor.precision;
        rm = Ctor.rounding;
        if (!xd[0] || !yd[0]) {
          if (yd[0]) y.s = -y.s;
          else if (xd[0]) y = new Ctor(x);
          else return new Ctor(rm === 3 ? -0 : 0);
          return external ? finalise(y, pr, rm) : y;
        }
        e = mathfloor(y.e / LOG_BASE);
        xe = mathfloor(x.e / LOG_BASE);
        xd = xd.slice();
        k = xe - e;
        if (k) {
          xLTy = k < 0;
          if (xLTy) {
            d = xd;
            k = -k;
            len = yd.length;
          } else {
            d = yd;
            e = xe;
            len = xd.length;
          }
          i = Math.max(Math.ceil(pr / LOG_BASE), len) + 2;
          if (k > i) {
            k = i;
            d.length = 1;
          }
          d.reverse();
          for (i = k; i--; ) d.push(0);
          d.reverse();
        } else {
          i = xd.length;
          len = yd.length;
          xLTy = i < len;
          if (xLTy) len = i;
          for (i = 0; i < len; i++) {
            if (xd[i] != yd[i]) {
              xLTy = xd[i] < yd[i];
              break;
            }
          }
          k = 0;
        }
        if (xLTy) {
          d = xd;
          xd = yd;
          yd = d;
          y.s = -y.s;
        }
        len = xd.length;
        for (i = yd.length - len; i > 0; --i) xd[len++] = 0;
        for (i = yd.length; i > k; ) {
          if (xd[--i] < yd[i]) {
            for (j = i; j && xd[--j] === 0; ) xd[j] = BASE - 1;
            --xd[j];
            xd[i] += BASE;
          }
          xd[i] -= yd[i];
        }
        for (; xd[--len] === 0; ) xd.pop();
        for (; xd[0] === 0; xd.shift()) --e;
        if (!xd[0]) return new Ctor(rm === 3 ? -0 : 0);
        y.d = xd;
        y.e = getBase10Exponent(xd, e);
        return external ? finalise(y, pr, rm) : y;
      };
      P.modulo = P.mod = function(y) {
        var q, x = this, Ctor = x.constructor;
        y = new Ctor(y);
        if (!x.d || !y.s || y.d && !y.d[0]) return new Ctor(NaN);
        if (!y.d || x.d && !x.d[0]) {
          return finalise(new Ctor(x), Ctor.precision, Ctor.rounding);
        }
        external = false;
        if (Ctor.modulo == 9) {
          q = divide(x, y.abs(), 0, 3, 1);
          q.s *= y.s;
        } else {
          q = divide(x, y, 0, Ctor.modulo, 1);
        }
        q = q.times(y);
        external = true;
        return x.minus(q);
      };
      P.naturalExponential = P.exp = function() {
        return naturalExponential(this);
      };
      P.naturalLogarithm = P.ln = function() {
        return naturalLogarithm(this);
      };
      P.negated = P.neg = function() {
        var x = new this.constructor(this);
        x.s = -x.s;
        return finalise(x);
      };
      P.plus = P.add = function(y) {
        var carry, d, e, i, k, len, pr, rm, xd, yd, x = this, Ctor = x.constructor;
        y = new Ctor(y);
        if (!x.d || !y.d) {
          if (!x.s || !y.s) y = new Ctor(NaN);
          else if (!x.d) y = new Ctor(y.d || x.s === y.s ? x : NaN);
          return y;
        }
        if (x.s != y.s) {
          y.s = -y.s;
          return x.minus(y);
        }
        xd = x.d;
        yd = y.d;
        pr = Ctor.precision;
        rm = Ctor.rounding;
        if (!xd[0] || !yd[0]) {
          if (!yd[0]) y = new Ctor(x);
          return external ? finalise(y, pr, rm) : y;
        }
        k = mathfloor(x.e / LOG_BASE);
        e = mathfloor(y.e / LOG_BASE);
        xd = xd.slice();
        i = k - e;
        if (i) {
          if (i < 0) {
            d = xd;
            i = -i;
            len = yd.length;
          } else {
            d = yd;
            e = k;
            len = xd.length;
          }
          k = Math.ceil(pr / LOG_BASE);
          len = k > len ? k + 1 : len + 1;
          if (i > len) {
            i = len;
            d.length = 1;
          }
          d.reverse();
          for (; i--; ) d.push(0);
          d.reverse();
        }
        len = xd.length;
        i = yd.length;
        if (len - i < 0) {
          i = len;
          d = yd;
          yd = xd;
          xd = d;
        }
        for (carry = 0; i; ) {
          carry = (xd[--i] = xd[i] + yd[i] + carry) / BASE | 0;
          xd[i] %= BASE;
        }
        if (carry) {
          xd.unshift(carry);
          ++e;
        }
        for (len = xd.length; xd[--len] == 0; ) xd.pop();
        y.d = xd;
        y.e = getBase10Exponent(xd, e);
        return external ? finalise(y, pr, rm) : y;
      };
      P.precision = P.sd = function(z) {
        var k, x = this;
        if (z !== void 0 && z !== !!z && z !== 1 && z !== 0) throw Error(invalidArgument + z);
        if (x.d) {
          k = getPrecision(x.d);
          if (z && x.e + 1 > k) k = x.e + 1;
        } else {
          k = NaN;
        }
        return k;
      };
      P.round = function() {
        var x = this, Ctor = x.constructor;
        return finalise(new Ctor(x), x.e + 1, Ctor.rounding);
      };
      P.sine = P.sin = function() {
        var pr, rm, x = this, Ctor = x.constructor;
        if (!x.isFinite()) return new Ctor(NaN);
        if (x.isZero()) return new Ctor(x);
        pr = Ctor.precision;
        rm = Ctor.rounding;
        Ctor.precision = pr + Math.max(x.e, x.sd()) + LOG_BASE;
        Ctor.rounding = 1;
        x = sine(Ctor, toLessThanHalfPi(Ctor, x));
        Ctor.precision = pr;
        Ctor.rounding = rm;
        return finalise(quadrant > 2 ? x.neg() : x, pr, rm, true);
      };
      P.squareRoot = P.sqrt = function() {
        var m, n, sd, r, rep, t, x = this, d = x.d, e = x.e, s = x.s, Ctor = x.constructor;
        if (s !== 1 || !d || !d[0]) {
          return new Ctor(!s || s < 0 && (!d || d[0]) ? NaN : d ? x : 1 / 0);
        }
        external = false;
        s = Math.sqrt(+x);
        if (s == 0 || s == 1 / 0) {
          n = digitsToString(d);
          if ((n.length + e) % 2 == 0) n += "0";
          s = Math.sqrt(n);
          e = mathfloor((e + 1) / 2) - (e < 0 || e % 2);
          if (s == 1 / 0) {
            n = "5e" + e;
          } else {
            n = s.toExponential();
            n = n.slice(0, n.indexOf("e") + 1) + e;
          }
          r = new Ctor(n);
        } else {
          r = new Ctor(s.toString());
        }
        sd = (e = Ctor.precision) + 3;
        for (; ; ) {
          t = r;
          r = t.plus(divide(x, t, sd + 2, 1)).times(0.5);
          if (digitsToString(t.d).slice(0, sd) === (n = digitsToString(r.d)).slice(0, sd)) {
            n = n.slice(sd - 3, sd + 1);
            if (n == "9999" || !rep && n == "4999") {
              if (!rep) {
                finalise(t, e + 1, 0);
                if (t.times(t).eq(x)) {
                  r = t;
                  break;
                }
              }
              sd += 4;
              rep = 1;
            } else {
              if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
                finalise(r, e + 1, 1);
                m = !r.times(r).eq(x);
              }
              break;
            }
          }
        }
        external = true;
        return finalise(r, e, Ctor.rounding, m);
      };
      P.tangent = P.tan = function() {
        var pr, rm, x = this, Ctor = x.constructor;
        if (!x.isFinite()) return new Ctor(NaN);
        if (x.isZero()) return new Ctor(x);
        pr = Ctor.precision;
        rm = Ctor.rounding;
        Ctor.precision = pr + 10;
        Ctor.rounding = 1;
        x = x.sin();
        x.s = 1;
        x = divide(x, new Ctor(1).minus(x.times(x)).sqrt(), pr + 10, 0);
        Ctor.precision = pr;
        Ctor.rounding = rm;
        return finalise(quadrant == 2 || quadrant == 4 ? x.neg() : x, pr, rm, true);
      };
      P.times = P.mul = function(y) {
        var carry, e, i, k, r, rL, t, xdL, ydL, x = this, Ctor = x.constructor, xd = x.d, yd = (y = new Ctor(y)).d;
        y.s *= x.s;
        if (!xd || !xd[0] || !yd || !yd[0]) {
          return new Ctor(!y.s || xd && !xd[0] && !yd || yd && !yd[0] && !xd ? NaN : !xd || !yd ? y.s / 0 : y.s * 0);
        }
        e = mathfloor(x.e / LOG_BASE) + mathfloor(y.e / LOG_BASE);
        xdL = xd.length;
        ydL = yd.length;
        if (xdL < ydL) {
          r = xd;
          xd = yd;
          yd = r;
          rL = xdL;
          xdL = ydL;
          ydL = rL;
        }
        r = [];
        rL = xdL + ydL;
        for (i = rL; i--; ) r.push(0);
        for (i = ydL; --i >= 0; ) {
          carry = 0;
          for (k = xdL + i; k > i; ) {
            t = r[k] + yd[i] * xd[k - i - 1] + carry;
            r[k--] = t % BASE | 0;
            carry = t / BASE | 0;
          }
          r[k] = (r[k] + carry) % BASE | 0;
        }
        for (; !r[--rL]; ) r.pop();
        if (carry) ++e;
        else r.shift();
        y.d = r;
        y.e = getBase10Exponent(r, e);
        return external ? finalise(y, Ctor.precision, Ctor.rounding) : y;
      };
      P.toBinary = function(sd, rm) {
        return toStringBinary(this, 2, sd, rm);
      };
      P.toDecimalPlaces = P.toDP = function(dp, rm) {
        var x = this, Ctor = x.constructor;
        x = new Ctor(x);
        if (dp === void 0) return x;
        checkInt32(dp, 0, MAX_DIGITS);
        if (rm === void 0) rm = Ctor.rounding;
        else checkInt32(rm, 0, 8);
        return finalise(x, dp + x.e + 1, rm);
      };
      P.toExponential = function(dp, rm) {
        var str, x = this, Ctor = x.constructor;
        if (dp === void 0) {
          str = finiteToString(x, true);
        } else {
          checkInt32(dp, 0, MAX_DIGITS);
          if (rm === void 0) rm = Ctor.rounding;
          else checkInt32(rm, 0, 8);
          x = finalise(new Ctor(x), dp + 1, rm);
          str = finiteToString(x, true, dp + 1);
        }
        return x.isNeg() && !x.isZero() ? "-" + str : str;
      };
      P.toFixed = function(dp, rm) {
        var str, y, x = this, Ctor = x.constructor;
        if (dp === void 0) {
          str = finiteToString(x);
        } else {
          checkInt32(dp, 0, MAX_DIGITS);
          if (rm === void 0) rm = Ctor.rounding;
          else checkInt32(rm, 0, 8);
          y = finalise(new Ctor(x), dp + x.e + 1, rm);
          str = finiteToString(y, false, dp + y.e + 1);
        }
        return x.isNeg() && !x.isZero() ? "-" + str : str;
      };
      P.toFraction = function(maxD) {
        var d, d0, d1, d2, e, k, n, n0, n1, pr, q, r, x = this, xd = x.d, Ctor = x.constructor;
        if (!xd) return new Ctor(x);
        n1 = d0 = new Ctor(1);
        d1 = n0 = new Ctor(0);
        d = new Ctor(d1);
        e = d.e = getPrecision(xd) - x.e - 1;
        k = e % LOG_BASE;
        d.d[0] = mathpow(10, k < 0 ? LOG_BASE + k : k);
        if (maxD == null) {
          maxD = e > 0 ? d : n1;
        } else {
          n = new Ctor(maxD);
          if (!n.isInt() || n.lt(n1)) throw Error(invalidArgument + n);
          maxD = n.gt(d) ? e > 0 ? d : n1 : n;
        }
        external = false;
        n = new Ctor(digitsToString(xd));
        pr = Ctor.precision;
        Ctor.precision = e = xd.length * LOG_BASE * 2;
        for (; ; ) {
          q = divide(n, d, 0, 1, 1);
          d2 = d0.plus(q.times(d1));
          if (d2.cmp(maxD) == 1) break;
          d0 = d1;
          d1 = d2;
          d2 = n1;
          n1 = n0.plus(q.times(d2));
          n0 = d2;
          d2 = d;
          d = n.minus(q.times(d2));
          n = d2;
        }
        d2 = divide(maxD.minus(d0), d1, 0, 1, 1);
        n0 = n0.plus(d2.times(n1));
        d0 = d0.plus(d2.times(d1));
        n0.s = n1.s = x.s;
        r = divide(n1, d1, e, 1).minus(x).abs().cmp(divide(n0, d0, e, 1).minus(x).abs()) < 1 ? [n1, d1] : [n0, d0];
        Ctor.precision = pr;
        external = true;
        return r;
      };
      P.toHexadecimal = P.toHex = function(sd, rm) {
        return toStringBinary(this, 16, sd, rm);
      };
      P.toNearest = function(y, rm) {
        var x = this, Ctor = x.constructor;
        x = new Ctor(x);
        if (y == null) {
          if (!x.d) return x;
          y = new Ctor(1);
          rm = Ctor.rounding;
        } else {
          y = new Ctor(y);
          if (rm === void 0) {
            rm = Ctor.rounding;
          } else {
            checkInt32(rm, 0, 8);
          }
          if (!x.d) return y.s ? x : y;
          if (!y.d) {
            if (y.s) y.s = x.s;
            return y;
          }
        }
        if (y.d[0]) {
          external = false;
          x = divide(x, y, 0, rm, 1).times(y);
          external = true;
          finalise(x);
        } else {
          y.s = x.s;
          x = y;
        }
        return x;
      };
      P.toNumber = function() {
        return +this;
      };
      P.toOctal = function(sd, rm) {
        return toStringBinary(this, 8, sd, rm);
      };
      P.toPower = P.pow = function(y) {
        var e, k, pr, r, rm, s, x = this, Ctor = x.constructor, yn = +(y = new Ctor(y));
        if (!x.d || !y.d || !x.d[0] || !y.d[0]) return new Ctor(mathpow(+x, yn));
        x = new Ctor(x);
        if (x.eq(1)) return x;
        pr = Ctor.precision;
        rm = Ctor.rounding;
        if (y.eq(1)) return finalise(x, pr, rm);
        e = mathfloor(y.e / LOG_BASE);
        if (e >= y.d.length - 1 && (k = yn < 0 ? -yn : yn) <= MAX_SAFE_INTEGER) {
          r = intPow(Ctor, x, k, pr);
          return y.s < 0 ? new Ctor(1).div(r) : finalise(r, pr, rm);
        }
        s = x.s;
        if (s < 0) {
          if (e < y.d.length - 1) return new Ctor(NaN);
          if ((y.d[e] & 1) == 0) s = 1;
          if (x.e == 0 && x.d[0] == 1 && x.d.length == 1) {
            x.s = s;
            return x;
          }
        }
        k = mathpow(+x, yn);
        e = k == 0 || !isFinite(k) ? mathfloor(yn * (Math.log("0." + digitsToString(x.d)) / Math.LN10 + x.e + 1)) : new Ctor(k + "").e;
        if (e > Ctor.maxE + 1 || e < Ctor.minE - 1) return new Ctor(e > 0 ? s / 0 : 0);
        external = false;
        Ctor.rounding = x.s = 1;
        k = Math.min(12, (e + "").length);
        r = naturalExponential(y.times(naturalLogarithm(x, pr + k)), pr);
        if (r.d) {
          r = finalise(r, pr + 5, 1);
          if (checkRoundingDigits(r.d, pr, rm)) {
            e = pr + 10;
            r = finalise(naturalExponential(y.times(naturalLogarithm(x, e + k)), e), e + 5, 1);
            if (+digitsToString(r.d).slice(pr + 1, pr + 15) + 1 == 1e14) {
              r = finalise(r, pr + 1, 0);
            }
          }
        }
        r.s = s;
        external = true;
        Ctor.rounding = rm;
        return finalise(r, pr, rm);
      };
      P.toPrecision = function(sd, rm) {
        var str, x = this, Ctor = x.constructor;
        if (sd === void 0) {
          str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
        } else {
          checkInt32(sd, 1, MAX_DIGITS);
          if (rm === void 0) rm = Ctor.rounding;
          else checkInt32(rm, 0, 8);
          x = finalise(new Ctor(x), sd, rm);
          str = finiteToString(x, sd <= x.e || x.e <= Ctor.toExpNeg, sd);
        }
        return x.isNeg() && !x.isZero() ? "-" + str : str;
      };
      P.toSignificantDigits = P.toSD = function(sd, rm) {
        var x = this, Ctor = x.constructor;
        if (sd === void 0) {
          sd = Ctor.precision;
          rm = Ctor.rounding;
        } else {
          checkInt32(sd, 1, MAX_DIGITS);
          if (rm === void 0) rm = Ctor.rounding;
          else checkInt32(rm, 0, 8);
        }
        return finalise(new Ctor(x), sd, rm);
      };
      P.toString = function() {
        var x = this, Ctor = x.constructor, str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
        return x.isNeg() && !x.isZero() ? "-" + str : str;
      };
      P.truncated = P.trunc = function() {
        return finalise(new this.constructor(this), this.e + 1, 1);
      };
      P.valueOf = P.toJSON = function() {
        var x = this, Ctor = x.constructor, str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
        return x.isNeg() ? "-" + str : str;
      };
      function digitsToString(d) {
        var i, k, ws, indexOfLastWord = d.length - 1, str = "", w = d[0];
        if (indexOfLastWord > 0) {
          str += w;
          for (i = 1; i < indexOfLastWord; i++) {
            ws = d[i] + "";
            k = LOG_BASE - ws.length;
            if (k) str += getZeroString(k);
            str += ws;
          }
          w = d[i];
          ws = w + "";
          k = LOG_BASE - ws.length;
          if (k) str += getZeroString(k);
        } else if (w === 0) {
          return "0";
        }
        for (; w % 10 === 0; ) w /= 10;
        return str + w;
      }
      function checkInt32(i, min2, max2) {
        if (i !== ~~i || i < min2 || i > max2) {
          throw Error(invalidArgument + i);
        }
      }
      function checkRoundingDigits(d, i, rm, repeating) {
        var di, k, r, rd;
        for (k = d[0]; k >= 10; k /= 10) --i;
        if (--i < 0) {
          i += LOG_BASE;
          di = 0;
        } else {
          di = Math.ceil((i + 1) / LOG_BASE);
          i %= LOG_BASE;
        }
        k = mathpow(10, LOG_BASE - i);
        rd = d[di] % k | 0;
        if (repeating == null) {
          if (i < 3) {
            if (i == 0) rd = rd / 100 | 0;
            else if (i == 1) rd = rd / 10 | 0;
            r = rm < 4 && rd == 99999 || rm > 3 && rd == 49999 || rd == 5e4 || rd == 0;
          } else {
            r = (rm < 4 && rd + 1 == k || rm > 3 && rd + 1 == k / 2) && (d[di + 1] / k / 100 | 0) == mathpow(10, i - 2) - 1 || (rd == k / 2 || rd == 0) && (d[di + 1] / k / 100 | 0) == 0;
          }
        } else {
          if (i < 4) {
            if (i == 0) rd = rd / 1e3 | 0;
            else if (i == 1) rd = rd / 100 | 0;
            else if (i == 2) rd = rd / 10 | 0;
            r = (repeating || rm < 4) && rd == 9999 || !repeating && rm > 3 && rd == 4999;
          } else {
            r = ((repeating || rm < 4) && rd + 1 == k || !repeating && rm > 3 && rd + 1 == k / 2) && (d[di + 1] / k / 1e3 | 0) == mathpow(10, i - 3) - 1;
          }
        }
        return r;
      }
      function convertBase(str, baseIn, baseOut) {
        var j, arr = [0], arrL, i = 0, strL = str.length;
        for (; i < strL; ) {
          for (arrL = arr.length; arrL--; ) arr[arrL] *= baseIn;
          arr[0] += NUMERALS.indexOf(str.charAt(i++));
          for (j = 0; j < arr.length; j++) {
            if (arr[j] > baseOut - 1) {
              if (arr[j + 1] === void 0) arr[j + 1] = 0;
              arr[j + 1] += arr[j] / baseOut | 0;
              arr[j] %= baseOut;
            }
          }
        }
        return arr.reverse();
      }
      function cosine(Ctor, x) {
        var k, len, y;
        if (x.isZero()) return x;
        len = x.d.length;
        if (len < 32) {
          k = Math.ceil(len / 3);
          y = (1 / tinyPow(4, k)).toString();
        } else {
          k = 16;
          y = "2.3283064365386962890625e-10";
        }
        Ctor.precision += k;
        x = taylorSeries(Ctor, 1, x.times(y), new Ctor(1));
        for (var i = k; i--; ) {
          var cos2x = x.times(x);
          x = cos2x.times(cos2x).minus(cos2x).times(8).plus(1);
        }
        Ctor.precision -= k;
        return x;
      }
      var divide = /* @__PURE__ */ function() {
        function multiplyInteger(x, k, base) {
          var temp, carry = 0, i = x.length;
          for (x = x.slice(); i--; ) {
            temp = x[i] * k + carry;
            x[i] = temp % base | 0;
            carry = temp / base | 0;
          }
          if (carry) x.unshift(carry);
          return x;
        }
        function compare(a, b, aL, bL) {
          var i, r;
          if (aL != bL) {
            r = aL > bL ? 1 : -1;
          } else {
            for (i = r = 0; i < aL; i++) {
              if (a[i] != b[i]) {
                r = a[i] > b[i] ? 1 : -1;
                break;
              }
            }
          }
          return r;
        }
        function subtract(a, b, aL, base) {
          var i = 0;
          for (; aL--; ) {
            a[aL] -= i;
            i = a[aL] < b[aL] ? 1 : 0;
            a[aL] = i * base + a[aL] - b[aL];
          }
          for (; !a[0] && a.length > 1; ) a.shift();
        }
        return function(x, y, pr, rm, dp, base) {
          var cmp, e, i, k, logBase, more, prod, prodL, q, qd, rem, remL, rem0, sd, t, xi, xL, yd0, yL, yz, Ctor = x.constructor, sign2 = x.s == y.s ? 1 : -1, xd = x.d, yd = y.d;
          if (!xd || !xd[0] || !yd || !yd[0]) {
            return new Ctor(
              // Return NaN if either NaN, or both Infinity or 0.
              !x.s || !y.s || (xd ? yd && xd[0] == yd[0] : !yd) ? NaN : (
                // Return ±0 if x is 0 or y is ±Infinity, or return ±Infinity as y is 0.
                xd && xd[0] == 0 || !yd ? sign2 * 0 : sign2 / 0
              )
            );
          }
          if (base) {
            logBase = 1;
            e = x.e - y.e;
          } else {
            base = BASE;
            logBase = LOG_BASE;
            e = mathfloor(x.e / logBase) - mathfloor(y.e / logBase);
          }
          yL = yd.length;
          xL = xd.length;
          q = new Ctor(sign2);
          qd = q.d = [];
          for (i = 0; yd[i] == (xd[i] || 0); i++) ;
          if (yd[i] > (xd[i] || 0)) e--;
          if (pr == null) {
            sd = pr = Ctor.precision;
            rm = Ctor.rounding;
          } else if (dp) {
            sd = pr + (x.e - y.e) + 1;
          } else {
            sd = pr;
          }
          if (sd < 0) {
            qd.push(1);
            more = true;
          } else {
            sd = sd / logBase + 2 | 0;
            i = 0;
            if (yL == 1) {
              k = 0;
              yd = yd[0];
              sd++;
              for (; (i < xL || k) && sd--; i++) {
                t = k * base + (xd[i] || 0);
                qd[i] = t / yd | 0;
                k = t % yd | 0;
              }
              more = k || i < xL;
            } else {
              k = base / (yd[0] + 1) | 0;
              if (k > 1) {
                yd = multiplyInteger(yd, k, base);
                xd = multiplyInteger(xd, k, base);
                yL = yd.length;
                xL = xd.length;
              }
              xi = yL;
              rem = xd.slice(0, yL);
              remL = rem.length;
              for (; remL < yL; ) rem[remL++] = 0;
              yz = yd.slice();
              yz.unshift(0);
              yd0 = yd[0];
              if (yd[1] >= base / 2) ++yd0;
              do {
                k = 0;
                cmp = compare(yd, rem, yL, remL);
                if (cmp < 0) {
                  rem0 = rem[0];
                  if (yL != remL) rem0 = rem0 * base + (rem[1] || 0);
                  k = rem0 / yd0 | 0;
                  if (k > 1) {
                    if (k >= base) k = base - 1;
                    prod = multiplyInteger(yd, k, base);
                    prodL = prod.length;
                    remL = rem.length;
                    cmp = compare(prod, rem, prodL, remL);
                    if (cmp == 1) {
                      k--;
                      subtract(prod, yL < prodL ? yz : yd, prodL, base);
                    }
                  } else {
                    if (k == 0) cmp = k = 1;
                    prod = yd.slice();
                  }
                  prodL = prod.length;
                  if (prodL < remL) prod.unshift(0);
                  subtract(rem, prod, remL, base);
                  if (cmp == -1) {
                    remL = rem.length;
                    cmp = compare(yd, rem, yL, remL);
                    if (cmp < 1) {
                      k++;
                      subtract(rem, yL < remL ? yz : yd, remL, base);
                    }
                  }
                  remL = rem.length;
                } else if (cmp === 0) {
                  k++;
                  rem = [0];
                }
                qd[i++] = k;
                if (cmp && rem[0]) {
                  rem[remL++] = xd[xi] || 0;
                } else {
                  rem = [xd[xi]];
                  remL = 1;
                }
              } while ((xi++ < xL || rem[0] !== void 0) && sd--);
              more = rem[0] !== void 0;
            }
            if (!qd[0]) qd.shift();
          }
          if (logBase == 1) {
            q.e = e;
            inexact = more;
          } else {
            for (i = 1, k = qd[0]; k >= 10; k /= 10) i++;
            q.e = i + e * logBase - 1;
            finalise(q, dp ? pr + q.e + 1 : pr, rm, more);
          }
          return q;
        };
      }();
      function finalise(x, sd, rm, isTruncated) {
        var digits, i, j, k, rd, roundUp, w, xd, xdi, Ctor = x.constructor;
        out: if (sd != null) {
          xd = x.d;
          if (!xd) return x;
          for (digits = 1, k = xd[0]; k >= 10; k /= 10) digits++;
          i = sd - digits;
          if (i < 0) {
            i += LOG_BASE;
            j = sd;
            w = xd[xdi = 0];
            rd = w / mathpow(10, digits - j - 1) % 10 | 0;
          } else {
            xdi = Math.ceil((i + 1) / LOG_BASE);
            k = xd.length;
            if (xdi >= k) {
              if (isTruncated) {
                for (; k++ <= xdi; ) xd.push(0);
                w = rd = 0;
                digits = 1;
                i %= LOG_BASE;
                j = i - LOG_BASE + 1;
              } else {
                break out;
              }
            } else {
              w = k = xd[xdi];
              for (digits = 1; k >= 10; k /= 10) digits++;
              i %= LOG_BASE;
              j = i - LOG_BASE + digits;
              rd = j < 0 ? 0 : w / mathpow(10, digits - j - 1) % 10 | 0;
            }
          }
          isTruncated = isTruncated || sd < 0 || xd[xdi + 1] !== void 0 || (j < 0 ? w : w % mathpow(10, digits - j - 1));
          roundUp = rm < 4 ? (rd || isTruncated) && (rm == 0 || rm == (x.s < 0 ? 3 : 2)) : rd > 5 || rd == 5 && (rm == 4 || isTruncated || rm == 6 && // Check whether the digit to the left of the rounding digit is odd.
          (i > 0 ? j > 0 ? w / mathpow(10, digits - j) : 0 : xd[xdi - 1]) % 10 & 1 || rm == (x.s < 0 ? 8 : 7));
          if (sd < 1 || !xd[0]) {
            xd.length = 0;
            if (roundUp) {
              sd -= x.e + 1;
              xd[0] = mathpow(10, (LOG_BASE - sd % LOG_BASE) % LOG_BASE);
              x.e = -sd || 0;
            } else {
              xd[0] = x.e = 0;
            }
            return x;
          }
          if (i == 0) {
            xd.length = xdi;
            k = 1;
            xdi--;
          } else {
            xd.length = xdi + 1;
            k = mathpow(10, LOG_BASE - i);
            xd[xdi] = j > 0 ? (w / mathpow(10, digits - j) % mathpow(10, j) | 0) * k : 0;
          }
          if (roundUp) {
            for (; ; ) {
              if (xdi == 0) {
                for (i = 1, j = xd[0]; j >= 10; j /= 10) i++;
                j = xd[0] += k;
                for (k = 1; j >= 10; j /= 10) k++;
                if (i != k) {
                  x.e++;
                  if (xd[0] == BASE) xd[0] = 1;
                }
                break;
              } else {
                xd[xdi] += k;
                if (xd[xdi] != BASE) break;
                xd[xdi--] = 0;
                k = 1;
              }
            }
          }
          for (i = xd.length; xd[--i] === 0; ) xd.pop();
        }
        if (external) {
          if (x.e > Ctor.maxE) {
            x.d = null;
            x.e = NaN;
          } else if (x.e < Ctor.minE) {
            x.e = 0;
            x.d = [0];
          }
        }
        return x;
      }
      function finiteToString(x, isExp, sd) {
        if (!x.isFinite()) return nonFiniteToString(x);
        var k, e = x.e, str = digitsToString(x.d), len = str.length;
        if (isExp) {
          if (sd && (k = sd - len) > 0) {
            str = str.charAt(0) + "." + str.slice(1) + getZeroString(k);
          } else if (len > 1) {
            str = str.charAt(0) + "." + str.slice(1);
          }
          str = str + (x.e < 0 ? "e" : "e+") + x.e;
        } else if (e < 0) {
          str = "0." + getZeroString(-e - 1) + str;
          if (sd && (k = sd - len) > 0) str += getZeroString(k);
        } else if (e >= len) {
          str += getZeroString(e + 1 - len);
          if (sd && (k = sd - e - 1) > 0) str = str + "." + getZeroString(k);
        } else {
          if ((k = e + 1) < len) str = str.slice(0, k) + "." + str.slice(k);
          if (sd && (k = sd - len) > 0) {
            if (e + 1 === len) str += ".";
            str += getZeroString(k);
          }
        }
        return str;
      }
      function getBase10Exponent(digits, e) {
        var w = digits[0];
        for (e *= LOG_BASE; w >= 10; w /= 10) e++;
        return e;
      }
      function getLn10(Ctor, sd, pr) {
        if (sd > LN10_PRECISION) {
          external = true;
          if (pr) Ctor.precision = pr;
          throw Error(precisionLimitExceeded);
        }
        return finalise(new Ctor(LN10), sd, 1, true);
      }
      function getPi(Ctor, sd, rm) {
        if (sd > PI_PRECISION) throw Error(precisionLimitExceeded);
        return finalise(new Ctor(PI), sd, rm, true);
      }
      function getPrecision(digits) {
        var w = digits.length - 1, len = w * LOG_BASE + 1;
        w = digits[w];
        if (w) {
          for (; w % 10 == 0; w /= 10) len--;
          for (w = digits[0]; w >= 10; w /= 10) len++;
        }
        return len;
      }
      function getZeroString(k) {
        var zs = "";
        for (; k--; ) zs += "0";
        return zs;
      }
      function intPow(Ctor, x, n, pr) {
        var isTruncated, r = new Ctor(1), k = Math.ceil(pr / LOG_BASE + 4);
        external = false;
        for (; ; ) {
          if (n % 2) {
            r = r.times(x);
            if (truncate(r.d, k)) isTruncated = true;
          }
          n = mathfloor(n / 2);
          if (n === 0) {
            n = r.d.length - 1;
            if (isTruncated && r.d[n] === 0) ++r.d[n];
            break;
          }
          x = x.times(x);
          truncate(x.d, k);
        }
        external = true;
        return r;
      }
      function isOdd(n) {
        return n.d[n.d.length - 1] & 1;
      }
      function maxOrMin(Ctor, args2, n) {
        var k, y, x = new Ctor(args2[0]), i = 0;
        for (; ++i < args2.length; ) {
          y = new Ctor(args2[i]);
          if (!y.s) {
            x = y;
            break;
          }
          k = x.cmp(y);
          if (k === n || k === 0 && x.s === n) {
            x = y;
          }
        }
        return x;
      }
      function naturalExponential(x, sd) {
        var denominator, guard, j, pow2, sum2, t, wpr, rep = 0, i = 0, k = 0, Ctor = x.constructor, rm = Ctor.rounding, pr = Ctor.precision;
        if (!x.d || !x.d[0] || x.e > 17) {
          return new Ctor(x.d ? !x.d[0] ? 1 : x.s < 0 ? 0 : 1 / 0 : x.s ? x.s < 0 ? 0 : x : 0 / 0);
        }
        if (sd == null) {
          external = false;
          wpr = pr;
        } else {
          wpr = sd;
        }
        t = new Ctor(0.03125);
        while (x.e > -2) {
          x = x.times(t);
          k += 5;
        }
        guard = Math.log(mathpow(2, k)) / Math.LN10 * 2 + 5 | 0;
        wpr += guard;
        denominator = pow2 = sum2 = new Ctor(1);
        Ctor.precision = wpr;
        for (; ; ) {
          pow2 = finalise(pow2.times(x), wpr, 1);
          denominator = denominator.times(++i);
          t = sum2.plus(divide(pow2, denominator, wpr, 1));
          if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum2.d).slice(0, wpr)) {
            j = k;
            while (j--) sum2 = finalise(sum2.times(sum2), wpr, 1);
            if (sd == null) {
              if (rep < 3 && checkRoundingDigits(sum2.d, wpr - guard, rm, rep)) {
                Ctor.precision = wpr += 10;
                denominator = pow2 = t = new Ctor(1);
                i = 0;
                rep++;
              } else {
                return finalise(sum2, Ctor.precision = pr, rm, external = true);
              }
            } else {
              Ctor.precision = pr;
              return sum2;
            }
          }
          sum2 = t;
        }
      }
      function naturalLogarithm(y, sd) {
        var c, c0, denominator, e, numerator, rep, sum2, t, wpr, x1, x2, n = 1, guard = 10, x = y, xd = x.d, Ctor = x.constructor, rm = Ctor.rounding, pr = Ctor.precision;
        if (x.s < 0 || !xd || !xd[0] || !x.e && xd[0] == 1 && xd.length == 1) {
          return new Ctor(xd && !xd[0] ? -1 / 0 : x.s != 1 ? NaN : xd ? 0 : x);
        }
        if (sd == null) {
          external = false;
          wpr = pr;
        } else {
          wpr = sd;
        }
        Ctor.precision = wpr += guard;
        c = digitsToString(xd);
        c0 = c.charAt(0);
        if (Math.abs(e = x.e) < 15e14) {
          while (c0 < 7 && c0 != 1 || c0 == 1 && c.charAt(1) > 3) {
            x = x.times(y);
            c = digitsToString(x.d);
            c0 = c.charAt(0);
            n++;
          }
          e = x.e;
          if (c0 > 1) {
            x = new Ctor("0." + c);
            e++;
          } else {
            x = new Ctor(c0 + "." + c.slice(1));
          }
        } else {
          t = getLn10(Ctor, wpr + 2, pr).times(e + "");
          x = naturalLogarithm(new Ctor(c0 + "." + c.slice(1)), wpr - guard).plus(t);
          Ctor.precision = pr;
          return sd == null ? finalise(x, pr, rm, external = true) : x;
        }
        x1 = x;
        sum2 = numerator = x = divide(x.minus(1), x.plus(1), wpr, 1);
        x2 = finalise(x.times(x), wpr, 1);
        denominator = 3;
        for (; ; ) {
          numerator = finalise(numerator.times(x2), wpr, 1);
          t = sum2.plus(divide(numerator, new Ctor(denominator), wpr, 1));
          if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum2.d).slice(0, wpr)) {
            sum2 = sum2.times(2);
            if (e !== 0) sum2 = sum2.plus(getLn10(Ctor, wpr + 2, pr).times(e + ""));
            sum2 = divide(sum2, new Ctor(n), wpr, 1);
            if (sd == null) {
              if (checkRoundingDigits(sum2.d, wpr - guard, rm, rep)) {
                Ctor.precision = wpr += guard;
                t = numerator = x = divide(x1.minus(1), x1.plus(1), wpr, 1);
                x2 = finalise(x.times(x), wpr, 1);
                denominator = rep = 1;
              } else {
                return finalise(sum2, Ctor.precision = pr, rm, external = true);
              }
            } else {
              Ctor.precision = pr;
              return sum2;
            }
          }
          sum2 = t;
          denominator += 2;
        }
      }
      function nonFiniteToString(x) {
        return String(x.s * x.s / 0);
      }
      function parseDecimal(x, str) {
        var e, i, len;
        if ((e = str.indexOf(".")) > -1) str = str.replace(".", "");
        if ((i = str.search(/e/i)) > 0) {
          if (e < 0) e = i;
          e += +str.slice(i + 1);
          str = str.substring(0, i);
        } else if (e < 0) {
          e = str.length;
        }
        for (i = 0; str.charCodeAt(i) === 48; i++) ;
        for (len = str.length; str.charCodeAt(len - 1) === 48; --len) ;
        str = str.slice(i, len);
        if (str) {
          len -= i;
          x.e = e = e - i - 1;
          x.d = [];
          i = (e + 1) % LOG_BASE;
          if (e < 0) i += LOG_BASE;
          if (i < len) {
            if (i) x.d.push(+str.slice(0, i));
            for (len -= LOG_BASE; i < len; ) x.d.push(+str.slice(i, i += LOG_BASE));
            str = str.slice(i);
            i = LOG_BASE - str.length;
          } else {
            i -= len;
          }
          for (; i--; ) str += "0";
          x.d.push(+str);
          if (external) {
            if (x.e > x.constructor.maxE) {
              x.d = null;
              x.e = NaN;
            } else if (x.e < x.constructor.minE) {
              x.e = 0;
              x.d = [0];
            }
          }
        } else {
          x.e = 0;
          x.d = [0];
        }
        return x;
      }
      function parseOther(x, str) {
        var base, Ctor, divisor, i, isFloat, len, p, xd, xe;
        if (str.indexOf("_") > -1) {
          str = str.replace(/(\d)_(?=\d)/g, "$1");
          if (isDecimal.test(str)) return parseDecimal(x, str);
        } else if (str === "Infinity" || str === "NaN") {
          if (!+str) x.s = NaN;
          x.e = NaN;
          x.d = null;
          return x;
        }
        if (isHex.test(str)) {
          base = 16;
          str = str.toLowerCase();
        } else if (isBinary.test(str)) {
          base = 2;
        } else if (isOctal.test(str)) {
          base = 8;
        } else {
          throw Error(invalidArgument + str);
        }
        i = str.search(/p/i);
        if (i > 0) {
          p = +str.slice(i + 1);
          str = str.substring(2, i);
        } else {
          str = str.slice(2);
        }
        i = str.indexOf(".");
        isFloat = i >= 0;
        Ctor = x.constructor;
        if (isFloat) {
          str = str.replace(".", "");
          len = str.length;
          i = len - i;
          divisor = intPow(Ctor, new Ctor(base), i, i * 2);
        }
        xd = convertBase(str, base, BASE);
        xe = xd.length - 1;
        for (i = xe; xd[i] === 0; --i) xd.pop();
        if (i < 0) return new Ctor(x.s * 0);
        x.e = getBase10Exponent(xd, xe);
        x.d = xd;
        external = false;
        if (isFloat) x = divide(x, divisor, len * 4);
        if (p) x = x.times(Math.abs(p) < 54 ? mathpow(2, p) : Decimal.pow(2, p));
        external = true;
        return x;
      }
      function sine(Ctor, x) {
        var k, len = x.d.length;
        if (len < 3) {
          return x.isZero() ? x : taylorSeries(Ctor, 2, x, x);
        }
        k = 1.4 * Math.sqrt(len);
        k = k > 16 ? 16 : k | 0;
        x = x.times(1 / tinyPow(5, k));
        x = taylorSeries(Ctor, 2, x, x);
        var sin2_x, d5 = new Ctor(5), d16 = new Ctor(16), d20 = new Ctor(20);
        for (; k--; ) {
          sin2_x = x.times(x);
          x = x.times(d5.plus(sin2_x.times(d16.times(sin2_x).minus(d20))));
        }
        return x;
      }
      function taylorSeries(Ctor, n, x, y, isHyperbolic) {
        var j, t, u, x2, i = 1, pr = Ctor.precision, k = Math.ceil(pr / LOG_BASE);
        external = false;
        x2 = x.times(x);
        u = new Ctor(y);
        for (; ; ) {
          t = divide(u.times(x2), new Ctor(n++ * n++), pr, 1);
          u = isHyperbolic ? y.plus(t) : y.minus(t);
          y = divide(t.times(x2), new Ctor(n++ * n++), pr, 1);
          t = u.plus(y);
          if (t.d[k] !== void 0) {
            for (j = k; t.d[j] === u.d[j] && j--; ) ;
            if (j == -1) break;
          }
          j = u;
          u = y;
          y = t;
          t = j;
          i++;
        }
        external = true;
        t.d.length = k + 1;
        return t;
      }
      function tinyPow(b, e) {
        var n = b;
        while (--e) n *= b;
        return n;
      }
      function toLessThanHalfPi(Ctor, x) {
        var t, isNeg = x.s < 0, pi = getPi(Ctor, Ctor.precision, 1), halfPi = pi.times(0.5);
        x = x.abs();
        if (x.lte(halfPi)) {
          quadrant = isNeg ? 4 : 1;
          return x;
        }
        t = x.divToInt(pi);
        if (t.isZero()) {
          quadrant = isNeg ? 3 : 2;
        } else {
          x = x.minus(t.times(pi));
          if (x.lte(halfPi)) {
            quadrant = isOdd(t) ? isNeg ? 2 : 3 : isNeg ? 4 : 1;
            return x;
          }
          quadrant = isOdd(t) ? isNeg ? 1 : 4 : isNeg ? 3 : 2;
        }
        return x.minus(pi).abs();
      }
      function toStringBinary(x, baseOut, sd, rm) {
        var base, e, i, k, len, roundUp, str, xd, y, Ctor = x.constructor, isExp = sd !== void 0;
        if (isExp) {
          checkInt32(sd, 1, MAX_DIGITS);
          if (rm === void 0) rm = Ctor.rounding;
          else checkInt32(rm, 0, 8);
        } else {
          sd = Ctor.precision;
          rm = Ctor.rounding;
        }
        if (!x.isFinite()) {
          str = nonFiniteToString(x);
        } else {
          str = finiteToString(x);
          i = str.indexOf(".");
          if (isExp) {
            base = 2;
            if (baseOut == 16) {
              sd = sd * 4 - 3;
            } else if (baseOut == 8) {
              sd = sd * 3 - 2;
            }
          } else {
            base = baseOut;
          }
          if (i >= 0) {
            str = str.replace(".", "");
            y = new Ctor(1);
            y.e = str.length - i;
            y.d = convertBase(finiteToString(y), 10, base);
            y.e = y.d.length;
          }
          xd = convertBase(str, 10, base);
          e = len = xd.length;
          for (; xd[--len] == 0; ) xd.pop();
          if (!xd[0]) {
            str = isExp ? "0p+0" : "0";
          } else {
            if (i < 0) {
              e--;
            } else {
              x = new Ctor(x);
              x.d = xd;
              x.e = e;
              x = divide(x, y, sd, rm, 0, base);
              xd = x.d;
              e = x.e;
              roundUp = inexact;
            }
            i = xd[sd];
            k = base / 2;
            roundUp = roundUp || xd[sd + 1] !== void 0;
            roundUp = rm < 4 ? (i !== void 0 || roundUp) && (rm === 0 || rm === (x.s < 0 ? 3 : 2)) : i > k || i === k && (rm === 4 || roundUp || rm === 6 && xd[sd - 1] & 1 || rm === (x.s < 0 ? 8 : 7));
            xd.length = sd;
            if (roundUp) {
              for (; ++xd[--sd] > base - 1; ) {
                xd[sd] = 0;
                if (!sd) {
                  ++e;
                  xd.unshift(1);
                }
              }
            }
            for (len = xd.length; !xd[len - 1]; --len) ;
            for (i = 0, str = ""; i < len; i++) str += NUMERALS.charAt(xd[i]);
            if (isExp) {
              if (len > 1) {
                if (baseOut == 16 || baseOut == 8) {
                  i = baseOut == 16 ? 4 : 3;
                  for (--len; len % i; len++) str += "0";
                  xd = convertBase(str, base, baseOut);
                  for (len = xd.length; !xd[len - 1]; --len) ;
                  for (i = 1, str = "1."; i < len; i++) str += NUMERALS.charAt(xd[i]);
                } else {
                  str = str.charAt(0) + "." + str.slice(1);
                }
              }
              str = str + (e < 0 ? "p" : "p+") + e;
            } else if (e < 0) {
              for (; ++e; ) str = "0" + str;
              str = "0." + str;
            } else {
              if (++e > len) for (e -= len; e--; ) str += "0";
              else if (e < len) str = str.slice(0, e) + "." + str.slice(e);
            }
          }
          str = (baseOut == 16 ? "0x" : baseOut == 2 ? "0b" : baseOut == 8 ? "0o" : "") + str;
        }
        return x.s < 0 ? "-" + str : str;
      }
      function truncate(arr, len) {
        if (arr.length > len) {
          arr.length = len;
          return true;
        }
      }
      function abs(x) {
        return new this(x).abs();
      }
      function acos(x) {
        return new this(x).acos();
      }
      function acosh(x) {
        return new this(x).acosh();
      }
      function add(x, y) {
        return new this(x).plus(y);
      }
      function asin(x) {
        return new this(x).asin();
      }
      function asinh(x) {
        return new this(x).asinh();
      }
      function atan(x) {
        return new this(x).atan();
      }
      function atanh(x) {
        return new this(x).atanh();
      }
      function atan2(y, x) {
        y = new this(y);
        x = new this(x);
        var r, pr = this.precision, rm = this.rounding, wpr = pr + 4;
        if (!y.s || !x.s) {
          r = new this(NaN);
        } else if (!y.d && !x.d) {
          r = getPi(this, wpr, 1).times(x.s > 0 ? 0.25 : 0.75);
          r.s = y.s;
        } else if (!x.d || y.isZero()) {
          r = x.s < 0 ? getPi(this, pr, rm) : new this(0);
          r.s = y.s;
        } else if (!y.d || x.isZero()) {
          r = getPi(this, wpr, 1).times(0.5);
          r.s = y.s;
        } else if (x.s < 0) {
          this.precision = wpr;
          this.rounding = 1;
          r = this.atan(divide(y, x, wpr, 1));
          x = getPi(this, wpr, 1);
          this.precision = pr;
          this.rounding = rm;
          r = y.s < 0 ? r.minus(x) : r.plus(x);
        } else {
          r = this.atan(divide(y, x, wpr, 1));
        }
        return r;
      }
      function cbrt(x) {
        return new this(x).cbrt();
      }
      function ceil(x) {
        return finalise(x = new this(x), x.e + 1, 2);
      }
      function clamp(x, min2, max2) {
        return new this(x).clamp(min2, max2);
      }
      function config(obj) {
        if (!obj || typeof obj !== "object") throw Error(decimalError + "Object expected");
        var i, p, v, useDefaults = obj.defaults === true, ps = [
          "precision",
          1,
          MAX_DIGITS,
          "rounding",
          0,
          8,
          "toExpNeg",
          -EXP_LIMIT,
          0,
          "toExpPos",
          0,
          EXP_LIMIT,
          "maxE",
          0,
          EXP_LIMIT,
          "minE",
          -EXP_LIMIT,
          0,
          "modulo",
          0,
          9
        ];
        for (i = 0; i < ps.length; i += 3) {
          if (p = ps[i], useDefaults) this[p] = DEFAULTS[p];
          if ((v = obj[p]) !== void 0) {
            if (mathfloor(v) === v && v >= ps[i + 1] && v <= ps[i + 2]) this[p] = v;
            else throw Error(invalidArgument + p + ": " + v);
          }
        }
        if (p = "crypto", useDefaults) this[p] = DEFAULTS[p];
        if ((v = obj[p]) !== void 0) {
          if (v === true || v === false || v === 0 || v === 1) {
            if (v) {
              if (typeof crypto != "undefined" && crypto && (crypto.getRandomValues || crypto.randomBytes)) {
                this[p] = true;
              } else {
                throw Error(cryptoUnavailable);
              }
            } else {
              this[p] = false;
            }
          } else {
            throw Error(invalidArgument + p + ": " + v);
          }
        }
        return this;
      }
      function cos(x) {
        return new this(x).cos();
      }
      function cosh(x) {
        return new this(x).cosh();
      }
      function clone(obj) {
        var i, p, ps;
        function Decimal2(v) {
          var e, i2, t, x = this;
          if (!(x instanceof Decimal2)) return new Decimal2(v);
          x.constructor = Decimal2;
          if (isDecimalInstance(v)) {
            x.s = v.s;
            if (external) {
              if (!v.d || v.e > Decimal2.maxE) {
                x.e = NaN;
                x.d = null;
              } else if (v.e < Decimal2.minE) {
                x.e = 0;
                x.d = [0];
              } else {
                x.e = v.e;
                x.d = v.d.slice();
              }
            } else {
              x.e = v.e;
              x.d = v.d ? v.d.slice() : v.d;
            }
            return;
          }
          t = typeof v;
          if (t === "number") {
            if (v === 0) {
              x.s = 1 / v < 0 ? -1 : 1;
              x.e = 0;
              x.d = [0];
              return;
            }
            if (v < 0) {
              v = -v;
              x.s = -1;
            } else {
              x.s = 1;
            }
            if (v === ~~v && v < 1e7) {
              for (e = 0, i2 = v; i2 >= 10; i2 /= 10) e++;
              if (external) {
                if (e > Decimal2.maxE) {
                  x.e = NaN;
                  x.d = null;
                } else if (e < Decimal2.minE) {
                  x.e = 0;
                  x.d = [0];
                } else {
                  x.e = e;
                  x.d = [v];
                }
              } else {
                x.e = e;
                x.d = [v];
              }
              return;
            }
            if (v * 0 !== 0) {
              if (!v) x.s = NaN;
              x.e = NaN;
              x.d = null;
              return;
            }
            return parseDecimal(x, v.toString());
          }
          if (t === "string") {
            if ((i2 = v.charCodeAt(0)) === 45) {
              v = v.slice(1);
              x.s = -1;
            } else {
              if (i2 === 43) v = v.slice(1);
              x.s = 1;
            }
            return isDecimal.test(v) ? parseDecimal(x, v) : parseOther(x, v);
          }
          if (t === "bigint") {
            if (v < 0) {
              v = -v;
              x.s = -1;
            } else {
              x.s = 1;
            }
            return parseDecimal(x, v.toString());
          }
          throw Error(invalidArgument + v);
        }
        Decimal2.prototype = P;
        Decimal2.ROUND_UP = 0;
        Decimal2.ROUND_DOWN = 1;
        Decimal2.ROUND_CEIL = 2;
        Decimal2.ROUND_FLOOR = 3;
        Decimal2.ROUND_HALF_UP = 4;
        Decimal2.ROUND_HALF_DOWN = 5;
        Decimal2.ROUND_HALF_EVEN = 6;
        Decimal2.ROUND_HALF_CEIL = 7;
        Decimal2.ROUND_HALF_FLOOR = 8;
        Decimal2.EUCLID = 9;
        Decimal2.config = Decimal2.set = config;
        Decimal2.clone = clone;
        Decimal2.isDecimal = isDecimalInstance;
        Decimal2.abs = abs;
        Decimal2.acos = acos;
        Decimal2.acosh = acosh;
        Decimal2.add = add;
        Decimal2.asin = asin;
        Decimal2.asinh = asinh;
        Decimal2.atan = atan;
        Decimal2.atanh = atanh;
        Decimal2.atan2 = atan2;
        Decimal2.cbrt = cbrt;
        Decimal2.ceil = ceil;
        Decimal2.clamp = clamp;
        Decimal2.cos = cos;
        Decimal2.cosh = cosh;
        Decimal2.div = div;
        Decimal2.exp = exp;
        Decimal2.floor = floor;
        Decimal2.hypot = hypot;
        Decimal2.ln = ln;
        Decimal2.log = log;
        Decimal2.log10 = log10;
        Decimal2.log2 = log2;
        Decimal2.max = max;
        Decimal2.min = min;
        Decimal2.mod = mod;
        Decimal2.mul = mul;
        Decimal2.pow = pow;
        Decimal2.random = random;
        Decimal2.round = round;
        Decimal2.sign = sign;
        Decimal2.sin = sin;
        Decimal2.sinh = sinh;
        Decimal2.sqrt = sqrt;
        Decimal2.sub = sub;
        Decimal2.sum = sum;
        Decimal2.tan = tan;
        Decimal2.tanh = tanh;
        Decimal2.trunc = trunc;
        if (obj === void 0) obj = {};
        if (obj) {
          if (obj.defaults !== true) {
            ps = ["precision", "rounding", "toExpNeg", "toExpPos", "maxE", "minE", "modulo", "crypto"];
            for (i = 0; i < ps.length; ) if (!obj.hasOwnProperty(p = ps[i++])) obj[p] = this[p];
          }
        }
        Decimal2.config(obj);
        return Decimal2;
      }
      function div(x, y) {
        return new this(x).div(y);
      }
      function exp(x) {
        return new this(x).exp();
      }
      function floor(x) {
        return finalise(x = new this(x), x.e + 1, 3);
      }
      function hypot() {
        var i, n, t = new this(0);
        external = false;
        for (i = 0; i < arguments.length; ) {
          n = new this(arguments[i++]);
          if (!n.d) {
            if (n.s) {
              external = true;
              return new this(1 / 0);
            }
            t = n;
          } else if (t.d) {
            t = t.plus(n.times(n));
          }
        }
        external = true;
        return t.sqrt();
      }
      function isDecimalInstance(obj) {
        return obj instanceof Decimal || obj && obj.toStringTag === tag || false;
      }
      function ln(x) {
        return new this(x).ln();
      }
      function log(x, y) {
        return new this(x).log(y);
      }
      function log2(x) {
        return new this(x).log(2);
      }
      function log10(x) {
        return new this(x).log(10);
      }
      function max() {
        return maxOrMin(this, arguments, -1);
      }
      function min() {
        return maxOrMin(this, arguments, 1);
      }
      function mod(x, y) {
        return new this(x).mod(y);
      }
      function mul(x, y) {
        return new this(x).mul(y);
      }
      function pow(x, y) {
        return new this(x).pow(y);
      }
      function random(sd) {
        var d, e, k, n, i = 0, r = new this(1), rd = [];
        if (sd === void 0) sd = this.precision;
        else checkInt32(sd, 1, MAX_DIGITS);
        k = Math.ceil(sd / LOG_BASE);
        if (!this.crypto) {
          for (; i < k; ) rd[i++] = Math.random() * 1e7 | 0;
        } else if (crypto.getRandomValues) {
          d = crypto.getRandomValues(new Uint32Array(k));
          for (; i < k; ) {
            n = d[i];
            if (n >= 429e7) {
              d[i] = crypto.getRandomValues(new Uint32Array(1))[0];
            } else {
              rd[i++] = n % 1e7;
            }
          }
        } else if (crypto.randomBytes) {
          d = crypto.randomBytes(k *= 4);
          for (; i < k; ) {
            n = d[i] + (d[i + 1] << 8) + (d[i + 2] << 16) + ((d[i + 3] & 127) << 24);
            if (n >= 214e7) {
              crypto.randomBytes(4).copy(d, i);
            } else {
              rd.push(n % 1e7);
              i += 4;
            }
          }
          i = k / 4;
        } else {
          throw Error(cryptoUnavailable);
        }
        k = rd[--i];
        sd %= LOG_BASE;
        if (k && sd) {
          n = mathpow(10, LOG_BASE - sd);
          rd[i] = (k / n | 0) * n;
        }
        for (; rd[i] === 0; i--) rd.pop();
        if (i < 0) {
          e = 0;
          rd = [0];
        } else {
          e = -1;
          for (; rd[0] === 0; e -= LOG_BASE) rd.shift();
          for (k = 1, n = rd[0]; n >= 10; n /= 10) k++;
          if (k < LOG_BASE) e -= LOG_BASE - k;
        }
        r.e = e;
        r.d = rd;
        return r;
      }
      function round(x) {
        return finalise(x = new this(x), x.e + 1, this.rounding);
      }
      function sign(x) {
        x = new this(x);
        return x.d ? x.d[0] ? x.s : 0 * x.s : x.s || NaN;
      }
      function sin(x) {
        return new this(x).sin();
      }
      function sinh(x) {
        return new this(x).sinh();
      }
      function sqrt(x) {
        return new this(x).sqrt();
      }
      function sub(x, y) {
        return new this(x).sub(y);
      }
      function sum() {
        var i = 0, args2 = arguments, x = new this(args2[i]);
        external = false;
        for (; x.s && ++i < args2.length; ) x = x.plus(args2[i]);
        external = true;
        return finalise(x, this.precision, this.rounding);
      }
      function tan(x) {
        return new this(x).tan();
      }
      function tanh(x) {
        return new this(x).tanh();
      }
      function trunc(x) {
        return finalise(x = new this(x), x.e + 1, 1);
      }
      Decimal = clone(DEFAULTS);
      Decimal.prototype.constructor = Decimal;
      Decimal["default"] = Decimal.Decimal = Decimal;
      LN10 = new Decimal(LN10);
      PI = new Decimal(PI);
      if (typeof define == "function" && define.amd) {
        define(function() {
          return Decimal;
        });
      } else if (typeof module != "undefined" && module.exports) {
        if (typeof Symbol == "function" && typeof Symbol.iterator == "symbol") {
          P[Symbol["for"]("nodejs.util.inspect.custom")] = P.toString;
          P[Symbol.toStringTag] = "Decimal";
        }
        module.exports = Decimal;
      } else {
        if (!globalScope) {
          globalScope = typeof self != "undefined" && self && self.self == self ? self : window;
        }
        noConflict = globalScope.Decimal;
        Decimal.noConflict = function() {
          globalScope.Decimal = noConflict;
          return Decimal;
        };
        globalScope.Decimal = Decimal;
      }
    })(exports);
  }
});

// ../../packages/shared/dist/expression.js
var require_expression = __commonJS({
  "../../packages/shared/dist/expression.js"(exports) {
    "use strict";
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.evaluateExpression = evaluateExpression;
    var decimal_js_1 = __importDefault(require_decimal());
    var Lexer = class {
      input;
      pos = 0;
      constructor(input) {
        this.input = input;
      }
      nextToken() {
        if (this.pos >= this.input.length) {
          return { type: "EOF" };
        }
        const ch = this.input[this.pos];
        if (ch === "+") {
          this.pos++;
          return { type: "PLUS" };
        }
        if (ch === "-") {
          this.pos++;
          return { type: "MINUS" };
        }
        if (ch === "*") {
          this.pos++;
          return { type: "STAR" };
        }
        if (ch === "/") {
          this.pos++;
          return { type: "SLASH" };
        }
        if (ch === "(") {
          this.pos++;
          return { type: "LPAREN" };
        }
        if (ch === ")") {
          this.pos++;
          return { type: "RPAREN" };
        }
        if (ch === "{") {
          const start = this.pos + 1;
          const end = this.input.indexOf("}", start);
          if (end === -1) {
            throw new Error("Incomplete expression");
          }
          const varName = this.input.slice(start, end);
          this.pos = end + 1;
          return { type: "VAR", value: varName };
        }
        if (!ch) {
          return { type: "EOF" };
        }
        if (ch >= "0" && ch <= "9" || ch === ".") {
          let numStr = "";
          let hasDot = false;
          while (this.pos < this.input.length) {
            const c = this.input[this.pos];
            if (c !== void 0 && c >= "0" && c <= "9") {
              numStr += c;
              this.pos++;
            } else if (c === ".") {
              if (hasDot) {
                throw new Error("Unexpected character");
              }
              hasDot = true;
              numStr += c;
              this.pos++;
            } else {
              break;
            }
          }
          return { type: "NUMBER", value: numStr };
        }
        throw new Error("Unexpected character");
      }
    };
    var Parser = class {
      lexer;
      vars;
      currentToken;
      constructor(lexer, vars) {
        this.lexer = lexer;
        this.vars = vars;
        this.currentToken = this.lexer.nextToken();
      }
      eat(type) {
        if (this.currentToken.type === type) {
          this.currentToken = this.lexer.nextToken();
        } else if (type === "RPAREN") {
          throw new Error("Missing bracket");
        } else {
          throw new Error("Incomplete expression");
        }
      }
      isEOF() {
        return this.currentToken.type === "EOF";
      }
      parse() {
        if (this.isEOF()) {
          throw new Error("Empty");
        }
        const result = this.expr();
        if (!this.isEOF()) {
          if (this.currentToken.type === "RPAREN") {
            throw new Error("Unexpected character");
          }
          throw new Error("Incomplete expression");
        }
        return result;
      }
      expr() {
        let result = this.term();
        while (this.currentToken.type === "PLUS" || this.currentToken.type === "MINUS") {
          const op = this.currentToken.type;
          this.eat(op);
          const right = this.term();
          if (op === "PLUS") {
            result = result.plus(right);
          } else {
            result = result.minus(right);
          }
        }
        return result;
      }
      term() {
        let result = this.factor();
        while (this.currentToken.type === "STAR" || this.currentToken.type === "SLASH") {
          const op = this.currentToken.type;
          this.eat(op);
          const right = this.factor();
          if (op === "STAR") {
            result = result.times(right);
          } else {
            if (right.isZero()) {
              throw new Error("Divide by zero");
            }
            result = result.dividedBy(right);
          }
        }
        return result;
      }
      factor() {
        const token = this.currentToken;
        if (token.type === "PLUS") {
          this.eat("PLUS");
          return this.factor();
        }
        if (token.type === "MINUS") {
          this.eat("MINUS");
          return this.factor().negated();
        }
        if (token.type === "NUMBER") {
          this.eat("NUMBER");
          try {
            return new decimal_js_1.default(token.value ?? "0");
          } catch {
            throw new Error("Unexpected character");
          }
        }
        if (token.type === "VAR") {
          const varKey = token.value ?? "";
          this.eat("VAR");
          if (!this.vars || !(varKey in this.vars)) {
            throw new Error("Unknown column");
          }
          const rawVal = this.vars[varKey] ?? "0";
          const cleanVal = rawVal.trim() === "" ? "0" : rawVal;
          try {
            return new decimal_js_1.default(cleanVal);
          } catch {
            throw new Error("Unexpected character");
          }
        }
        if (token.type === "LPAREN") {
          this.eat("LPAREN");
          const result = this.expr();
          this.eat("RPAREN");
          return result;
        }
        if (token.type === "EOF") {
          throw new Error("Incomplete expression");
        }
        throw new Error("Unexpected character");
      }
    };
    function evaluateExpression(raw, opts) {
      if (!raw || raw.trim() === "") {
        return { ok: false, error: "Empty" };
      }
      let sanitized = raw.replace(/[\s,]/g, "");
      sanitized = sanitized.replace(/[xX×]/g, "*");
      sanitized = sanitized.replace(/÷/g, "/");
      if (sanitized === "") {
        return { ok: false, error: "Empty" };
      }
      try {
        const lexer = new Lexer(sanitized);
        const parser = new Parser(lexer, opts?.vars);
        const result = parser.parse();
        const decimals = opts?.decimals ?? 2;
        decimal_js_1.default.set({ rounding: decimal_js_1.default.ROUND_HALF_UP });
        let finalValStr;
        if (result.isInteger()) {
          finalValStr = result.toString();
        } else {
          finalValStr = result.toFixed(decimals);
          if (finalValStr.includes(".")) {
            finalValStr = finalValStr.replace(/\.?0+$/, "");
          }
        }
        const num = Number(finalValStr);
        const display = new Intl.NumberFormat("en-IN", {
          maximumFractionDigits: decimals
        }).format(num);
        return {
          ok: true,
          value: finalValStr,
          display
        };
      } catch (err) {
        const message = err instanceof Error ? err.message : "Incomplete expression";
        return { ok: false, error: message };
      }
    }
  }
});

// ../../packages/shared/dist/notebook.js
var require_notebook = __commonJS({
  "../../packages/shared/dist/notebook.js"(exports) {
    "use strict";
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.computeRowCells = computeRowCells;
    exports.computeColumnTotal = computeColumnTotal;
    exports.exportNotebookToCSV = exportNotebookToCSV;
    var decimal_js_1 = __importDefault(require_decimal());
    var expression_js_1 = require_expression();
    function computeRowCells(columns, row) {
      const vars = {};
      const computedCols = /* @__PURE__ */ new Map();
      for (const col of columns) {
        if (col.type !== "computed") {
          const cell = row.cells[col.key];
          vars[col.key] = cell?.value ?? cell?.raw ?? "0";
        } else if (col.formula) {
          computedCols.set(col.key, col);
        }
      }
      const updatedCells = { ...row.cells };
      const visiting = /* @__PURE__ */ new Set();
      const resolved = /* @__PURE__ */ new Set();
      function resolveComputedColumn(key) {
        if (resolved.has(key))
          return true;
        if (visiting.has(key)) {
          updatedCells[key] = {
            raw: computedCols.get(key)?.formula || "",
            value: "\u2014",
            error: "#CYCLE!"
          };
          return false;
        }
        const col = computedCols.get(key);
        if (!col || !col.formula)
          return true;
        visiting.add(key);
        const refRegex = /\{([^}]+)\}/g;
        let match;
        while ((match = refRegex.exec(col.formula)) !== null) {
          const depKey = match[1]?.trim() || "";
          if (depKey === key) {
            visiting.delete(key);
            updatedCells[key] = {
              raw: col.formula,
              value: "\u2014",
              error: "#CYCLE!"
            };
            return false;
          }
          if (computedCols.has(depKey) && !resolved.has(depKey)) {
            const okDep = resolveComputedColumn(depKey);
            if (!okDep) {
              visiting.delete(key);
              updatedCells[key] = {
                raw: col.formula,
                value: "\u2014",
                error: "#CYCLE!"
              };
              return false;
            }
          }
        }
        visiting.delete(key);
        const evalRes = (0, expression_js_1.evaluateExpression)(col.formula, {
          decimals: col.decimals ?? 2,
          vars
        });
        if (evalRes.ok) {
          updatedCells[col.key] = {
            raw: col.formula,
            value: evalRes.value
          };
          vars[col.key] = evalRes.value;
        } else {
          updatedCells[col.key] = {
            raw: col.formula,
            value: "\u2014",
            error: evalRes.error
          };
        }
        resolved.add(key);
        return true;
      }
      for (const col of columns) {
        if (col.type === "computed" && col.formula) {
          resolveComputedColumn(col.key);
        }
      }
      return {
        ...row,
        cells: updatedCells
      };
    }
    function computeColumnTotal(col, rows) {
      if (!col.total || rows.length === 0)
        return null;
      const values = [];
      for (const r of rows) {
        const cell = r.cells[col.key];
        const val = cell?.value ?? cell?.raw;
        if (val && val !== "\u2014") {
          try {
            const d = new decimal_js_1.default(val.replace(/,/g, ""));
            if (!d.isNaN()) {
              values.push(d);
            }
          } catch {
          }
        }
      }
      if (col.total === "count") {
        return values.length.toString();
      }
      if (values.length === 0)
        return "0";
      let result;
      switch (col.total) {
        case "sum":
          result = values.reduce((acc, curr) => acc.plus(curr), new decimal_js_1.default(0));
          break;
        case "avg": {
          const sum = values.reduce((acc, curr) => acc.plus(curr), new decimal_js_1.default(0));
          result = sum.dividedBy(values.length);
          break;
        }
        case "min":
          result = values.reduce((min, curr) => curr.lessThan(min) ? curr : min, values[0]);
          break;
        case "max":
          result = values.reduce((max, curr) => curr.greaterThan(max) ? curr : max, values[0]);
          break;
      }
      const decimals = col.decimals ?? 2;
      const num = Number(result.toFixed(decimals));
      return new Intl.NumberFormat("en-IN", {
        maximumFractionDigits: decimals
      }).format(num);
    }
    function exportNotebookToCSV(notebook) {
      const headers = notebook.columns.map((c) => `"${c.title.replace(/"/g, '""')}"`);
      const lines = [headers.join(",")];
      for (const row of notebook.rows) {
        const rowValues = notebook.columns.map((c) => {
          const cell = row.cells[c.key];
          const val = cell?.value ?? cell?.raw ?? "";
          return `"${val.replace(/"/g, '""')}"`;
        });
        lines.push(rowValues.join(","));
      }
      return lines.join("\n");
    }
  }
});

// ../../packages/shared/dist/seed.js
var require_seed = __commonJS({
  "../../packages/shared/dist/seed.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.INITIAL_NOTIFICATIONS = exports.INITIAL_TASKS = exports.SAMPLE_TASK_PHOTO_2 = exports.SAMPLE_TASK_PHOTO_1 = exports.INITIAL_ACTIVITIES = exports.INITIAL_NOTEBOOKS = exports.INITIAL_CHALLANS = exports.INITIAL_REPLY_THREADS = exports.INITIAL_RULES = exports.INITIAL_BALANCES = exports.INITIAL_STOCK = exports.INITIAL_GODOWNS = exports.INITIAL_LEDGER_SAMPLE = exports.INITIAL_BILLS = exports.INITIAL_PARTIES = exports.INITIAL_USERS = exports.INITIAL_AGENT = exports.INITIAL_COMPANIES = exports.INITIAL_TENANTS = exports.FIXED_TODAY = void 0;
    var money_js_1 = require_money();
    exports.FIXED_TODAY = "2026-10-17";
    exports.INITIAL_TENANTS = [
      {
        id: "tenant-1",
        name: "Manohar Traders Group",
        ownerName: "Manohar Lal",
        ownerPhone: "+91 98140 11223",
        status: "active",
        createdAt: "2026-04-01T00:00:00Z"
      }
    ];
    exports.INITIAL_COMPANIES = [
      {
        id: "c1",
        tenantId: "tenant-1",
        name: "Manohar Traders",
        tallyName: "Manohar Traders",
        financialYear: "2026-27",
        gstin: "03AABCM1234F1Z1",
        lastSyncedAt: "2026-10-17T15:18:00Z",
        agentStatus: "online"
      },
      {
        id: "c2",
        tenantId: "tenant-1",
        name: "Manohar International",
        tallyName: "Manohar International",
        financialYear: "2026-27",
        gstin: "03AABCM5678F1Z2",
        lastSyncedAt: "2026-10-17T15:15:00Z",
        agentStatus: "online"
      }
    ];
    exports.INITIAL_AGENT = {
      version: "1.4.2",
      status: "online",
      lastSeenAt: "2026-10-17T15:18:00Z"
    };
    exports.INITIAL_USERS = [
      {
        id: "u-dev",
        tenantId: "platform",
        name: "Dev Admin",
        phone: "+91 99999 00000",
        pin: "0000",
        role: "dev",
        companyIds: "all",
        active: true
      },
      {
        id: "u1",
        tenantId: "tenant-1",
        name: "Manohar Lal",
        phone: "+91 98140 11223",
        pin: "1234",
        role: "owner",
        companyIds: "all",
        active: true
      },
      {
        id: "u2",
        tenantId: "tenant-1",
        name: "Priya Sharma",
        phone: "+91 98765 22334",
        pin: "1234",
        role: "admin",
        companyIds: "all",
        active: true
      },
      {
        id: "u3",
        tenantId: "tenant-1",
        name: "Ramesh Gupta",
        phone: "+91 98111 33445",
        pin: "1234",
        role: "accounts",
        companyIds: ["c1"],
        active: true
      },
      {
        id: "u4",
        tenantId: "tenant-1",
        name: "Amit Verma",
        phone: "+91 98222 44556",
        pin: "1234",
        role: "sales",
        companyIds: ["c1", "c2"],
        active: true
      },
      {
        id: "u5",
        tenantId: "tenant-1",
        name: "Suresh Kumar",
        phone: "+91 98333 55667",
        pin: "1234",
        role: "stock_keeper",
        companyIds: ["c1"],
        active: true
      },
      {
        id: "u6",
        tenantId: "tenant-1",
        name: "Kavita Singh",
        phone: "+91 98444 66778",
        pin: "1234",
        role: "viewer",
        companyIds: "all",
        active: true
      }
    ];
    exports.INITIAL_PARTIES = [
      {
        id: "p-sample",
        tenantId: "tenant-1",
        companyId: "c1",
        name: "Sample Garments Pvt Ltd",
        city: "Kanpur",
        phones: ["+91 98390 12345", "+91 94150 54321"],
        gstin: "09AABCS1234F1Z3",
        creditDays: 30,
        remindersPaused: false,
        notes: "Key sewing parts customer; prefers afternoon calls."
      },
      {
        id: "p-bharat",
        tenantId: "tenant-1",
        companyId: "c1",
        name: "Bharat Textiles",
        city: "Ludhiana",
        phones: ["+91 98141 23456"],
        gstin: "03AABCB2345F1Z4",
        creditDays: 30,
        remindersPaused: false,
        notes: "Follow up with purchasing head Mr. Sethi."
      },
      {
        id: "p-royal",
        tenantId: "tenant-1",
        companyId: "c1",
        name: "Royal Fashion Hub",
        city: "Delhi",
        phones: ["+91 98101 34567"],
        gstin: "07AABCR3456F1Z5",
        creditDays: 30,
        remindersPaused: false,
        notes: "Promises payment by Monday."
      },
      {
        id: "p-apex",
        tenantId: "tenant-1",
        companyId: "c1",
        name: "Apex Stitching Co",
        city: "Jaipur",
        phones: ["+91 98290 45678"],
        gstin: "08AABCA4567F1Z6",
        creditDays: 30,
        remindersPaused: false,
        notes: ""
      },
      {
        id: "p-modern",
        tenantId: "tenant-1",
        companyId: "c1",
        name: "Modern Tailors",
        city: "Tirupur",
        phones: ["+91 98422 56789"],
        gstin: "33AABCM5678F1Z7",
        creditDays: 30,
        remindersPaused: false,
        notes: "Regular client."
      },
      {
        id: "p-golden",
        tenantId: "tenant-1",
        companyId: "c1",
        name: "Golden Thread Works",
        city: "Lucknow",
        phones: ["+91 98399 67890"],
        gstin: "09AABCG6789F1Z8",
        creditDays: 30,
        remindersPaused: false,
        notes: ""
      },
      {
        id: "p-inter-1",
        tenantId: "tenant-1",
        companyId: "c2",
        name: "Global Exports Hub",
        city: "Mumbai",
        phones: ["+91 98200 78901"],
        gstin: "27AABCG7890F1Z9",
        creditDays: 45,
        remindersPaused: false,
        notes: "Interstate container orders."
      }
    ];
    exports.INITIAL_BILLS = [
      // Sample Garments (Kanpur): Total ₹1,32,300 (45 days late)
      {
        id: "b-sample-1",
        companyId: "c1",
        partyId: "p-sample",
        billNo: "GST/004/26-27",
        date: "2026-08-03",
        dueDate: "2026-09-02",
        // 45 days overdue relative to 2026-10-17
        amount: (0, money_js_1.rupeesToPaise)(105840),
        pending: (0, money_js_1.rupeesToPaise)(105840),
        source: "estimated"
      },
      {
        id: "b-sample-2",
        companyId: "c1",
        partyId: "p-sample",
        billNo: "GST/005/26-27",
        date: "2026-08-10",
        dueDate: "2026-09-09",
        amount: (0, money_js_1.rupeesToPaise)(26460),
        pending: (0, money_js_1.rupeesToPaise)(26460),
        source: "estimated"
      },
      // Bharat Textiles: ₹98,400 (38 days late)
      {
        id: "b-bharat-1",
        companyId: "c1",
        partyId: "p-bharat",
        billNo: "GST/014/26-27",
        date: "2026-08-10",
        dueDate: "2026-09-09",
        // 38 days overdue
        amount: (0, money_js_1.rupeesToPaise)(98400),
        pending: (0, money_js_1.rupeesToPaise)(98400),
        source: "tally_bill"
      },
      // Royal Fashion Hub: ₹84,200 (32 days late)
      {
        id: "b-royal-1",
        companyId: "c1",
        partyId: "p-royal",
        billNo: "GST/021/26-27",
        date: "2026-08-16",
        dueDate: "2026-09-15",
        // 32 days overdue
        amount: (0, money_js_1.rupeesToPaise)(84200),
        pending: (0, money_js_1.rupeesToPaise)(84200),
        source: "tally_bill"
      },
      // Apex Stitching Co: ₹65,000 (28 days late)
      {
        id: "b-apex-1",
        companyId: "c1",
        partyId: "p-apex",
        billNo: "GST/033/26-27",
        date: "2026-08-20",
        dueDate: "2026-09-19",
        // 28 days overdue
        amount: (0, money_js_1.rupeesToPaise)(65e3),
        pending: (0, money_js_1.rupeesToPaise)(65e3),
        source: "tally_bill"
      },
      // Modern Tailors: ₹42,500 (24 days late)
      {
        id: "b-modern-1",
        companyId: "c1",
        partyId: "p-modern",
        billNo: "GST/045/26-27",
        date: "2026-08-24",
        dueDate: "2026-09-23",
        // 24 days overdue
        amount: (0, money_js_1.rupeesToPaise)(42500),
        pending: (0, money_js_1.rupeesToPaise)(42500),
        source: "tally_bill"
      },
      // Remaining amount to reach ₹18,42,300 total receivables with ₹6,10,200 overdue
      // Total overdue = 132300 + 98400 + 84200 + 65000 + 42500 = 422400. We add 187800 overdue for Golden Thread Works:
      {
        id: "b-golden-1",
        companyId: "c1",
        partyId: "p-golden",
        billNo: "GST/055/26-27",
        date: "2026-08-28",
        dueDate: "2026-09-27",
        // 20 days late (1-30d)
        amount: (0, money_js_1.rupeesToPaise)(187800),
        pending: (0, money_js_1.rupeesToPaise)(187800),
        source: "tally_bill"
      },
      // Now overdue = 4,22,400 + 1,87,800 = ₹6,10,200 (exact match)
      // Not due bills (Total receivables = 18,42,300, so not due = 18,42,300 - 6,10,200 = ₹12,32,100 = 67%):
      {
        id: "b-not-due-1",
        companyId: "c1",
        partyId: "p-sample",
        billNo: "GST/060/26-27",
        date: "2026-10-05",
        dueDate: "2026-11-04",
        // Not due
        amount: (0, money_js_1.rupeesToPaise)(632100),
        pending: (0, money_js_1.rupeesToPaise)(632100),
        source: "tally_bill"
      },
      {
        id: "b-not-due-2",
        companyId: "c1",
        partyId: "p-bharat",
        billNo: "GST/062/26-27",
        date: "2026-10-10",
        dueDate: "2026-11-09",
        // Not due
        amount: (0, money_js_1.rupeesToPaise)(6e5),
        pending: (0, money_js_1.rupeesToPaise)(6e5),
        source: "tally_bill"
      }
    ];
    exports.INITIAL_LEDGER_SAMPLE = [
      {
        date: "2026-05-10",
        particulars: "Sales - Sewing Machine Servo Motors (Qty: 20)",
        voucherType: "Sales",
        voucherNo: "GST/001/26-27",
        debit: (0, money_js_1.rupeesToPaise)(90720),
        credit: 0
      },
      {
        date: "2026-05-20",
        particulars: "Sales - Heavy Duty Needle Plates & Feed Dogs",
        voucherType: "Sales",
        voucherNo: "GST/002/26-27",
        debit: (0, money_js_1.rupeesToPaise)(90720),
        credit: 0
      },
      {
        date: "2026-06-01",
        particulars: "Sales - Rotary Hooks & Bobbin Cases Set",
        voucherType: "Sales",
        voucherNo: "GST/003/26-27",
        debit: (0, money_js_1.rupeesToPaise)(105840),
        credit: 0
      },
      {
        date: "2026-06-10",
        particulars: "Bank Receipt - HDFC Cheque #349182",
        voucherType: "Receipt",
        voucherNo: "RC/018/26-27",
        debit: 0,
        credit: (0, money_js_1.rupeesToPaise)(287280)
      },
      {
        date: "2026-08-03",
        particulars: "Sales - Direct Drive Motors 550W",
        voucherType: "Sales",
        voucherNo: "GST/004/26-27",
        debit: (0, money_js_1.rupeesToPaise)(105840),
        credit: 0
      },
      {
        date: "2026-08-10",
        particulars: "Sales - Lubrication Pumps & Accessories",
        voucherType: "Sales",
        voucherNo: "GST/005/26-27",
        debit: (0, money_js_1.rupeesToPaise)(26460),
        credit: 0
      }
    ];
    exports.INITIAL_GODOWNS = [
      { id: "g1", companyId: "c1", name: "Main Godown (Ludhiana)" },
      { id: "g2", companyId: "c1", name: "Shop Godown" },
      { id: "g3", companyId: "c2", name: "Export Yard" }
    ];
    exports.INITIAL_STOCK = [
      {
        id: "item-1",
        companyId: "c1",
        name: "Servo Motor 550W (Direct Drive)",
        partNo: "SM-550D",
        unit: "pcs",
        group: "Motors",
        rate: (0, money_js_1.rupeesToPaise)(4200),
        reorderLevel: 20
      },
      {
        id: "item-2",
        companyId: "c1",
        name: "Rotary Hook Assembly (Japanese Type)",
        partNo: "RH-204J",
        unit: "set",
        group: "Hooks & Shuttles",
        rate: (0, money_js_1.rupeesToPaise)(850),
        reorderLevel: 15
      },
      {
        id: "item-3",
        companyId: "c1",
        name: "Heavy Duty Needle Plate B-24",
        partNo: "NP-B24",
        unit: "pcs",
        group: "Plates & Dogs",
        rate: (0, money_js_1.rupeesToPaise)(180),
        reorderLevel: 50
      },
      {
        id: "item-4",
        companyId: "c1",
        name: "Standard Bobbin Case (No-Backlash)",
        partNo: "BC-312",
        unit: "pcs",
        group: "Bobbin Cases",
        rate: (0, money_js_1.rupeesToPaise)(95),
        reorderLevel: 100
      },
      {
        id: "item-tai",
        companyId: "c1",
        name: "TAI MACHINE",
        partNo: "TAI-9000-HD",
        unit: "set",
        group: "Sewing Machines",
        rate: (0, money_js_1.rupeesToPaise)(38500),
        reorderLevel: 5
      },
      {
        id: "item-sv",
        companyId: "c1",
        name: "SV MACHINE",
        partNo: "SV-8700-DX",
        unit: "set",
        group: "Sewing Machines",
        rate: (0, money_js_1.rupeesToPaise)(42e3),
        reorderLevel: 4
      },
      {
        id: "item-130k",
        companyId: "c1",
        name: "130K MACHINE",
        partNo: "130K-INTERLOCK",
        unit: "set",
        group: "Sewing Machines",
        rate: (0, money_js_1.rupeesToPaise)(55e3),
        reorderLevel: 3
      },
      {
        id: "item-tai-set",
        companyId: "c1",
        name: "TAI SET MACHINE",
        partNo: "TAI-SET-FULL",
        unit: "set",
        group: "Sewing Machines",
        rate: (0, money_js_1.rupeesToPaise)(68e3),
        reorderLevel: 2
      }
    ];
    exports.INITIAL_BALANCES = [
      { itemId: "item-1", godownId: "g1", qty: 42 },
      { itemId: "item-1", godownId: "g2", qty: 8 },
      { itemId: "item-2", godownId: "g1", qty: 12 },
      // Low! Reorder is 15
      { itemId: "item-3", godownId: "g1", qty: 120 },
      { itemId: "item-4", godownId: "g1", qty: 80 },
      // Low! Reorder is 100
      { itemId: "item-tai", godownId: "g1", qty: 14 },
      { itemId: "item-sv", godownId: "g1", qty: 9 },
      { itemId: "item-130k", godownId: "g1", qty: 6 },
      { itemId: "item-tai-set", godownId: "g1", qty: 5 }
    ];
    exports.INITIAL_RULES = {
      tenantId: "tenant-1",
      enabled: true,
      whatsappEnabled: false,
      defaultDueDays: 30,
      steps: [
        { offsetDays: -3, template: "due_soon", enabled: true },
        { offsetDays: 0, template: "due_today", enabled: true },
        { offsetDays: 3, template: "overdue", enabled: true },
        { offsetDays: 7, template: "overdue", enabled: true },
        { offsetDays: 15, template: "overdue", enabled: true }
      ],
      quietHours: {
        from: "20:00",
        to: "09:00",
        days: [0]
        // Sunday
      },
      minAmount: (0, money_js_1.rupeesToPaise)(1e3),
      stopWhenPaid: true
    };
    exports.INITIAL_REPLY_THREADS = [
      {
        id: "th-1",
        companyId: "c1",
        partyId: "p-sample",
        unread: 1,
        lastCustomerMessageAt: "2026-10-17T14:45:00Z",
        messages: [
          {
            from: "us",
            text: "Hello Sample Garments, invoice GST/004/26-27 for \u20B91,05,840 is overdue. Please arrange payment.",
            at: "2026-10-17T11:00:00Z"
          },
          {
            from: "customer",
            text: "Paid \u20B950,000 via NEFT today ref #UTR991823. Please check and send updated balance.",
            at: "2026-10-17T14:45:00Z"
          }
        ]
      },
      {
        id: "th-2",
        companyId: "c1",
        partyId: "p-royal",
        unread: 1,
        lastCustomerMessageAt: "2026-10-17T13:20:00Z",
        messages: [
          {
            from: "customer",
            text: "Will clear Monday 100%. Please don\u2019t stop material dispatch.",
            at: "2026-10-17T13:20:00Z"
          }
        ]
      }
    ];
    exports.INITIAL_CHALLANS = [
      {
        id: "ch-1",
        companyId: "c1",
        type: "delivery",
        number: "DC/042/26-27",
        date: "2026-10-15",
        partyId: "p-sample",
        godownId: "g1",
        lines: [
          {
            itemId: "item-1",
            description: "Servo Motor 550W (Direct Drive)",
            qty: 10,
            unit: "pcs",
            rate: (0, money_js_1.rupeesToPaise)(4200),
            amount: (0, money_js_1.rupeesToPaise)(42e3)
          },
          {
            itemId: "item-2",
            description: "Rotary Hook Assembly (Japanese Type)",
            qty: 20,
            unit: "set",
            rate: (0, money_js_1.rupeesToPaise)(850),
            amount: (0, money_js_1.rupeesToPaise)(17e3)
          }
        ],
        vehicleNo: "PB-10-CZ-8821",
        lrNo: "LR-99214",
        transporter: "Golden Goods Transport",
        narration: "Dispatched via Golden Goods Transport for branch expansion",
        status: "synced",
        createdBy: "u-owner"
      },
      {
        id: "ch-2",
        companyId: "c1",
        type: "sales",
        number: "SC/014/26-27",
        date: "2026-10-16",
        partyId: "p-bharat",
        godownId: "g1",
        lines: [
          {
            itemId: "item-3",
            description: "Heavy Duty Needle Plate B-24",
            qty: 50,
            unit: "pcs",
            rate: (0, money_js_1.rupeesToPaise)(180),
            amount: (0, money_js_1.rupeesToPaise)(9e3)
          },
          {
            itemId: "item-4",
            description: "Standard Bobbin Case (No-Backlash)",
            qty: 100,
            unit: "pcs",
            rate: (0, money_js_1.rupeesToPaise)(95),
            amount: (0, money_js_1.rupeesToPaise)(9500)
          }
        ],
        vehicleNo: "PB-10-ET-1920",
        lrNo: "LR-44910",
        transporter: "Surat Express Carrier",
        narration: "Urgent sample batch for production line",
        status: "queued",
        createdBy: "u-sales"
      },
      {
        id: "ch-3",
        companyId: "c1",
        type: "purchase",
        number: "PC/008/26-27",
        date: "2026-10-14",
        partyId: "p-apex",
        godownId: "g1",
        lines: [
          {
            itemId: "item-1",
            description: "Servo Motor 550W (Direct Drive)",
            qty: 25,
            unit: "pcs",
            rate: (0, money_js_1.rupeesToPaise)(4e3),
            amount: (0, money_js_1.rupeesToPaise)(1e5)
          }
        ],
        vehicleNo: "DL-01-A-4432",
        lrNo: "LR-11029",
        transporter: "Apex Logistics",
        narration: "Inward material from OEM manufacturing partner",
        status: "synced",
        createdBy: "u-owner"
      },
      {
        id: "ch-4",
        companyId: "c1",
        type: "delivery",
        number: "DC/043/26-27",
        date: "2026-10-17",
        partyId: "p-royal",
        godownId: "g2",
        lines: [
          {
            itemId: "item-2",
            description: "Rotary Hook Assembly (Japanese Type)",
            qty: 15,
            unit: "set",
            rate: (0, money_js_1.rupeesToPaise)(850),
            amount: (0, money_js_1.rupeesToPaise)(12750)
          }
        ],
        vehicleNo: "HR-26-BK-9182",
        lrNo: "LR-33102",
        transporter: "City Parcel Express",
        narration: "Delivered against advance token",
        status: "failed",
        failureReason: "Tally connection timed out while allocating batch stock",
        createdBy: "u-sales"
      },
      {
        id: "ch-5",
        companyId: "c1",
        type: "sales",
        number: "SC/015/26-27",
        date: "2026-10-17",
        partyId: "p-sample",
        godownId: "g1",
        lines: [
          {
            itemId: "item-3",
            description: "Heavy Duty Needle Plate B-24",
            qty: 30,
            unit: "pcs",
            rate: (0, money_js_1.rupeesToPaise)(180),
            amount: (0, money_js_1.rupeesToPaise)(5400)
          }
        ],
        narration: "Draft order awaiting lorry receipt from driver",
        status: "draft",
        createdBy: "u-sales"
      },
      {
        id: "ch-6",
        companyId: "c1",
        type: "delivery",
        number: "DC/045/26-27",
        date: "2026-10-17",
        partyId: "p-sample",
        godownId: "g1",
        lines: [
          {
            itemId: "item-tai",
            description: "TAI MACHINE",
            qty: 2,
            unit: "set",
            rate: (0, money_js_1.rupeesToPaise)(38500),
            amount: (0, money_js_1.rupeesToPaise)(77e3)
          },
          {
            itemId: "item-sv",
            description: "SV MACHINE",
            qty: 1,
            unit: "set",
            rate: (0, money_js_1.rupeesToPaise)(42e3),
            amount: (0, money_js_1.rupeesToPaise)(42e3)
          }
        ],
        vehicleNo: "PB-10-DX-5542",
        lrNo: "LR-99881",
        transporter: "Ludhiana Cargo Express",
        narration: "Dispatched for garment factory installation. Tested with 14-gauge needles.",
        status: "synced",
        createdBy: "u1"
      },
      {
        id: "ch-7",
        companyId: "c1",
        type: "delivery",
        number: "DC/046/26-27",
        date: "2026-10-17",
        partyId: "p-royal",
        godownId: "g1",
        lines: [
          {
            itemId: "item-130k",
            description: "130K MACHINE",
            qty: 1,
            unit: "set",
            rate: (0, money_js_1.rupeesToPaise)(55e3),
            amount: (0, money_js_1.rupeesToPaise)(55e3)
          },
          {
            itemId: "item-tai-set",
            description: "TAI SET MACHINE",
            qty: 1,
            unit: "set",
            rate: (0, money_js_1.rupeesToPaise)(68e3),
            amount: (0, money_js_1.rupeesToPaise)(68e3)
          }
        ],
        vehicleNo: "PB-10-FZ-7711",
        lrNo: "LR-99882",
        transporter: "Golden Goods Transport",
        narration: "Urgent machinery dispatch with complete stand & table sets.",
        status: "queued",
        createdBy: "u4"
      }
    ];
    exports.INITIAL_NOTEBOOKS = [
      {
        id: "nb-1",
        companyId: "c1",
        userId: "u1",
        title: "Diwali Advance Booking & Material Estimates",
        updatedAt: "2026-10-17T15:30:00Z",
        updatedBy: "u1",
        columns: [
          { id: "c-party", key: "party", title: "Customer", type: "party" },
          { id: "c-item", key: "item", title: "Item Description", type: "item" },
          { id: "c-qty", key: "qty", title: "Qty", type: "number", decimals: 0, total: "sum" },
          { id: "c-rate", key: "rate", title: "Rate (\u20B9)", type: "number", decimals: 0 },
          { id: "c-amount", key: "amount", title: "Amount (\u20B9)", type: "computed", formula: "{qty} * {rate}", decimals: 0, total: "sum" },
          { id: "c-freight", key: "freight", title: "Freight (\u20B9)", type: "number", decimals: 0, total: "sum" },
          { id: "c-net", key: "net", title: "Net Total (\u20B9)", type: "computed", formula: "{amount} + {freight}", decimals: 0, total: "sum" }
        ],
        rows: [
          {
            id: "r-1",
            linkedPartyId: "p-sample",
            linkedItemId: "item-1",
            cells: {
              party: { raw: "Sample Garments Pvt Ltd", value: "Sample Garments Pvt Ltd" },
              item: { raw: "Servo Motor 550W (Direct Drive)", value: "Servo Motor 550W (Direct Drive)" },
              qty: { raw: "10*2", value: "20" },
              rate: { raw: "4200", value: "4200" },
              amount: { raw: "{qty} * {rate}", value: "84000" },
              freight: { raw: "1200", value: "1200" },
              net: { raw: "{amount} + {freight}", value: "85200" }
            }
          },
          {
            id: "r-2",
            linkedPartyId: "p-bharat",
            linkedItemId: "item-2",
            cells: {
              party: { raw: "Bharat Textiles", value: "Bharat Textiles" },
              item: { raw: "Rotary Hook Assembly", value: "Rotary Hook Assembly" },
              qty: { raw: "50+25", value: "75" },
              rate: { raw: "850", value: "850" },
              amount: { raw: "{qty} * {rate}", value: "63750" },
              freight: { raw: "850", value: "850" },
              net: { raw: "{amount} + {freight}", value: "64600" }
            }
          },
          {
            id: "r-3",
            linkedPartyId: "p-royal",
            linkedItemId: "item-3",
            cells: {
              party: { raw: "Royal Fashion Hub", value: "Royal Fashion Hub" },
              item: { raw: "Heavy Duty Needle Plate B-24", value: "Heavy Duty Needle Plate B-24" },
              qty: { raw: "120", value: "120" },
              rate: { raw: "180", value: "180" },
              amount: { raw: "{qty} * {rate}", value: "21600" },
              freight: { raw: "400", value: "400" },
              net: { raw: "{amount} + {freight}", value: "22000" }
            }
          },
          {
            id: "r-4",
            linkedPartyId: "p-apex",
            linkedItemId: "item-4",
            cells: {
              party: { raw: "Apex Stitching Co", value: "Apex Stitching Co" },
              item: { raw: "Standard Bobbin Case", value: "Standard Bobbin Case" },
              qty: { raw: "200", value: "200" },
              rate: { raw: "95", value: "95" },
              amount: { raw: "{qty} * {rate}", value: "19000" },
              freight: { raw: "350", value: "350" },
              net: { raw: "{amount} + {freight}", value: "19350" }
            }
          }
        ]
      },
      {
        id: "nb-2",
        companyId: "c1",
        title: "Daily Logistics & Box Weight Calculations",
        updatedAt: "2026-10-16T11:00:00Z",
        updatedBy: "u-owner",
        columns: [
          { id: "c-date", key: "date", title: "Dispatch Date", type: "date" },
          { id: "c-boxes", key: "boxes", title: "Cartons", type: "number", decimals: 0, total: "sum" },
          { id: "c-weightPerBox", key: "weightPerBox", title: "Weight / Box (Kg)", type: "number", decimals: 1 },
          { id: "c-totalWeight", key: "totalWeight", title: "Total Weight (Kg)", type: "computed", formula: "{boxes} * {weightPerBox}", decimals: 1, total: "sum" },
          { id: "c-freightPerKg", key: "freightPerKg", title: "Rate / Kg (\u20B9)", type: "number", decimals: 0 },
          { id: "c-totalFreight", key: "totalFreight", title: "Total Freight (\u20B9)", type: "computed", formula: "{totalWeight} * {freightPerKg}", decimals: 0, total: "sum" }
        ],
        rows: [
          {
            id: "r-log-1",
            cells: {
              date: { raw: "2026-10-15", value: "2026-10-15" },
              boxes: { raw: "12", value: "12" },
              weightPerBox: { raw: "15.5", value: "15.5" },
              totalWeight: { raw: "{boxes} * {weightPerBox}", value: "186" },
              freightPerKg: { raw: "18", value: "18" },
              totalFreight: { raw: "{totalWeight} * {freightPerKg}", value: "3348" }
            }
          },
          {
            id: "r-log-2",
            cells: {
              date: { raw: "2026-10-16", value: "2026-10-16" },
              boxes: { raw: "8*2", value: "16" },
              weightPerBox: { raw: "12", value: "12" },
              totalWeight: { raw: "{boxes} * {weightPerBox}", value: "192" },
              freightPerKg: { raw: "18", value: "18" },
              totalFreight: { raw: "{totalWeight} * {freightPerKg}", value: "3456" }
            }
          }
        ]
      }
    ];
    exports.INITIAL_ACTIVITIES = [
      {
        id: "act-1",
        tenantId: "tenant-1",
        companyId: "c1",
        actorId: "u1",
        action: "challan_created",
        target: "Delivery Challan DC/042/26-27 (\u20B942,000) for Sample Garments Pvt Ltd",
        at: "2026-10-17T15:24:00Z",
        device: "iPhone"
      },
      {
        id: "act-2",
        tenantId: "tenant-1",
        companyId: "c1",
        actorId: "u-agent",
        action: "tally_synced",
        target: "Office PC synced 34 ledgers & 18 vouchers (AlterID #1480)",
        at: "2026-10-17T15:18:00Z",
        device: "Agent"
      },
      {
        id: "act-3",
        tenantId: "tenant-1",
        companyId: "c1",
        actorId: "u3",
        action: "reminder_sent",
        target: "WhatsApp payment reminder sent to Sample Garments Pvt Ltd (\u20B91,05,840)",
        at: "2026-10-17T14:40:00Z",
        device: "Desktop"
      },
      {
        id: "act-4",
        tenantId: "tenant-1",
        companyId: "c1",
        actorId: "u-system",
        action: "reminder_reply",
        target: 'WhatsApp reply received from Royal Fashion Hub: "Will clear Monday 100%"',
        at: "2026-10-17T13:20:00Z",
        device: "Agent"
      },
      {
        id: "act-5",
        tenantId: "tenant-1",
        companyId: "c1",
        actorId: "u5",
        action: "stock_adjusted",
        target: "Stock adjustment: -2 pcs Servo Motor 550W (Physical stock damage)",
        at: "2026-10-17T13:10:00Z",
        device: "Android"
      },
      {
        id: "act-6",
        tenantId: "tenant-1",
        companyId: "c2",
        actorId: "u4",
        action: "challan_created",
        target: "Sales Challan SC/014/26-27 (\u20B95,400) for Vardhman Spinning Mills",
        at: "2026-10-17T12:05:00Z",
        device: "Android"
      },
      {
        id: "act-7",
        tenantId: "tenant-1",
        companyId: "c1",
        actorId: "u2",
        action: "party_updated",
        target: "Credit terms updated to 45 days for Royal Fashion Hub",
        at: "2026-10-17T11:35:00Z",
        device: "Desktop"
      },
      {
        id: "act-8",
        tenantId: "tenant-1",
        companyId: "c1",
        actorId: "u-agent",
        action: "challan_synced",
        target: "Delivery Challan DC/041/26-27 confirmed in TallyPrime",
        at: "2026-10-17T10:15:00Z",
        device: "Agent"
      },
      {
        id: "act-9",
        tenantId: "tenant-1",
        companyId: "c1",
        actorId: "u1",
        action: "user_login",
        target: "Owner signed in from iPhone 15 Pro (Ludhiana, Punjab)",
        at: "2026-10-17T09:00:00Z",
        device: "iPhone"
      },
      {
        id: "act-10",
        tenantId: "tenant-1",
        companyId: "c1",
        actorId: "u1",
        action: "notebook_saved",
        target: 'Updated calculation sheet "Diwali Advance Booking & Material Estimates"',
        at: "2026-10-16T18:30:00Z",
        device: "Desktop"
      }
    ];
    exports.SAMPLE_TASK_PHOTO_1 = "data:image/svg+xml;utf8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"><rect width="100%" height="100%" fill="#f8fafc"/><rect x="20" y="20" width="360" height="260" rx="16" fill="#e2e8f0" stroke="#cbd5e1" stroke-width="2"/><circle cx="120" cy="110" r="36" fill="#3b82f6" opacity="0.85"/><path d="M50 240 L160 140 L250 210 L310 165 L360 240 Z" fill="#0284c7"/><rect x="40" y="230" width="320" height="38" rx="8" fill="#0f172a" opacity="0.85"/><text x="200" y="254" font-family="system-ui, sans-serif" font-size="13" font-weight="600" fill="#ffffff" text-anchor="middle">TAI MACHINE #TM-9002 Inspection Mark</text></svg>');
    exports.SAMPLE_TASK_PHOTO_2 = "data:image/svg+xml;utf8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"><rect width="100%" height="100%" fill="#f8fafc"/><rect x="20" y="20" width="360" height="260" rx="16" fill="#fef3c7" stroke="#fde68a" stroke-width="2"/><rect x="50" y="50" width="300" height="180" rx="12" fill="#ffffff" stroke="#f59e0b" stroke-dasharray="4 4" stroke-width="2"/><text x="200" y="120" font-family="system-ui, sans-serif" font-size="16" font-weight="bold" fill="#b45309" text-anchor="middle">LORRY RECEIPT / BILTY</text><text x="200" y="150" font-family="monospace" font-size="14" fill="#78350f" text-anchor="middle">LR-99881 \xB7 SIGNED &amp; STAMPED</text><rect x="40" y="235" width="320" height="35" rx="8" fill="#b45309"/><text x="200" y="258" font-family="system-ui, sans-serif" font-size="12" font-weight="600" fill="#ffffff" text-anchor="middle">Verified Delivery Proof \xB7 Ludhiana Cargo</text></svg>');
    exports.INITIAL_TASKS = [
      {
        id: "task-1",
        companyId: "c1",
        title: "Check needle plate & motor wiring on TAI MACHINE & SV MACHINE",
        description: "Ensure 14-gauge needle plate is installed and oil seal is verified before driver leaves for Ludhiana Cargo.",
        assignedToUserId: "u5",
        // Suresh Kumar (stock_keeper)
        assignedByUserId: "u1",
        // Manohar Lal (owner)
        challanId: "ch-6",
        // DC/045/26-27
        photoUrl: exports.SAMPLE_TASK_PHOTO_1,
        status: "pending",
        priority: "high",
        createdAt: "2026-10-17T09:30:00Z"
      },
      {
        id: "task-2",
        companyId: "c1",
        title: "Collect stamped bilty receipt for 130K MACHINE delivery",
        description: "Customer representative will sign upon truck arrival at Focal Point godown.",
        assignedToUserId: "u4",
        // Amit Verma (sales)
        assignedByUserId: "u2",
        // Priya Sharma (admin)
        challanId: "ch-7",
        // DC/046/26-27
        photoUrl: exports.SAMPLE_TASK_PHOTO_2,
        status: "in_progress",
        priority: "normal",
        createdAt: "2026-10-17T11:15:00Z"
      }
    ];
    exports.INITIAL_NOTIFICATIONS = [
      {
        id: "notif-1",
        userId: "u5",
        // Suresh Kumar
        companyId: "c1",
        title: "New Task Assigned",
        body: 'Manohar Lal assigned you: "Check needle plate & motor wiring on TAI MACHINE & SV MACHINE"',
        taskId: "task-1",
        challanId: "ch-6",
        photoUrl: exports.SAMPLE_TASK_PHOTO_1,
        read: false,
        createdAt: "2026-10-17T09:30:00Z"
      },
      {
        id: "notif-2",
        userId: "u4",
        // Amit Verma
        companyId: "c1",
        title: "Delivery Task Assigned",
        body: 'Priya Sharma assigned you: "Collect stamped bilty receipt for 130K MACHINE delivery"',
        taskId: "task-2",
        challanId: "ch-7",
        photoUrl: exports.SAMPLE_TASK_PHOTO_2,
        read: false,
        createdAt: "2026-10-17T11:15:00Z"
      },
      {
        id: "notif-3",
        userId: "u1",
        // Manohar Lal (current active user)
        companyId: "c1",
        title: "Challan Task Notification",
        body: "Delivery task assigned on DC/045/26-27 (TAI MACHINE & SV MACHINE) with inspection photo.",
        taskId: "task-1",
        challanId: "ch-6",
        photoUrl: exports.SAMPLE_TASK_PHOTO_1,
        read: false,
        createdAt: "2026-10-17T09:32:00Z"
      }
    ];
  }
});

// ../../packages/shared/dist/index.js
var require_dist = __commonJS({
  "../../packages/shared/dist/index.js"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    } : function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    __exportStar(require_types2(), exports);
    __exportStar(require_money(), exports);
    __exportStar(require_aging(), exports);
    __exportStar(require_fifo(), exports);
    __exportStar(require_permissions(), exports);
    __exportStar(require_expression(), exports);
    __exportStar(require_notebook(), exports);
    __exportStar(require_seed(), exports);
  }
});

// src/index.ts
import path4 from "node:path";

// src/tally/templates.ts
function buildCompanyInfoQuery(companyName) {
  const companyTag = companyName ? `
        <SVCURRENTCOMPANY>${escapeXml(companyName)}</SVCURRENTCOMPANY>` : "";
  return `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>Export</TALLYREQUEST>
    <TYPE>Data</TYPE>
    <ID>CompanyInfo</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>${companyTag}
      </STATICVARIABLES>
      <TDL>
        <TDLMESSAGE>
          <REPORT NAME="CompanyInfo">
            <FORMS>CompanyInfoForm</FORMS>
          </REPORT>
          <FORM NAME="CompanyInfoForm">
            <PARTS>CompanyInfoPart</PARTS>
          </FORM>
          <PART NAME="CompanyInfoPart">
            <LINES>CompanyInfoLine</LINES>
          </PART>
          <LINE NAME="CompanyInfoLine">
            <FIELDS>CompNameField, CompYearField, CompBooksField</FIELDS>
          </LINE>
          <FIELD NAME="CompNameField">
            <SET>if $$IsEmpty:##SVCURRENTCOMPANY then $$CurrentSimpleCompany else ##SVCURRENTCOMPANY</SET>
          </FIELD>
          <FIELD NAME="CompYearField">
            <SET>$$String:##SVFROMDATE</SET>
          </FIELD>
          <FIELD NAME="CompBooksField">
            <SET>$$String:##SVTODATE</SET>
          </FIELD>
        </TDLMESSAGE>
      </TDL>
    </DESC>
  </BODY>
</ENVELOPE>`;
}
function buildOpenCompaniesQuery() {
  return `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>Export</TALLYREQUEST>
    <TYPE>Collection</TYPE>
    <ID>ListOfOpenCompanies</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
      </STATICVARIABLES>
      <TDL>
        <TDLMESSAGE>
          <COLLECTION NAME="ListOfOpenCompanies" ISMODIFY="No">
            <TYPE>Company</TYPE>
            <FETCH>NAME, STARTINGFROM, BOOKSFROM, PARTYGSTIN, GSTIN, GUID</FETCH>
          </COLLECTION>
        </TDLMESSAGE>
      </TDL>
    </DESC>
  </BODY>
</ENVELOPE>`;
}
function buildLedgersQuery(lastAlterId = 0, companyName) {
  const companyTag = companyName ? `
        <SVCURRENTCOMPANY>${escapeXml(companyName)}</SVCURRENTCOMPANY>` : "";
  return `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>Export</TALLYREQUEST>
    <TYPE>Collection</TYPE>
    <ID>CustomLedgerCollection</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>${companyTag}
      </STATICVARIABLES>
      <TDL>
        <TDLMESSAGE>
          <COLLECTION NAME="CustomLedgerCollection" ISMODIFY="No">
            <TYPE>Ledger</TYPE>
            <FETCH>NAME, PARENT, OPENINGBALANCE, CLOSINGBALANCE, LEDGERPHONE, EMAIL, PARTYGSTIN, BILLCREDITPERIOD, ALTERID</FETCH>
            <FILTER>AlterIdFilter</FILTER>
          </COLLECTION>
          <SYSTEM TYPE="Formulae" NAME="AlterIdFilter">$$Number:$AlterId &gt; ${lastAlterId}</SYSTEM>
        </TDLMESSAGE>
      </TDL>
    </DESC>
  </BODY>
</ENVELOPE>`;
}
function buildBillsQuery(companyName) {
  const companyTag = companyName ? `
        <SVCURRENTCOMPANY>${escapeXml(companyName)}</SVCURRENTCOMPANY>` : "";
  return `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>Export</TALLYREQUEST>
    <TYPE>Collection</TYPE>
    <ID>BillsCollection</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>${companyTag}
      </STATICVARIABLES>
      <TDL>
        <TDLMESSAGE>
          <COLLECTION NAME="BillsCollection" ISMODIFY="No">
            <TYPE>Bills</TYPE>
            <CHILDOF>$$GroupSundryDebtors</CHILDOF>
            <BELONGSTO>Yes</BELONGSTO>
            <FETCH>PARENT, BILLDATE, BILLREF, BILLDUE, OPENINGBALANCE, CLOSINGBALANCE, ISDEBIT</FETCH>
          </COLLECTION>
        </TDLMESSAGE>
      </TDL>
    </DESC>
  </BODY>
</ENVELOPE>`;
}
function buildStockItemsQuery(lastAlterId = 0, companyName) {
  const companyTag = companyName ? `
        <SVCURRENTCOMPANY>${escapeXml(companyName)}</SVCURRENTCOMPANY>` : "";
  return `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>Export</TALLYREQUEST>
    <TYPE>Collection</TYPE>
    <ID>CustomStockCollection</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>${companyTag}
      </STATICVARIABLES>
      <TDL>
        <TDLMESSAGE>
          <COLLECTION NAME="CustomStockCollection" ISMODIFY="No">
            <TYPE>StockItem</TYPE>
            <FETCH>NAME, PARENT, PARTNO, CLOSINGBALANCE, CLOSINGRATE, CLOSINGVALUE, BASEUNITS, ALTERID</FETCH>
            <FILTER>StockAlterFilter</FILTER>
          </COLLECTION>
          <SYSTEM TYPE="Formulae" NAME="StockAlterFilter">$$Number:$AlterId &gt; ${lastAlterId}</SYSTEM>
        </TDLMESSAGE>
      </TDL>
    </DESC>
  </BODY>
</ENVELOPE>`;
}
function buildStockJournalVoucherXml(params) {
  const isAddition = params.qty > 0;
  const absQty = Math.abs(params.qty);
  const amount = (absQty * params.rateRupees).toFixed(2);
  const staticVars = params.companyName ? `<STATICVARIABLES>
        <SVCURRENTCOMPANY>${escapeXml(params.companyName)}</SVCURRENTCOMPANY>
      </STATICVARIABLES>` : `<STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
      </STATICVARIABLES>`;
  const godown = escapeXml(params.godownName || "Main Location");
  const itemBlock = isAddition ? `<INVENTORYENTRIESIN.LIST>
        <STOCKITEMNAME>${escapeXml(params.itemName)}</STOCKITEMNAME>
        <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
        <RATE>${params.rateRupees} / ${escapeXml(params.unit)}</RATE>
        <AMOUNT>-${amount}</AMOUNT>
        <ACTUALQTY>${absQty} ${escapeXml(params.unit)}</ACTUALQTY>
        <BILLEDQTY>${absQty} ${escapeXml(params.unit)}</BILLEDQTY>
        <BATCHALLOCATIONS.LIST>
          <GODOWNNAME>${godown}</GODOWNNAME>
          <BATCHNAME>Primary Batch</BATCHNAME>
          <AMOUNT>-${amount}</AMOUNT>
          <ACTUALQTY>${absQty} ${escapeXml(params.unit)}</ACTUALQTY>
          <BILLEDQTY>${absQty} ${escapeXml(params.unit)}</BILLEDQTY>
        </BATCHALLOCATIONS.LIST>
      </INVENTORYENTRIESIN.LIST>` : `<INVENTORYENTRIESOUT.LIST>
        <STOCKITEMNAME>${escapeXml(params.itemName)}</STOCKITEMNAME>
        <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
        <RATE>${params.rateRupees} / ${escapeXml(params.unit)}</RATE>
        <AMOUNT>${amount}</AMOUNT>
        <ACTUALQTY>${absQty} ${escapeXml(params.unit)}</ACTUALQTY>
        <BILLEDQTY>${absQty} ${escapeXml(params.unit)}</BILLEDQTY>
        <BATCHALLOCATIONS.LIST>
          <GODOWNNAME>${godown}</GODOWNNAME>
          <BATCHNAME>Primary Batch</BATCHNAME>
          <AMOUNT>${amount}</AMOUNT>
          <ACTUALQTY>${absQty} ${escapeXml(params.unit)}</ACTUALQTY>
          <BILLEDQTY>${absQty} ${escapeXml(params.unit)}</BILLEDQTY>
        </BATCHALLOCATIONS.LIST>
      </INVENTORYENTRIESOUT.LIST>`;
  return `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>Import</TALLYREQUEST>
    <TYPE>Data</TYPE>
    <ID>Vouchers</ID>
  </HEADER>
  <BODY>
    <DESC>
      ${staticVars}
    </DESC>
    <DATA>
      <TALLYMESSAGE>
        <UNIT NAME="${escapeXml(params.unit)}" ACTION="Create">
          <NAME>${escapeXml(params.unit)}</NAME>
          <ISSIMPLEUNIT>Yes</ISSIMPLEUNIT>
        </UNIT>
      </TALLYMESSAGE>
      <TALLYMESSAGE>
        <STOCKITEM NAME="${escapeXml(params.itemName)}" ACTION="Alter">
          <NAME.LIST>
            <NAME>${escapeXml(params.itemName)}</NAME>
          </NAME.LIST>
          <BASEUNITS>${escapeXml(params.unit)}</BASEUNITS>
        </STOCKITEM>
      </TALLYMESSAGE>
      <TALLYMESSAGE>
        <VOUCHER VCHTYPE="Stock Journal" ACTION="Create">
          <DATE>${params.date}</DATE>
          <VOUCHERNUMBER>${escapeXml(params.voucherNumber)}</VOUCHERNUMBER>
          <VOUCHERTYPENAME>Stock Journal</VOUCHERTYPENAME>
          <NARRATION>${escapeXml(params.narration)}</NARRATION>
          ${itemBlock}
        </VOUCHER>
      </TALLYMESSAGE>
    </DATA>
  </BODY>
</ENVELOPE>`;
}
function buildDeliveryChallanVoucherXml(params) {
  const isPurchase = params.voucherType === "purchase";
  const tallyVchType = params.voucherType === "sales" ? "Sales" : isPurchase ? "Purchase" : "Delivery Note";
  const signPrefix = isPurchase ? "-" : "";
  const partySignPrefix = isPurchase ? "" : "-";
  const defaultLedger = params.salesLedgerName || (isPurchase ? "Purchase Account" : "Sales Account");
  const staticVars = params.companyName ? `<STATICVARIABLES>
        <SVCURRENTCOMPANY>${escapeXml(params.companyName)}</SVCURRENTCOMPANY>
      </STATICVARIABLES>` : `<STATICVARIABLES>
        <SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>
      </STATICVARIABLES>`;
  const totalAmountNum = params.items.reduce((sum, item) => sum + item.qty * item.rateRupees, 0);
  const totalAmount = totalAmountNum.toFixed(2);
  const itemEntries = params.items.map((item) => {
    const amount = (item.qty * item.rateRupees).toFixed(2);
    const godown = escapeXml(item.godownName || "Main Location");
    const itemAmount = isPurchase ? "-" + amount : amount;
    return `<ALLINVENTORYENTRIES.LIST>
          <STOCKITEMNAME>${escapeXml(item.itemName)}</STOCKITEMNAME>
          <ISDEEMEDPOSITIVE>${isPurchase ? "Yes" : "No"}</ISDEEMEDPOSITIVE>
          <RATE>${item.rateRupees} / ${escapeXml(item.unit)}</RATE>
          <AMOUNT>${itemAmount}</AMOUNT>
          <ACTUALQTY>${item.qty} ${escapeXml(item.unit)}</ACTUALQTY>
          <BILLEDQTY>${item.qty} ${escapeXml(item.unit)}</BILLEDQTY>
          <BATCHALLOCATIONS.LIST>
            <GODOWNNAME>${godown}</GODOWNNAME>
            <BATCHNAME>Primary Batch</BATCHNAME>
            <AMOUNT>${itemAmount}</AMOUNT>
            <ACTUALQTY>${item.qty} ${escapeXml(item.unit)}</ACTUALQTY>
            <BILLEDQTY>${item.qty} ${escapeXml(item.unit)}</BILLEDQTY>
          </BATCHALLOCATIONS.LIST>
          <ACCOUNTINGALLOCATIONS.LIST>
            <LEDGERNAME>${escapeXml(defaultLedger)}</LEDGERNAME>
            <ISDEEMEDPOSITIVE>${isPurchase ? "Yes" : "No"}</ISDEEMEDPOSITIVE>
            <AMOUNT>${signPrefix}${amount}</AMOUNT>
          </ACCOUNTINGALLOCATIONS.LIST>
        </ALLINVENTORYENTRIES.LIST>`;
  }).join("\n");
  const vehicleNarration = params.vehicleNo ? `${params.narration} (Vehicle: ${params.vehicleNo})` : params.narration;
  return `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>Import</TALLYREQUEST>
    <TYPE>Data</TYPE>
    <ID>Vouchers</ID>
  </HEADER>
  <BODY>
    <DESC>
      ${staticVars}
    </DESC>
    <DATA>
      <TALLYMESSAGE>
        <VOUCHER VCHTYPE="${tallyVchType}" ACTION="Create" OBJVIEW="Invoice Voucher View">
          <DATE>${params.date}</DATE>
          <VOUCHERNUMBER>${escapeXml(params.voucherNumber)}</VOUCHERNUMBER>
          <VOUCHERTYPENAME>${tallyVchType}</VOUCHERTYPENAME>
          <PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW>
          <ISINVOICE>Yes</ISINVOICE>
          <PARTYLEDGERNAME>${escapeXml(params.partyName)}</PARTYLEDGERNAME>
          <BASICBUYERNAME>${escapeXml(params.partyName)}</BASICBUYERNAME>
          <NARRATION>${escapeXml(vehicleNarration)}</NARRATION>
          <LEDGERENTRIES.LIST>
            <LEDGERNAME>${escapeXml(params.partyName)}</LEDGERNAME>
            <ISDEEMEDPOSITIVE>${isPurchase ? "No" : "Yes"}</ISDEEMEDPOSITIVE>
            <ISPARTYLEDGER>Yes</ISPARTYLEDGER>
            <AMOUNT>${partySignPrefix}${totalAmount}</AMOUNT>
          </LEDGERENTRIES.LIST>
          ${itemEntries}
        </VOUCHER>
      </TALLYMESSAGE>
    </DATA>
  </BODY>
</ENVELOPE>`;
}
function escapeXml(str) {
  return String(str === void 0 || str === null ? "" : str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

// src/tally/parser.ts
var import_fast_xml_parser = __toESM(require_fxp(), 1);
var import_shared = __toESM(require_dist(), 1);
var xmlParser = new import_fast_xml_parser.XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  textNodeName: "#text",
  trimValues: true,
  parseTagValue: false
  // Keep values as strings to avoid floating point truncation
});
function extractXmlText(node) {
  if (node === void 0 || node === null) return "";
  if (typeof node === "string") return node.trim();
  if (typeof node === "number" || typeof node === "boolean") return String(node);
  if (typeof node === "object") {
    if (node["#text"] !== void 0) return extractXmlText(node["#text"]);
    if (node._ !== void 0) return extractXmlText(node._);
    for (const k of Object.keys(node)) {
      if (!k.startsWith("@_")) {
        const val = extractXmlText(node[k]);
        if (val) return val;
      }
    }
  }
  return "";
}
function toArray(val) {
  if (!val) return [];
  return Array.isArray(val) ? val : [val];
}
function parseTallyAmount(amountStr) {
  if (amountStr === void 0 || amountStr === null || amountStr === "") return 0;
  const text = extractXmlText(amountStr);
  if (!text) return 0;
  const beforeSlash = text.split("/")[0] || "";
  const raw = beforeSlash.replace(/,/g, "").trim();
  const isCr = /(?:cr|credit)\.?$/i.test(raw);
  const isDr = /(?:dr|debit)\.?$/i.test(raw);
  const isTrailingMinus = /-\s*$/.test(raw) || raw.endsWith("-");
  const isLeadingMinus = raw.startsWith("-");
  const numOnly = raw.replace(/[^\d.-]/g, "");
  const parsed = parseFloat(numOnly);
  if (isNaN(parsed)) return 0;
  const paise = (0, import_shared.rupeesToPaise)(Math.abs(parsed));
  if (isCr || isTrailingMinus || isLeadingMinus) return -paise;
  if (isDr) return paise;
  return parsed < 0 ? -paise : paise;
}
function parseTallyLedgerBalance(amountStr, isDebtor = true) {
  if (amountStr === void 0 || amountStr === null || amountStr === "") return 0;
  const text = extractXmlText(amountStr);
  if (!text) return 0;
  const raw = text.replace(/,/g, "").trim();
  const isCr = /(?:cr|credit)\.?$/i.test(raw);
  const isDr = /(?:dr|debit)\.?$/i.test(raw);
  const isNegativeInXml = raw.startsWith("-") || /-\s*$/.test(raw) || raw.endsWith("-");
  const numOnly = raw.replace(/[^\d.]/g, "");
  const parsed = parseFloat(numOnly);
  if (isNaN(parsed) || parsed === 0) return 0;
  const paise = (0, import_shared.rupeesToPaise)(parsed);
  if (isDr || isNegativeInXml && !isCr) {
    return paise;
  }
  if (isCr || !isNegativeInXml && !isDr) {
    return isDebtor ? -paise : paise;
  }
  return paise;
}
function parseTallyDate(dateStr) {
  const text = extractXmlText(dateStr);
  if (!text) return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const clean = text.trim();
  if (/^\d{8}$/.test(clean)) {
    return `${clean.slice(0, 4)}-${clean.slice(4, 6)}-${clean.slice(6, 8)}`;
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) {
    return clean;
  }
  const d = new Date(clean);
  if (!isNaN(d.getTime())) {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }
  return clean;
}
function parseCompanyInfoResponse(xmlString) {
  const parsed = xmlParser.parse(xmlString);
  const envelope = parsed?.ENVELOPE || parsed?.envelope;
  const body = envelope?.BODY || envelope?.body;
  const data = body?.DATA || body?.data;
  const companyName = extractXmlText(data?.COMPNAMEFIELD) || extractXmlText(data?.COMPANYNAME) || extractXmlText(body?.DESC?.STATICVARIABLES?.SVCURRENTCOMPANY) || extractXmlText(data?.TALLYMESSAGE?.COMPANY?.NAME) || "";
  const fromDate = parseTallyDate(extractXmlText(data?.COMPYEARFIELD) || "20260401");
  const booksFrom = parseTallyDate(extractXmlText(data?.COMPBOOKSFIELD) || fromDate);
  return {
    name: companyName.trim(),
    financialYearFrom: fromDate,
    booksFrom
  };
}
function parseOpenCompaniesResponse(xmlString) {
  const parsed = xmlParser.parse(xmlString);
  const envelope = parsed?.ENVELOPE || parsed?.envelope;
  const body = envelope?.BODY || envelope?.body;
  const data = body?.DATA || body?.data;
  const messages = toArray(data?.TALLYMESSAGE || data?.COLLECTION?.COMPANY || data?.COMPANY);
  const companies = [];
  const seen = /* @__PURE__ */ new Set();
  for (const msg of messages) {
    const rawComp = msg?.COMPANY || msg;
    if (!rawComp || typeof rawComp !== "object") continue;
    const name = extractXmlText(rawComp["@_NAME"] || rawComp.NAME || rawComp.COMPANYNAME);
    if (!name) continue;
    const cleanName = name.trim();
    if (!cleanName || cleanName === "[object Object]" || seen.has(cleanName.toLowerCase())) continue;
    seen.add(cleanName.toLowerCase());
    const fromDate = parseTallyDate(extractXmlText(rawComp.STARTINGFROM || rawComp.COMPYEARFIELD) || "20260401");
    const booksFrom = parseTallyDate(extractXmlText(rawComp.BOOKSFROM || rawComp.COMPBOOKSFIELD) || fromDate);
    const guid = extractXmlText(rawComp.GUID) || void 0;
    companies.push({
      name: cleanName,
      financialYearFrom: fromDate,
      booksFrom,
      guid
    });
  }
  return companies;
}
function parseLedgersResponse(xmlString) {
  const parsed = xmlParser.parse(xmlString);
  const envelope = parsed?.ENVELOPE || parsed?.envelope;
  const body = envelope?.BODY || envelope?.body;
  const data = body?.DATA || body?.data;
  const messages = toArray(data?.TALLYMESSAGE || data?.COLLECTION?.LEDGER);
  const ledgers = [];
  for (const msg of messages) {
    const rawLedger = msg?.LEDGER || msg;
    if (!rawLedger || typeof rawLedger !== "object") continue;
    const name = extractXmlText(rawLedger["@_NAME"] || rawLedger.NAME);
    if (!name || name === "[object Object]") continue;
    const parent = extractXmlText(rawLedger.PARENT);
    const parentLower = parent.toLowerCase();
    const isDebtor = parentLower.includes("debtor") || parentLower.includes("customer");
    const isCreditor = parentLower.includes("creditor") || parentLower.includes("supplier");
    const alterId = parseInt(extractXmlText(rawLedger.ALTERID) || "0", 10) || 0;
    const phone = extractXmlText(rawLedger.LEDGERPHONE || rawLedger.PHONE) || void 0;
    const email = extractXmlText(rawLedger.EMAIL) || void 0;
    const gstin = extractXmlText(rawLedger.PARTYGSTIN || rawLedger.GSTIN) || void 0;
    const creditDays = parseInt(extractXmlText(rawLedger.BILLCREDITPERIOD) || "30", 10) || 30;
    ledgers.push({
      name: name.trim(),
      parent,
      openingBalance: parseTallyLedgerBalance(rawLedger.OPENINGBALANCE, isDebtor),
      closingBalance: parseTallyLedgerBalance(rawLedger.CLOSINGBALANCE, isDebtor),
      phone,
      email,
      gstin,
      creditDays,
      alterId,
      isSundryDebtor: isDebtor,
      isSundryCreditor: isCreditor
    });
  }
  return ledgers;
}
function parseBillsResponse(xmlString, today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)) {
  const parsed = xmlParser.parse(xmlString);
  const envelope = parsed?.ENVELOPE || parsed?.envelope;
  const body = envelope?.BODY || envelope?.body;
  const data = body?.DATA || body?.data;
  const messages = toArray(data?.TALLYMESSAGE || data?.COLLECTION?.BILLS);
  const bills = [];
  for (const msg of messages) {
    const rawBill = msg?.BILLS || msg;
    if (!rawBill || typeof rawBill !== "object") continue;
    const partyName = extractXmlText(rawBill.PARENT || rawBill["@_PARENT"]);
    const billNo = extractXmlText(rawBill.BILLREF || rawBill["@_BILLREF"]);
    if (!partyName || !billNo || partyName === "[object Object]" || billNo === "[object Object]") continue;
    const billDate = parseTallyDate(rawBill.BILLDATE);
    const dueDate = parseTallyDate(rawBill.BILLDUE || rawBill.BILLDATE);
    const isDebitRaw = rawBill.ISDEBIT !== void 0 ? rawBill.ISDEBIT : rawBill["@_ISDEBIT"];
    let isDebit = void 0;
    if (isDebitRaw !== void 0 && isDebitRaw !== null) {
      const s = extractXmlText(isDebitRaw).trim().toLowerCase();
      if (s === "yes" || s === "true" || s === "1") isDebit = true;
      if (s === "no" || s === "false" || s === "0") isDebit = false;
    }
    const parsedClosing = parseTallyAmount(rawBill.CLOSINGBALANCE);
    const parsedOpening = parseTallyAmount(rawBill.OPENINGBALANCE);
    let closingAmount = parsedClosing;
    if (isDebit === false && closingAmount > 0) {
      closingAmount = -closingAmount;
    } else if (isDebit === true && closingAmount < 0) {
      closingAmount = Math.abs(closingAmount);
    }
    let openingAmount = parsedOpening;
    if (isDebit === false && openingAmount > 0) {
      openingAmount = -openingAmount;
    } else if (isDebit === true && openingAmount < 0) {
      openingAmount = Math.abs(openingAmount);
    }
    if (openingAmount === 0 && closingAmount !== 0) {
      openingAmount = closingAmount;
    }
    const isPending = closingAmount > 0;
    const daysLate = isPending ? (0, import_shared.getDaysOverdue)(dueDate, today) : 0;
    bills.push({
      partyName: partyName.trim(),
      billNo: billNo.trim(),
      billDate,
      dueDate,
      openingAmount,
      pendingAmount: closingAmount,
      isOverdue: isPending && daysLate > 0,
      daysOverdue: Math.max(0, daysLate)
    });
  }
  return bills;
}
function parseStockItemsResponse(xmlString) {
  const parsed = xmlParser.parse(xmlString);
  const envelope = parsed?.ENVELOPE || parsed?.envelope;
  const body = envelope?.BODY || envelope?.body;
  const data = body?.DATA || body?.data;
  const messages = toArray(data?.TALLYMESSAGE || data?.COLLECTION?.STOCKITEM);
  const stockItems = [];
  for (const msg of messages) {
    const rawItem = msg?.STOCKITEM || msg;
    if (!rawItem || typeof rawItem !== "object") continue;
    const name = extractXmlText(rawItem["@_NAME"] || rawItem.NAME);
    if (!name || name === "[object Object]") continue;
    const rawQtyStr = extractXmlText(rawItem.CLOSINGBALANCE);
    const qtyMatch = rawQtyStr.match(/([-+]?\d+(\.\d+)?)/);
    const closingQty = qtyMatch && qtyMatch[1] ? parseFloat(qtyMatch[1]) : 0;
    const rawUnits = extractXmlText(rawItem.BASEUNITS);
    const baseUnits = rawUnits && rawUnits !== "[object Object]" ? rawUnits : "pcs";
    const rawParent = extractXmlText(rawItem.PARENT);
    const parent = rawParent && rawParent !== "[object Object]" ? rawParent : void 0;
    const rawPartNo = extractXmlText(rawItem.PARTNO);
    const partNo = rawPartNo && rawPartNo !== "[object Object]" ? rawPartNo : void 0;
    const closingRate = parseTallyAmount(rawItem.CLOSINGRATE);
    const closingValue = parseTallyAmount(rawItem.CLOSINGVALUE);
    const alterId = parseInt(extractXmlText(rawItem.ALTERID) || "0", 10) || 0;
    stockItems.push({
      name: name.trim(),
      parent,
      partNo,
      closingQty,
      baseUnits,
      closingRate,
      closingValue,
      alterId
    });
  }
  return stockItems;
}
function parseVoucherImportResponse(xmlString) {
  const parsed = xmlParser.parse(xmlString);
  const resp = parsed?.RESPONSE || parsed?.ENVELOPE?.BODY?.DATA?.IMPORTRESULT;
  const created = parseInt(extractXmlText(resp?.CREATED) || "0", 10) || 0;
  const altered = parseInt(extractXmlText(resp?.ALTERED) || "0", 10) || 0;
  const errors = parseInt(extractXmlText(resp?.ERRORS) || "0", 10) || 0;
  const lineErrors = resp?.LINEERROR ? toArray(resp.LINEERROR).map(extractXmlText).join("; ") : void 0;
  return {
    success: errors === 0 && (created > 0 || altered > 0),
    created,
    altered,
    errors,
    message: lineErrors
  };
}

// src/tally/mock.ts
function getMockCompanyInfoXml() {
  return `<?xml version="1.0" encoding="utf-8"?>
<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <STATUS>1</STATUS>
  </HEADER>
  <BODY>
    <DATA>
      <COMPANYNAME>Manohar Traders</COMPANYNAME>
      <COMPNAMEFIELD>Manohar Traders</COMPNAMEFIELD>
      <COMPYEARFIELD>20260401</COMPYEARFIELD>
      <COMPBOOKSFIELD>20260401</COMPBOOKSFIELD>
    </DATA>
  </BODY>
</ENVELOPE>`;
}
function getMockOpenCompaniesXml() {
  return `<?xml version="1.0" encoding="utf-8"?>
<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <STATUS>1</STATUS>
  </HEADER>
  <BODY>
    <DATA>
      <TALLYMESSAGE xmlns:UDF="TallyUDF">
        <COMPANY NAME="Manohar Traders">
          <NAME>Manohar Traders</NAME>
          <STARTINGFROM>20260401</STARTINGFROM>
          <BOOKSFROM>20260401</BOOKSFROM>
        </COMPANY>
      </TALLYMESSAGE>
    </DATA>
  </BODY>
</ENVELOPE>`;
}
function getMockLedgersXml(lastAlterId = 0) {
  const allLedgers = [
    {
      name: "Sample Garments Pvt Ltd",
      parent: "Sundry Debtors",
      opening: "105840.00 Dr",
      closing: "105840.00 Dr",
      phone: "+91 98390 12345",
      email: "accounts@samplegarments.com",
      gstin: "09AABCS1234F1Z3",
      creditPeriod: "30",
      alterId: 1475
    },
    {
      name: "Bharat Textiles",
      parent: "Sundry Debtors",
      opening: "245000.00 Dr",
      closing: "245000.00 Dr",
      phone: "+91 98141 55667",
      email: "info@bharattextiles.in",
      gstin: "03AABCB5678G1Z4",
      creditPeriod: "45",
      alterId: 1478
    },
    {
      name: "Royal Fashion Hub",
      parent: "Sundry Debtors",
      opening: "88500.00 Dr",
      closing: "88500.00 Dr",
      phone: "+91 98722 88990",
      email: "royal@fashionhub.com",
      gstin: "03AAACR9912H1Z8",
      creditPeriod: "30",
      alterId: 1480
    },
    {
      name: "Apex Stitching Co",
      parent: "Sundry Debtors",
      opening: "42300.00 Dr",
      closing: "42300.00 Dr",
      phone: "+91 98555 44332",
      email: "purchase@apexstitching.com",
      gstin: "03AABCA9012J1Z2",
      creditPeriod: "30",
      alterId: 1472
    },
    {
      name: "Golden Yarns & Fibres",
      parent: "Sundry Creditors",
      opening: "350000.00 Cr",
      closing: "350000.00 Cr",
      phone: "+91 98111 22334",
      email: "sales@goldenyarns.com",
      gstin: "07AABCG4455K1Z9",
      creditPeriod: "60",
      alterId: 1468
    }
  ];
  const filtered = allLedgers.filter((l) => l.alterId > lastAlterId);
  const ledgersXml = filtered.map(
    (l) => `
    <TALLYMESSAGE xmlns:UDF="TallyUDF">
      <LEDGER NAME="${l.name}">
        <NAME>${l.name}</NAME>
        <PARENT>${l.parent}</PARENT>
        <OPENINGBALANCE>${l.opening}</OPENINGBALANCE>
        <CLOSINGBALANCE>${l.closing}</CLOSINGBALANCE>
        <LEDGERPHONE>${l.phone}</LEDGERPHONE>
        <EMAIL>${l.email}</EMAIL>
        <PARTYGSTIN>${l.gstin}</PARTYGSTIN>
        <BILLCREDITPERIOD>${l.creditPeriod}</BILLCREDITPERIOD>
        <ALTERID>${l.alterId}</ALTERID>
      </LEDGER>
    </TALLYMESSAGE>`
  ).join("\n");
  return `<?xml version="1.0" encoding="utf-8"?>
<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <STATUS>1</STATUS>
  </HEADER>
  <BODY>
    <DATA>
      ${ledgersXml}
    </DATA>
  </BODY>
</ENVELOPE>`;
}
function getMockBillsXml() {
  return `<?xml version="1.0" encoding="utf-8"?>
<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <STATUS>1</STATUS>
  </HEADER>
  <BODY>
    <DATA>
      <TALLYMESSAGE>
        <BILLS>
          <PARENT>Sample Garments Pvt Ltd</PARENT>
          <BILLREF>GST/004/26-27</BILLREF>
          <BILLDATE>20260910</BILLDATE>
          <BILLDUE>20261010</BILLDUE>
          <CLOSINGBALANCE>105840.00 Dr</CLOSINGBALANCE>
          <ISDEBIT>Yes</ISDEBIT>
        </BILLS>
      </TALLYMESSAGE>
      <TALLYMESSAGE>
        <BILLS>
          <PARENT>Bharat Textiles</PARENT>
          <BILLREF>INV/142/26-27</BILLREF>
          <BILLDATE>20260815</BILLDATE>
          <BILLDUE>20260929</BILLDUE>
          <CLOSINGBALANCE>245000.00 Dr</CLOSINGBALANCE>
          <ISDEBIT>Yes</ISDEBIT>
        </BILLS>
      </TALLYMESSAGE>
      <TALLYMESSAGE>
        <BILLS>
          <PARENT>Royal Fashion Hub</PARENT>
          <BILLREF>INV/188/26-27</BILLREF>
          <BILLDATE>20260905</BILLDATE>
          <BILLDUE>20261005</BILLDUE>
          <CLOSINGBALANCE>88500.00 Dr</CLOSINGBALANCE>
          <ISDEBIT>Yes</ISDEBIT>
        </BILLS>
      </TALLYMESSAGE>
      <TALLYMESSAGE>
        <BILLS>
          <PARENT>Apex Stitching Co</PARENT>
          <BILLREF>INV/195/26-27</BILLREF>
          <BILLDATE>20260920</BILLDATE>
          <BILLDUE>20261020</BILLDUE>
          <CLOSINGBALANCE>42300.00 Dr</CLOSINGBALANCE>
          <ISDEBIT>Yes</ISDEBIT>
        </BILLS>
      </TALLYMESSAGE>
    </DATA>
  </BODY>
</ENVELOPE>`;
}
function getMockStockItemsXml(lastAlterId = 0) {
  const allItems = [
    {
      name: "Servo Motor 550W (Direct Drive)",
      parent: "Industrial Motors",
      partNo: "SM-550-DD",
      closingQty: 18,
      baseUnits: "pcs",
      closingRate: 4200,
      closingValue: 75600,
      alterId: 1476
    },
    {
      name: "Rotary Hook Assembly (Japanese Type)",
      parent: "Sewing Accessories",
      partNo: "RH-220-JP",
      closingQty: 84,
      baseUnits: "set",
      closingRate: 850,
      closingValue: 71400,
      alterId: 1479
    },
    {
      name: "Heavy Duty Needle Plate B-24",
      parent: "Sewing Accessories",
      partNo: "NP-B24-HD",
      closingQty: 145,
      baseUnits: "pcs",
      closingRate: 180,
      closingValue: 26100,
      alterId: 1465
    },
    {
      name: "Standard Bobbin Case (Lockstitch)",
      parent: "Sewing Accessories",
      partNo: "BC-LK-01",
      closingQty: 320,
      baseUnits: "pcs",
      closingRate: 95,
      closingValue: 30400,
      alterId: 1470
    }
  ];
  const filtered = allItems.filter((i) => i.alterId > lastAlterId);
  const itemsXml = filtered.map(
    (i) => `
    <TALLYMESSAGE xmlns:UDF="TallyUDF">
      <STOCKITEM NAME="${i.name}">
        <NAME>${i.name}</NAME>
        <PARENT>${i.parent}</PARENT>
        <PARTNO>${i.partNo}</PARTNO>
        <CLOSINGBALANCE>${i.closingQty} ${i.baseUnits}</CLOSINGBALANCE>
        <CLOSINGRATE>${i.closingRate} / ${i.baseUnits}</CLOSINGRATE>
        <CLOSINGVALUE>${i.closingValue}</CLOSINGVALUE>
        <BASEUNITS>${i.baseUnits}</BASEUNITS>
        <ALTERID>${i.alterId}</ALTERID>
      </STOCKITEM>
    </TALLYMESSAGE>`
  ).join("\n");
  return `<?xml version="1.0" encoding="utf-8"?>
<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <STATUS>1</STATUS>
  </HEADER>
  <BODY>
    <DATA>
      ${itemsXml}
    </DATA>
  </BODY>
</ENVELOPE>`;
}
function getMockVoucherImportResponseXml() {
  return `<?xml version="1.0" encoding="utf-8"?>
<RESPONSE>
  <CREATED>1</CREATED>
  <ALTERED>0</ALTERED>
  <DELETED>0</DELETED>
  <LASTVCHID>98124</LASTVCHID>
  <LASTMID>1481</LASTMID>
  <COMBINED>0</COMBINED>
  <IGNORED>0</IGNORED>
  <ERRORS>0</ERRORS>
</RESPONSE>`;
}

// src/tally/client.ts
var CANDIDATE_TALLY_PORTS = [25853, 9e3, 9001, 9002, 9003, 9004, 9005, 9006, 9007, 9008, 9009, 9010, 9999];
function normalizeTallyCompanyName(name) {
  return (name || "").toLowerCase().replace(/\s*-\s*\(from.*?\)/gi, "").replace(/\s*\(\s*\d{2,4}\s*-\s*\d{2,4}\s*\)/gi, "").replace(/\s+/g, " ").trim();
}
var TallyClient = class {
  url;
  mock;
  timeoutMs;
  constructor(options = {}) {
    this.url = options.url || "http://127.0.0.1:25853";
    this.mock = options.mock ?? false;
    this.timeoutMs = options.timeoutMs || 8e3;
  }
  setMockMode(mock) {
    this.mock = mock;
  }
  isMockMode() {
    return this.mock;
  }
  getUrl() {
    return this.url;
  }
  getActivePort() {
    try {
      const u = new URL(this.url);
      return parseInt(u.port || "9000", 10) || 9e3;
    } catch {
      return 9e3;
    }
  }
  /**
   * Automatically scans local ports 9000-9010 & 9999 when the configured port is unreachable
   */
  async discoverActivePort() {
    if (this.mock) return this.url;
    const probeXml = buildCompanyInfoQuery();
    for (const port of CANDIDATE_TALLY_PORTS) {
      const candidateUrl = `http://127.0.0.1:${port}`;
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 1200);
        const resp = await fetch(candidateUrl, {
          method: "POST",
          headers: { "Content-Type": "text/xml;charset=utf-8" },
          body: probeXml,
          signal: controller.signal
        });
        clearTimeout(timer);
        if (resp.ok) {
          this.url = candidateUrl;
          return candidateUrl;
        }
      } catch {
      }
    }
    return null;
  }
  async postXml(xmlPayload, allowPortScan = true) {
    if (this.mock) {
      if (xmlPayload.includes("ListOfOpenCompanies")) return getMockOpenCompaniesXml();
      if (xmlPayload.includes("CompanyInfo")) return getMockCompanyInfoXml();
      if (xmlPayload.includes("CustomLedgerCollection")) {
        const alterMatch = xmlPayload.match(/AlterId &gt; (\d+)/);
        const lastAlter = alterMatch && alterMatch[1] ? parseInt(alterMatch[1], 10) : 0;
        return getMockLedgersXml(lastAlter);
      }
      if (xmlPayload.includes("BillsCollection")) return getMockBillsXml();
      if (xmlPayload.includes("CustomStockCollection")) {
        const alterMatch = xmlPayload.match(/StockAlterFilter">.*?(\d+)/);
        const lastAlter = alterMatch && alterMatch[1] ? parseInt(alterMatch[1], 10) : 0;
        return getMockStockItemsXml(lastAlter);
      }
      if (xmlPayload.includes("TALLYREQUEST>Import</TALLYREQUEST>")) {
        return getMockVoucherImportResponseXml();
      }
      return getMockCompanyInfoXml();
    }
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), this.timeoutMs);
      const resp = await fetch(this.url, {
        method: "POST",
        headers: {
          "Content-Type": "text/xml;charset=utf-8"
        },
        body: xmlPayload,
        signal: controller.signal
      });
      clearTimeout(timer);
      if (!resp.ok) {
        throw new Error(`Tally server responded with status ${resp.status}`);
      }
      return await resp.text();
    } catch (err) {
      if (this.mock) {
        return this.postXml(xmlPayload, false);
      }
      if (allowPortScan) {
        const discovered = await this.discoverActivePort();
        if (discovered) {
          return this.postXml(xmlPayload, false);
        }
      }
      throw new Error(`Cannot reach Tally at ${this.url}: ${err.message}. Ensure TallyPrime is open with connectivity enabled on port 9000-9010.`);
    }
  }
  async ping() {
    if (this.mock) {
      return { ok: true, company: "Manohar Traders (Mock Mode)", port: 9e3 };
    }
    try {
      const xml = await this.postXml(buildCompanyInfoQuery());
      const info = parseCompanyInfoResponse(xml);
      return { ok: true, company: info.name, port: this.getActivePort() };
    } catch (err) {
      return { ok: false, port: this.getActivePort(), error: err.message };
    }
  }
  async getCompanyInfo(companyName) {
    const xml = await this.postXml(buildCompanyInfoQuery(companyName));
    return parseCompanyInfoResponse(xml);
  }
  async getOpenCompanies() {
    try {
      const xml = await this.postXml(buildOpenCompaniesQuery());
      const openList = parseOpenCompaniesResponse(xml);
      if (openList.length > 0) {
        return openList;
      }
    } catch {
    }
    try {
      const active = await this.getCompanyInfo();
      return active?.name ? [active] : [];
    } catch {
      return [];
    }
  }
  async getLedgers(lastAlterId = 0, companyName) {
    const xml = await this.postXml(buildLedgersQuery(lastAlterId, companyName));
    return parseLedgersResponse(xml);
  }
  async getBills(today, companyName) {
    const xml = await this.postXml(buildBillsQuery(companyName));
    return parseBillsResponse(xml, today);
  }
  async getStockItems(lastAlterId = 0, companyName) {
    const xml = await this.postXml(buildStockItemsQuery(lastAlterId, companyName));
    return parseStockItemsResponse(xml);
  }
  async postVoucher(voucherXml) {
    const xml = await this.postXml(voucherXml);
    return parseVoucherImportResponse(xml);
  }
};

// src/sync/state.ts
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
var StateStore = class {
  filePath;
  state;
  constructor(filePath) {
    if (filePath) {
      this.filePath = filePath;
    } else {
      let scriptDir = process.cwd();
      try {
        if (typeof import.meta !== "undefined" && import.meta.url) {
          scriptDir = path.dirname(fileURLToPath(import.meta.url));
        }
      } catch {
      }
      const scriptState = path.resolve(scriptDir, "agent-state.json");
      const cwdState = path.resolve(process.cwd(), "agent-state.json");
      this.filePath = fs.existsSync(scriptState) ? scriptState : cwdState;
    }
    this.state = this.load();
  }
  load() {
    const bakPath = `${this.filePath}.bak`;
    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, "utf-8").replace(/^\uFEFF/, "").trim();
        if (raw.length > 0) {
          const parsed = JSON.parse(raw);
          try {
            fs.copyFileSync(this.filePath, bakPath);
          } catch {
          }
          return parsed;
        }
      }
    } catch (err) {
      console.warn(`[StateStore] Could not load state from ${this.filePath}: ${err.message}`);
    }
    try {
      if (fs.existsSync(bakPath)) {
        const rawBak = fs.readFileSync(bakPath, "utf-8");
        if (rawBak.trim().length > 0) {
          const parsedBak = JSON.parse(rawBak);
          console.warn(`[StateStore] Successfully recovered state from backup: ${bakPath}`);
          try {
            fs.writeFileSync(this.filePath, JSON.stringify(parsedBak, null, 2), "utf-8");
          } catch {
          }
          return parsedBak;
        }
      }
    } catch (err) {
      console.warn(`[StateStore] Could not load backup state from ${bakPath}: ${err.message}`);
    }
    return {
      lastAlterId: 0,
      status: "offline"
    };
  }
  get() {
    return { ...this.state };
  }
  update(patch) {
    this.state = {
      ...this.state,
      ...patch
    };
    this.save();
    return this.state;
  }
  save() {
    try {
      const dir = path.dirname(this.filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      const tmpPath = `${this.filePath}.tmp`;
      const bakPath = `${this.filePath}.bak`;
      const serialized = JSON.stringify(this.state, null, 2);
      fs.writeFileSync(tmpPath, serialized, "utf-8");
      try {
        fs.copyFileSync(tmpPath, bakPath);
      } catch {
      }
      try {
        fs.renameSync(tmpPath, this.filePath);
      } catch {
        fs.copyFileSync(tmpPath, this.filePath);
        try {
          fs.unlinkSync(tmpPath);
        } catch {
        }
      }
    } catch (err) {
      console.error(`[StateStore] Failed to save state to ${this.filePath}: ${err.message}`);
    }
  }
  getFilePath() {
    return this.filePath;
  }
  reset() {
    const companies = Array.isArray(this.state.companies) ? this.state.companies.map((c) => ({ ...c, lastAlterId: 0, lastSyncedAt: void 0 })) : this.state.companies;
    this.state = {
      ...this.state,
      lastAlterId: 0,
      lastSyncedAt: void 0,
      companies,
      status: "offline"
    };
    this.save();
  }
};

// src/sync/engine.ts
import fs2 from "node:fs";
import path2 from "node:path";
import crypto2 from "node:crypto";
import { fileURLToPath as fileURLToPath2 } from "node:url";
function slugify(text) {
  const ascii = text.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  if (ascii) return ascii;
  let hash = 5381;
  for (let i = 0; i < text.length; i++) {
    hash = (hash << 5) + hash + text.charCodeAt(i);
  }
  return `item-${Math.abs(hash).toString(36)}`;
}
var SyncEngine = class {
  client;
  store;
  cloudUrl;
  companyId;
  agentSecretKey;
  pollIntervalMs;
  pollTimer = null;
  isRunning = false;
  syncCount = 0;
  pendingAlterIdReset = false;
  knownCreditors = /* @__PURE__ */ new Set();
  onSyncComplete;
  onSyncError;
  constructor(options) {
    this.client = options.client;
    this.store = options.store;
    this.cloudUrl = options.cloudUrl || process.env.CLOUD_URL || options.store.get().cloudUrl;
    this.companyId = options.companyId || process.env.COMPANY_ID || options.store.get().companyId;
    this.agentSecretKey = options.agentSecretKey || process.env.AGENT_KEY || options.store.get().agentSecretKey || "dev-agent-secret-key";
    this.pollIntervalMs = options.pollIntervalMs || 3e4;
    this.onSyncComplete = options.onSyncComplete;
    this.onSyncError = options.onSyncError;
  }
  /**
   * Over-The-Air (OTA) silent self-updater for tally-agent.mjs.
   * Compares local bundle SHA-256 with Cloud /api/agent/version and atomically replaces bundle if changed.
   */
  async checkAndApplyOtaUpdate() {
    if (!this.cloudUrl || this.client.isMockMode()) return false;
    try {
      let scriptPath = "";
      try {
        if (typeof import.meta !== "undefined" && import.meta.url) {
          scriptPath = fileURLToPath2(import.meta.url);
        }
      } catch {
      }
      const mjsPath = scriptPath && scriptPath.endsWith("tally-agent.mjs") ? scriptPath : path2.resolve(process.cwd(), "tally-agent.mjs");
      if (!fs2.existsSync(mjsPath)) return false;
      const localBuf = fs2.readFileSync(mjsPath);
      const localSha = crypto2.createHash("sha256").update(localBuf).digest("hex");
      const key = this.agentSecretKey || this.store.get().agentSecretKey || "dev-agent-secret-key";
      const verRes = await fetch(`${this.cloudUrl}/api/agent/version`, {
        headers: { "x-agent-key": key }
      });
      if (!verRes.ok) return false;
      const verData = await verRes.json();
      if (!verData?.sha256 || verData.sha256 === "unknown" || verData.sha256 === localSha) {
        this.store.update({ bundleSha256: localSha });
        return false;
      }
      const bundleRes = await fetch(`${this.cloudUrl}/api/agent/bundle`, {
        headers: { "x-agent-key": key }
      });
      if (!bundleRes.ok) return false;
      const newBuf = Buffer.from(await bundleRes.arrayBuffer());
      const downloadedSha = crypto2.createHash("sha256").update(newBuf).digest("hex");
      if (downloadedSha !== verData.sha256 || newBuf.length < 1e3) {
        return false;
      }
      const downloadedText = newBuf.toString("utf8");
      if (!downloadedText.includes("extractXmlText")) {
        console.log("[OTA] Skipping cloud bundle because it is an older version than local tally-agent.mjs.");
        return false;
      }
      const tmpPath = `${mjsPath}.tmp`;
      fs2.writeFileSync(tmpPath, newBuf);
      try {
        if (fs2.existsSync(mjsPath)) {
          fs2.copyFileSync(mjsPath, `${mjsPath}.bak`);
        }
      } catch (backupErr) {
        console.warn(`[OTA] Failed to create tally-agent.mjs.bak backup: ${backupErr.message}`);
      }
      try {
        fs2.renameSync(tmpPath, mjsPath);
      } catch {
        fs2.copyFileSync(tmpPath, mjsPath);
        try {
          fs2.unlinkSync(tmpPath);
        } catch {
        }
      }
      this.store.update({ bundleSha256: downloadedSha });
      console.log(`[OTA] Updated tally-agent.mjs to latest cloud bundle (${downloadedSha.slice(0, 8)}).`);
      if (this.isRunning) {
        console.log("[OTA] Exiting with code 42 so watchdog supervisor restarts updated agent...");
        process.exit(42);
      }
      return true;
    } catch {
      return false;
    }
  }
  findCompanyConfigByName(name, list = []) {
    if (!name) return void 0;
    const norm = normalizeTallyCompanyName(name);
    if (!norm) return void 0;
    return list.find((c) => {
      const cNorm = normalizeTallyCompanyName(c.tallyName || c.companyName);
      return cNorm && (cNorm === norm || cNorm.includes(norm) || norm.includes(cNorm));
    });
  }
  async runSyncOnce() {
    const startTime = Date.now();
    const currentState = this.store.get();
    this.syncCount += 1;
    if (this.syncCount === 1 || this.syncCount % 20 === 0) {
      await this.checkAndApplyOtaUpdate();
    }
    try {
      let company = await this.client.getCompanyInfo();
      let openCompanies = [];
      try {
        openCompanies = await this.client.getOpenCompanies();
      } catch {
        openCompanies = company?.name ? [company] : [];
      }
      if (!company?.name && openCompanies.length > 0 && openCompanies[0]?.name) {
        company = openCompanies[0];
      }
      const openNamesSet = /* @__PURE__ */ new Set();
      const openCompanyNames = [];
      for (const oc of [company, ...openCompanies]) {
        if (oc?.name && !openNamesSet.has(oc.name.toLowerCase())) {
          openNamesSet.add(oc.name.toLowerCase());
          openCompanyNames.push(oc.name);
        }
      }
      const targetCompany = company?.name;
      const activePort = this.client.getActivePort();
      const knownList = Array.isArray(currentState.companies) ? [...currentState.companies] : [];
      const matchedConfig = this.findCompanyConfigByName(targetCompany, knownList);
      const isPairedNameMatching = !currentState.companyName || normalizeTallyCompanyName(currentState.companyName) === normalizeTallyCompanyName(targetCompany || "");
      const primaryCompanyId = matchedConfig?.companyId || (isPairedNameMatching ? this.companyId || currentState.companyId : void 0);
      const isSameAsPreviousSync = Boolean(currentState.companyName && targetCompany) && normalizeTallyCompanyName(currentState.companyName || "") === normalizeTallyCompanyName(targetCompany || "");
      const lastAlterId = isSameAsPreviousSync ? currentState.lastAlterId || 0 : matchedConfig?.lastAlterId || 0;
      if (company?.name) {
        this.store.update({
          companyName: company.name,
          tallyPort: activePort,
          openTallyCompanies: openCompanyNames.length > 0 ? openCompanyNames : [company.name]
        });
      }
      if (this.cloudUrl && primaryCompanyId) {
        await this.pullOutboxFromCloud(primaryCompanyId, targetCompany);
      }
      const ledgers = await this.client.getLedgers(0);
      const bills = await this.client.getBills();
      const stockItems = await this.client.getStockItems(0);
      let maxAlterId = lastAlterId;
      for (const l of ledgers) {
        if (l.alterId > maxAlterId) maxAlterId = l.alterId;
      }
      for (const s of stockItems) {
        if (s.alterId > maxAlterId) maxAlterId = s.alterId;
      }
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const payload = {
        company,
        ledgers,
        bills,
        stockItems,
        maxAlterId,
        syncedAt: nowIso,
        durationMs: Date.now() - startTime
      };
      let resolvedPrimaryId = primaryCompanyId;
      if (this.cloudUrl) {
        const pushResultId = await this.pushToCloud(payload, primaryCompanyId);
        if (pushResultId) resolvedPrimaryId = pushResultId;
      }
      const syncedNamesNorm = /* @__PURE__ */ new Set();
      const syncedCompanyIds = /* @__PURE__ */ new Set();
      if (targetCompany) syncedNamesNorm.add(normalizeTallyCompanyName(targetCompany));
      if (resolvedPrimaryId) syncedCompanyIds.add(resolvedPrimaryId);
      if (resolvedPrimaryId && targetCompany) {
        const existingIdx = knownList.findIndex(
          (c) => c.companyId === resolvedPrimaryId || normalizeTallyCompanyName(c.tallyName || c.companyName) === normalizeTallyCompanyName(targetCompany)
        );
        const updatedEntry = {
          companyId: resolvedPrimaryId,
          companyName: targetCompany,
          tallyName: targetCompany,
          lastAlterId: this.pendingAlterIdReset ? 0 : maxAlterId,
          lastSyncedAt: nowIso
        };
        if (existingIdx >= 0) {
          knownList[existingIdx] = updatedEntry;
        } else {
          knownList.push(updatedEntry);
        }
      }
      const additionalTargets = [];
      for (const openCompName of openCompanyNames) {
        const openNorm = normalizeTallyCompanyName(openCompName);
        if (!openNorm || syncedNamesNorm.has(openNorm)) continue;
        const matchedCfg = this.findCompanyConfigByName(openCompName, knownList);
        const candidateId = matchedCfg?.companyId && !syncedCompanyIds.has(matchedCfg.companyId) ? matchedCfg.companyId : void 0;
        additionalTargets.push({
          companyId: candidateId,
          tallyName: openCompName,
          lastAlterId: matchedCfg?.lastAlterId || 0
        });
        if (candidateId) syncedCompanyIds.add(candidateId);
        syncedNamesNorm.add(openNorm);
      }
      for (const extra of additionalTargets) {
        try {
          const extraTarget = extra.tallyName;
          if (this.cloudUrl && extra.companyId) {
            await this.pullOutboxFromCloud(extra.companyId, extraTarget);
          }
          const extraInfo = await this.client.getCompanyInfo(extraTarget);
          if (extraInfo?.name) {
            const extraLedgers = await this.client.getLedgers(0, extraTarget);
            const extraBills = await this.client.getBills(void 0, extraTarget);
            const extraStock = await this.client.getStockItems(0, extraTarget);
            let extraMaxAlter = extra.lastAlterId || 0;
            for (const l of extraLedgers) if (l.alterId > extraMaxAlter) extraMaxAlter = l.alterId;
            for (const s of extraStock) if (s.alterId > extraMaxAlter) extraMaxAlter = s.alterId;
            let resolvedExtraId = extra.companyId;
            if (this.cloudUrl) {
              const cloudId = await this.pushToCloud(
                {
                  company: extraInfo,
                  ledgers: extraLedgers,
                  bills: extraBills,
                  stockItems: extraStock,
                  maxAlterId: extraMaxAlter,
                  syncedAt: nowIso,
                  durationMs: Date.now() - startTime
                },
                extra.companyId
              );
              if (cloudId) resolvedExtraId = cloudId;
              if (!extra.companyId && resolvedExtraId) {
                await this.pullOutboxFromCloud(resolvedExtraId, extraInfo.name);
              }
            }
            if (resolvedExtraId) {
              const idx = knownList.findIndex(
                (c) => c.companyId === resolvedExtraId || normalizeTallyCompanyName(c.tallyName || c.companyName) === normalizeTallyCompanyName(extraInfo.name)
              );
              const entry = {
                companyId: resolvedExtraId,
                companyName: extraInfo.name,
                tallyName: extraInfo.name,
                lastAlterId: extraMaxAlter,
                lastSyncedAt: nowIso
              };
              if (idx >= 0) knownList[idx] = entry;
              else knownList.push(entry);
            }
          }
        } catch {
        }
      }
      const newAlterId = this.pendingAlterIdReset ? 0 : maxAlterId;
      this.pendingAlterIdReset = false;
      this.store.update({
        companyName: company.name,
        lastAlterId: newAlterId,
        lastSyncedAt: nowIso,
        status: "online",
        tallyPort: activePort,
        openTallyCompanies: openCompanyNames.length > 0 ? openCompanyNames : [company.name],
        companies: knownList.length > 0 ? knownList : currentState.companies
      });
      this.onSyncComplete?.(payload);
      return payload;
    } catch (err) {
      this.store.update({ status: "offline" });
      if (this.cloudUrl) {
        await this.sendCloudHeartbeat(false, err?.message || "Local Tally unreachable");
      }
      this.onSyncError?.(err);
      throw err;
    }
  }
  async sendCloudHeartbeat(tallyOk, tallyError) {
    if (!this.cloudUrl) return;
    const state = this.store.get();
    const companyId2 = this.companyId || state.companyId;
    const companyName = state.companyName;
    const key = this.agentSecretKey || state.agentSecretKey || "dev-agent-secret-key";
    try {
      const res = await fetch(`${this.cloudUrl}/api/agent/sync`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-agent-key": key
        },
        body: JSON.stringify({
          companyId: companyId2,
          companyName,
          tallyStatus: tallyOk ? "online" : "offline",
          tallyError: tallyError || null,
          tallyPort: this.client.getActivePort(),
          openTallyCompanies: state.openTallyCompanies || (companyName ? [companyName] : [])
        })
      });
      if (res.ok) {
        const syncRes = await res.json().catch(() => ({}));
        if (Array.isArray(syncRes?.commands) && syncRes.commands.length > 0) {
          this.handleCloudCommands(syncRes.commands);
        }
        this.store.update({
          cloudStatus: "connected",
          lastCloudSyncAt: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
    } catch {
    }
  }
  /**
   * Handle remote commands delivered from SaaS cloud (e.g. RESET_ALTER_ID, FORCE_OTA_UPDATE, RESTART_AGENT, PAUSE_SYNC, RESUME_SYNC, SET_CONFIG, EXEC_TALLY_XML).
   */
  handleCloudCommands(commands) {
    for (const cmd of commands) {
      if (cmd.type === "RESET_ALTER_ID" || cmd.type === "SYNC_NOW") {
        const targetDesc = cmd.companyId ? `company ${cmd.companyId}` : "all companies";
        console.log(`[SyncEngine] [REMOTE COMMAND] Received ${cmd.type} for ${targetDesc}. Resetting lastAlterId to 0.`);
        this.pendingAlterIdReset = true;
        const currentState = this.store.get();
        if (!cmd.companyId || cmd.companyId === this.companyId || cmd.companyId === currentState.companyId) {
          this.store.update({ lastAlterId: 0 });
        }
        if (Array.isArray(currentState.companies)) {
          const updated = currentState.companies.map((c) => {
            if (!cmd.companyId || c.companyId === cmd.companyId) {
              return { ...c, lastAlterId: 0 };
            }
            return c;
          });
          this.store.update({ companies: updated });
        }
      } else if (cmd.type === "SET_CONFIG") {
        console.log("[SyncEngine] [REMOTE COMMAND] Received SET_CONFIG:", JSON.stringify(cmd));
        const updates = {};
        if (typeof cmd.tallyUrl === "string" && cmd.tallyUrl.trim()) {
          updates.tallyUrl = cmd.tallyUrl.trim();
        }
        if (typeof cmd.tallyPort === "number" && cmd.tallyPort > 0) {
          updates.tallyPort = cmd.tallyPort;
          updates.tallyUrl = `http://127.0.0.1:${cmd.tallyPort}`;
        }
        if (typeof cmd.companyId === "string" && cmd.companyId.trim()) {
          this.companyId = cmd.companyId.trim();
          updates.companyId = this.companyId;
        }
        if (typeof cmd.companyName === "string" && cmd.companyName.trim()) {
          updates.companyName = cmd.companyName.trim();
        }
        if (typeof cmd.cloudUrl === "string" && cmd.cloudUrl.trim()) {
          this.cloudUrl = cmd.cloudUrl.trim();
          updates.cloudUrl = this.cloudUrl;
        }
        if (typeof cmd.pollIntervalMs === "number" && cmd.pollIntervalMs >= 5e3) {
          this.pollIntervalMs = cmd.pollIntervalMs;
        }
        if (Object.keys(updates).length > 0) {
          this.store.update(updates);
        }
      } else if (cmd.type === "FORCE_OTA_UPDATE") {
        console.log("[SyncEngine] [REMOTE COMMAND] Received FORCE_OTA_UPDATE. Checking for latest bundle immediately...");
        void this.checkAndApplyOtaUpdate();
      } else if (cmd.type === "RESTART_AGENT") {
        console.log("[SyncEngine] [REMOTE COMMAND] Received RESTART_AGENT. Exiting with code 42 for supervisor restart...");
        if (this.isRunning) {
          process.exit(42);
        }
      } else if (cmd.type === "EXEC_TALLY_XML" && typeof cmd.xml === "string" && cmd.xml.trim()) {
        console.log("[SyncEngine] [REMOTE COMMAND] Received EXEC_TALLY_XML. Posting custom XML to TallyPrime...");
        void this.client.postVoucher(cmd.xml).catch((err) => {
          console.error("[SyncEngine] [REMOTE COMMAND] EXEC_TALLY_XML failed:", err?.message || err);
        });
      }
    }
  }
  async pushToCloud(payload, targetCompanyId) {
    if (!this.cloudUrl) return targetCompanyId;
    const state = this.store.get();
    const companyName = payload.company?.name || state.companyName;
    const isNameMatchingState = !companyName || !state.companyName || normalizeTallyCompanyName(state.companyName) === normalizeTallyCompanyName(companyName);
    const companyId2 = targetCompanyId || (isNameMatchingState ? this.companyId || state.companyId : void 0);
    const key = this.agentSecretKey || state.agentSecretKey || "dev-agent-secret-key";
    const companyPrefix = companyId2 ? `${slugify(companyId2)}-` : companyName ? `${slugify(companyName)}-` : "";
    for (const l of payload.ledgers) {
      if (l.isSundryCreditor || l.parent.toLowerCase().includes("creditor") || l.parent.toLowerCase().includes("supplier")) {
        this.knownCreditors.add(l.name.toLowerCase().trim());
      }
    }
    const parties = payload.ledgers.filter((l) => l.isSundryDebtor || l.isSundryCreditor || l.parent.toLowerCase().includes("debtor") || l.parent.toLowerCase().includes("creditor")).map((l) => ({
      id: `p-${companyPrefix}${slugify(l.name)}`,
      name: l.name,
      city: "",
      phones: l.phone ? [l.phone] : [],
      gstin: l.gstin || null,
      creditDays: l.creditDays || 30,
      notes: `Imported from Tally (${l.parent})`,
      closingBalance: l.closingBalance || 0
    }));
    const bills = payload.bills.filter((b) => {
      const nameLower = b.partyName.toLowerCase().trim();
      return !this.knownCreditors.has(nameLower) && !nameLower.includes("sundry creditor") && !nameLower.includes("creditor");
    }).map((b) => ({
      id: `b-${companyPrefix}${slugify(b.partyName)}-${slugify(b.billNo)}`,
      partyId: `p-${companyPrefix}${slugify(b.partyName)}`,
      billNo: b.billNo,
      date: b.billDate,
      dueDate: b.dueDate,
      dueDays: 30,
      amount: b.openingAmount ?? b.pendingAmount,
      pending: b.pendingAmount,
      source: "tally_bill"
    }));
    const stockItems = payload.stockItems.map((s) => ({
      id: `s-${companyPrefix}${slugify(s.name)}`,
      name: s.name,
      partNo: s.partNo || null,
      unit: s.baseUnits || "pcs",
      group: s.parent || "General",
      rate: s.closingRate || 0,
      closingQty: s.closingQty || 0,
      reorderLevel: 5,
      alias: null
    }));
    const pushRes = await fetch(`${this.cloudUrl}/api/sync/push`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-agent-key": key
      },
      body: JSON.stringify({
        companyId: companyId2,
        companyName,
        alterId: payload.maxAlterId,
        reconcilePaidBills: true,
        parties,
        bills,
        stockItems
      })
    });
    if (!pushRes.ok) {
      const err = await pushRes.text();
      throw new Error(`Cloud sync push failed (${pushRes.status}): ${err}`);
    }
    const pushData = await pushRes.json().catch(() => ({}));
    if (Array.isArray(pushData?.commands) && pushData.commands.length > 0) {
      this.handleCloudCommands(pushData.commands);
    }
    if (Array.isArray(pushData?.tenantCompanies) && pushData.tenantCompanies.length > 0) {
      const currentList = Array.isArray(this.store.get().companies) ? [...this.store.get().companies || []] : [];
      for (const tc of pushData.tenantCompanies) {
        if (!tc?.companyId) continue;
        const exists = currentList.some((c) => c.companyId === tc.companyId);
        if (!exists) {
          currentList.push({
            companyId: tc.companyId,
            companyName: tc.companyName || tc.tallyName || "Tally Company",
            tallyName: tc.tallyName || tc.companyName,
            lastAlterId: 0
          });
        }
      }
      this.store.update({ companies: currentList });
    }
    this.store.update({
      cloudStatus: "connected",
      lastCloudSyncAt: (/* @__PURE__ */ new Date()).toISOString(),
      lastSyncStats: {
        partiesUpdated: pushData.partiesUpdated || 0,
        billsUpdated: pushData.billsUpdated || 0,
        stockUpdated: pushData.stockUpdated || 0
      }
    });
    await this.sendCloudHeartbeat(true);
    return pushData?.companyId || companyId2;
  }
  async pullOutboxFromCloud(targetCompanyId, overrideCompanyName) {
    if (!this.cloudUrl) return 0;
    const companyId2 = targetCompanyId || this.companyId || this.store.get().companyId;
    const key = this.agentSecretKey || this.store.get().agentSecretKey || "dev-agent-secret-key";
    const pullUrl = companyId2 ? `${this.cloudUrl}/api/sync/pull?companyId=${encodeURIComponent(companyId2)}` : `${this.cloudUrl}/api/sync/pull`;
    const pullRes = await fetch(pullUrl, {
      headers: {
        "x-agent-key": key
      }
    });
    if (!pullRes.ok) return 0;
    const cmdHeader = pullRes.headers.get("x-agent-commands");
    if (cmdHeader) {
      try {
        const cmds = JSON.parse(cmdHeader);
        if (Array.isArray(cmds) && cmds.length > 0) {
          this.handleCloudCommands(cmds);
        }
      } catch {
      }
    }
    const queuedItems = await pullRes.json();
    let syncedCount = 0;
    for (const item of queuedItems) {
      try {
        const formattedDate = item.date ? item.date.replace(/-/g, "") : (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replace(/-/g, "");
        const targetCompanyName = overrideCompanyName || item.companyName || this.store.get().companyName;
        let result;
        if (item.kind === "stock_journal") {
          result = await this.pushStockAdjustment({
            companyName: targetCompanyName,
            date: formattedDate,
            voucherNumber: item.number || item.id,
            narration: item.narration || item.reason || `Mobile Stock Adjustment (${item.id})`,
            itemName: item.itemName || item.refId,
            godownName: item.godownName || "Main Location",
            qty: item.deltaQty ?? item.qty ?? 0,
            unit: item.unit || "pcs",
            rateRupees: (item.rate || 0) / 100
          });
        } else {
          result = await this.pushDeliveryChallan({
            companyName: targetCompanyName,
            date: formattedDate,
            voucherNumber: item.number || item.id,
            partyName: item.partyName || item.partyId,
            narration: item.narration || `Mobile Challan (${item.id})`,
            vehicleNo: item.vehicleNo,
            voucherType: item.type || "delivery",
            items: (item.lines || []).map((l) => ({
              itemName: l.description || l.itemId,
              godownName: item.godownName,
              qty: l.qty || 1,
              unit: l.unit || "pcs",
              rateRupees: (l.rate || 0) / 100
            }))
          });
        }
        const status = result.success && result.errors === 0 ? "synced" : "failed";
        await fetch(`${this.cloudUrl}/api/sync/ack`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-agent-key": key
          },
          body: JSON.stringify({
            challanId: item.id,
            outboxId: item.outboxId || item.id,
            kind: item.kind || "challan",
            status,
            failureReason: status === "failed" ? result.message || "Tally XML import error" : null
          })
        });
        if (status === "synced") syncedCount++;
      } catch (err) {
        console.error(`[SyncEngine] Failed to import item ${item.id} to Tally:`, err.message);
      }
    }
    return syncedCount;
  }
  // Push a stock adjustment to Tally
  async pushStockAdjustment(params) {
    const xml = buildStockJournalVoucherXml(params);
    return await this.client.postVoucher(xml);
  }
  // Push a delivery challan to Tally
  async pushDeliveryChallan(params) {
    const xml = buildDeliveryChallanVoucherXml(params);
    return await this.client.postVoucher(xml);
  }
  startPolling() {
    if (this.isRunning) return;
    this.isRunning = true;
    const poll = async () => {
      try {
        await this.runSyncOnce();
      } catch (err) {
        console.error(`[SyncEngine] Poll failed: ${err.message}`);
      }
      if (this.isRunning) {
        this.pollTimer = setTimeout(poll, this.pollIntervalMs);
      }
    };
    poll();
  }
  stopPolling() {
    this.isRunning = false;
    if (this.pollTimer) {
      clearTimeout(this.pollTimer);
      this.pollTimer = null;
    }
  }
  getStatus() {
    return {
      isRunning: this.isRunning,
      state: this.store.get(),
      isMock: this.client.isMockMode()
    };
  }
};

// src/lock.ts
import fs3 from "node:fs";
import path3 from "node:path";
function acquireSingleInstanceLock(lockFilePath, onConflict) {
  const lockDir = path3.dirname(lockFilePath);
  if (!fs3.existsSync(lockDir)) {
    try {
      fs3.mkdirSync(lockDir, { recursive: true });
    } catch {
    }
  }
  try {
    if (fs3.existsSync(lockFilePath)) {
      const content = fs3.readFileSync(lockFilePath, "utf8").trim();
      const existingPid = parseInt(content, 10);
      if (!isNaN(existingPid) && existingPid > 0 && existingPid !== process.pid) {
        let isRunning = false;
        try {
          process.kill(existingPid, 0);
          isRunning = true;
        } catch (e) {
          if (e.code === "EPERM") {
            isRunning = true;
          }
        }
        if (isRunning) {
          if (onConflict) {
            onConflict(existingPid);
            return () => {
            };
          }
          console.error(`
[Error] Another instance of Tally Agent is already running (PID: ${existingPid})!`);
          console.error("Only one instance may run at a time to prevent TallyPrime sync conflicts.");
          console.error(`If you believe this is in error, delete: ${lockFilePath}
`);
          process.exit(1);
        } else {
          console.warn(`[Lock] Found stale lock file from inactive PID ${existingPid}. Reclaiming lock.`);
        }
      }
    }
    fs3.writeFileSync(lockFilePath, String(process.pid), { flag: "w" });
  } catch (err) {
    console.warn(`[Lock] Warning: Could not write lock file (${err.message}). Proceeding.`);
  }
  const releaseLock = () => {
    try {
      if (fs3.existsSync(lockFilePath)) {
        const content = fs3.readFileSync(lockFilePath, "utf8").trim();
        if (parseInt(content, 10) === process.pid) {
          fs3.unlinkSync(lockFilePath);
        }
      }
    } catch {
    }
  };
  process.on("exit", releaseLock);
  return releaseLock;
}

// src/index.ts
var import_shared2 = __toESM(require_dist(), 1);
var args = process.argv.slice(2);
var command = args[0] || "help";
var isMock = args.includes("--mock");
var intervalArg = args.find((a) => a.startsWith("--interval="));
var pollIntervalMs = intervalArg ? parseInt(intervalArg.split("=")[1], 10) : 3e4;
var cloudArg = args.find((a) => a.startsWith("--cloud="));
var companyArg = args.find((a) => a.startsWith("--company="));
var keyArg = args.find((a) => a.startsWith("--key="));
var tallyArg = args.find((a) => a.startsWith("--tally="));
var store = new StateStore();
var savedState = store.get();
var cloudUrl = cloudArg ? cloudArg.split("=")[1] : process.env.CLOUD_URL || savedState.cloudUrl || "https://manohar.evolveexpert.com";
var companyId = companyArg ? companyArg.split("=")[1] : process.env.COMPANY_ID || savedState.companyId || "";
var agentSecretKey = keyArg ? keyArg.split("=")[1] : process.env.AGENT_KEY || savedState.agentSecretKey || "dev-agent-secret-key";
var rawTallyUrl = tallyArg ? tallyArg.split("=")[1] : process.env.TALLY_URL || savedState.tallyUrl || "http://127.0.0.1:25853";
var customPort = savedState?.tallyPort || savedState?.port;
var tallyUrl = rawTallyUrl || "http://127.0.0.1:25853";
if (customPort && !tallyArg) {
  try {
    const u = new URL(tallyUrl);
    u.port = String(customPort);
    tallyUrl = u.toString().replace(/\/$/, "");
  } catch {
    tallyUrl = `http://127.0.0.1:${customPort}`;
  }
}
var client = new TallyClient({
  url: tallyUrl,
  mock: isMock
});
process.on("uncaughtException", (err) => {
  console.error(`[${(/* @__PURE__ */ new Date()).toLocaleTimeString()}] Uncaught Exception (recovering): ${err?.message || err}`);
});
process.on("unhandledRejection", (reason) => {
  console.error(`[${(/* @__PURE__ */ new Date()).toLocaleTimeString()}] Unhandled Rejection (recovering): ${reason?.message || reason}`);
});
var engine = new SyncEngine({
  client,
  store,
  cloudUrl,
  companyId,
  agentSecretKey,
  pollIntervalMs,
  onSyncComplete: (p) => {
    console.log(
      `[${(/* @__PURE__ */ new Date()).toLocaleTimeString()}] Sync OK \xB7 Co: "${p.company.name}" \xB7 Ledgers: ${p.ledgers.length} \xB7 Bills: ${p.bills.length} \xB7 Stock: ${p.stockItems.length} \xB7 AlterID: ${p.maxAlterId} (${p.durationMs}ms)`
    );
  },
  onSyncError: (e) => {
    console.error(`[${(/* @__PURE__ */ new Date()).toLocaleTimeString()}] Sync Failed: ${e.message}`);
  }
});
async function main() {
  switch (command) {
    case "status": {
      console.log("=== Manohar Traders TallyPrime Sync Agent ===");
      const ping = await client.ping();
      const state = store.get();
      console.log(`
[Local Tally Configuration]`);
      console.log(`Tally URL:  ${tallyUrl}`);
      console.log(`Connection: ${ping.ok ? "ONLINE" : "OFFLINE"}`);
      console.log(`Mode:       ${client.isMockMode() ? "Mock Simulator" : `Live Tally (${tallyUrl})`}`);
      if (ping.company) console.log(`Active Co:  ${ping.company}`);
      if (ping.error) console.log(`Error:      ${ping.error}`);
      console.log(`
[Cloud SaaS Configuration]`);
      console.log(`Cloud URL:  ${cloudUrl || "Not set"}`);
      console.log(`Company ID: ${companyId ? `${companyId}${savedState.companyName ? ` (${savedState.companyName})` : ""}` : "NOT CONNECTED (Run 'tally-agent pair <code>')"}`);
      console.log(`Tenant ID:  ${savedState.tenantId || "Not set"}`);
      console.log(`Agent Key:  ${agentSecretKey ? "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022" + agentSecretKey.slice(-4) : "Not configured"}`);
      try {
        const infoRes = await fetch(`${cloudUrl}/api/sync/info`, {
          headers: { "x-agent-key": agentSecretKey || "" }
        });
        if (infoRes.ok) {
          const info = await infoRes.json();
          console.log(`Cloud Link: CONNECTED (Server time: ${info.serverTime})`);
          if (info.companies?.length) {
            console.log(`Companies:  ${info.companies.map((c) => `${c.name} (${c.id})`).join(", ")}`);
          }
        } else {
          console.log(`Cloud Link: AUTH/SERVER ERROR (${infoRes.status})`);
        }
      } catch (err) {
        console.log(`Cloud Link: OFFLINE (${err.message})`);
      }
      console.log(`
[Sync Progress]`);
      console.log(`Last Alter: ${state.lastAlterId}`);
      console.log(`Last Sync:  ${state.lastSyncedAt || "Never"}`);
      if (state.lastSyncStats) {
        console.log(`Last Push:  ${state.lastSyncStats.partiesUpdated} parties, ${state.lastSyncStats.billsUpdated} bills, ${state.lastSyncStats.stockUpdated} stock items`);
      }
      break;
    }
    case "config": {
      const patch = {};
      if (cloudArg) patch.cloudUrl = cloudArg.split("=")[1];
      if (companyArg) patch.companyId = companyArg.split("=")[1];
      if (keyArg) patch.agentSecretKey = keyArg.split("=")[1];
      if (tallyArg) patch.tallyUrl = tallyArg.split("=")[1];
      store.update(patch);
      console.log("Configuration updated:");
      console.log(store.get());
      break;
    }
    case "test": {
      console.log("Testing Tally and Cloud connections...");
      const ping = await client.ping();
      console.log(`1. TallyPrime (${tallyUrl}): ${ping.ok ? "SUCCESS (" + ping.company + ")" : "FAILED: " + ping.error}`);
      try {
        const res = await fetch(`${cloudUrl}/api/sync/info`, {
          headers: { "x-agent-key": agentSecretKey || "" }
        });
        if (res.ok) {
          console.log(`2. Cloud SaaS API:         SUCCESS (${cloudUrl})`);
        } else {
          console.log(`2. Cloud SaaS API:         ERROR (${res.status} ${res.statusText})`);
        }
      } catch (e) {
        console.log(`2. Cloud SaaS API:         FAILED (${e.message})`);
      }
      break;
    }
    case "sync": {
      if (!companyId) {
        console.error("\n[Error] Agent is not connected to any company / organization!");
        console.error("Please connect your agent using one of the following methods:");
        console.error("  1. Generate a Pairing Code in the Web App (Settings -> Desktop Tally Agent)");
        console.error("  2. Run: tally-agent pair <6-digit-code>");
        console.error("  3. Or run run-agent.bat and choose Option [4].\n");
        process.exit(1);
      }
      console.log(`Starting 2-way sync (Mode: ${client.isMockMode() ? "Mock" : "Live"})...`);
      try {
        const payload = await engine.runSyncOnce();
        console.log("\n--- Sync Results ---");
        console.log(`Company:       ${payload.company.name} (FY from ${payload.company.financialYearFrom})`);
        console.log(`New Ledgers:   ${payload.ledgers.length}`);
        payload.ledgers.slice(0, 5).forEach((l) => {
          console.log(`  \u2022 ${l.name} (${l.parent}) - AlterID: ${l.alterId} - Balance: ${(0, import_shared2.formatINR)(l.closingBalance)}`);
        });
        if (payload.ledgers.length > 5) console.log(`  ... and ${payload.ledgers.length - 5} more`);
        console.log(`
Active Bills:  ${payload.bills.length}`);
        payload.bills.slice(0, 5).forEach((b) => {
          console.log(`  \u2022 [${b.partyName}] ${b.billNo} - Due: ${b.dueDate} - Pending: ${(0, import_shared2.formatINR)(b.pendingAmount)} (${b.daysOverdue}d late)`);
        });
        if (payload.bills.length > 5) console.log(`  ... and ${payload.bills.length - 5} more`);
        console.log(`
Stock Items:   ${payload.stockItems.length}`);
        payload.stockItems.slice(0, 5).forEach((s) => {
          console.log(`  \u2022 ${s.name} - Qty: ${s.closingQty} ${s.baseUnits} - Rate: ${(0, import_shared2.formatINR)(s.closingRate)} - AlterID: ${s.alterId}`);
        });
        if (payload.stockItems.length > 5) console.log(`  ... and ${payload.stockItems.length - 5} more`);
        console.log(`
Max AlterID:   ${payload.maxAlterId}`);
        console.log(`Duration:      ${payload.durationMs}ms`);
        if (cloudUrl) {
          console.log(`
\u2713 Pushed to Cloud SaaS: ${cloudUrl}`);
        }
      } catch (err) {
        console.error("Sync failed:", err.message);
        process.exit(1);
      }
      break;
    }
    case "start": {
      if (!companyId) {
        console.error("\n[Error] Agent is not connected to any company / organization!");
        console.error("Please connect your agent using one of the following methods:");
        console.error("  1. Generate a Pairing Code in the Web App (Settings -> Desktop Tally Agent)");
        console.error("  2. Run: tally-agent pair <6-digit-code>");
        console.error("  3. Or run run-agent.bat and choose Option [4].\n");
        process.exit(1);
      }
      const lockPath = path4.resolve(path4.dirname(store.getFilePath()), "agent.lock");
      const releaseLock = acquireSingleInstanceLock(lockPath);
      console.log(`Starting Tally Sync Agent daemon (Poll Interval: ${pollIntervalMs}ms)...`);
      console.log(`Tally URL:  ${tallyUrl}`);
      console.log(`Cloud URL:  ${cloudUrl}`);
      console.log(`Company ID: ${companyId}${savedState.companyName ? ` (${savedState.companyName})` : ""}`);
      engine.startPolling();
      const shutdown = () => {
        console.log("\nStopping agent...");
        engine.stopPolling();
        releaseLock();
        process.exit(0);
      };
      process.on("SIGINT", shutdown);
      process.on("SIGTERM", shutdown);
      break;
    }
    case "pair": {
      const code = args[1];
      if (!code || !/^\d{6}$/.test(code.trim())) {
        console.error("Error: Please provide a valid 6-digit pairing code, e.g. tally-agent pair 839201");
        process.exit(1);
      }
      const pairCode = code.trim();
      const targetCloudUrl = cloudArg ? cloudArg.split("=")[1] : process.env.CLOUD_URL || savedState.cloudUrl || "https://manohar.evolveexpert.com";
      console.log(`Connecting to Cloud SaaS: ${targetCloudUrl}`);
      console.log(`Submitting pairing code:  ${pairCode}...`);
      try {
        const res = await fetch(`${targetCloudUrl}/api/agent/pair`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code: pairCode })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
          throw new Error(data.error || `Server returned error (${res.status})`);
        }
        store.update({
          companyId: data.companyId,
          companyName: data.companyName,
          tenantId: data.tenantId,
          agentSecretKey: data.agentSecretKey,
          cloudUrl: data.cloudUrl || targetCloudUrl,
          pairingKey: pairCode,
          status: "online"
        });
        console.log(`
================================================================`);
        console.log(`\u2713 PAIRING SUCCESSFUL!`);
        console.log(`Connected to Organization: "${data.companyName}"`);
        console.log(`Company ID:                ${data.companyId}`);
        if (data.tenantId) {
          console.log(`Tenant ID:                 ${data.tenantId}`);
        }
        console.log(`Cloud Server:              ${data.cloudUrl || targetCloudUrl}`);
        console.log(`================================================================
`);
        console.log(`Agent is now permanently configured for "${data.companyName}".`);
        console.log(`You can run 'tally-agent sync' to start syncing.`);
      } catch (err) {
        console.error(`
\u2717 Pairing failed: ${err.message}`);
        console.error(`Please make sure the pairing code has not expired (valid for 10m) and cloud server is reachable.`);
        process.exit(1);
      }
      break;
    }
    case "reset": {
      store.reset();
      console.log("Agent state reset. Next sync will fetch from AlterID 0.");
      break;
    }
    case "help":
    default: {
      console.log(`Manohar Companion Windows Tally Agent
Commands:
  status               Check local Tally connection & Cloud sync status
  test                 Verify connection to local Tally and Cloud API
  sync [--mock]        Run one-shot 2-way sync (push data, pull challans)
  start [--mock]       Start background sync daemon
  pair <code>          Pair agent with organization using 6-digit code from Web App
  config --cloud=URL --company=ID --key=KEY   Save configuration manually
  reset                Reset AlterID counter and state`);
      break;
    }
  }
}
main().catch((e) => {
  console.error("Fatal error:", e);
  process.exit(1);
});
/*! Bundled license information:

decimal.js/decimal.js:
  (*!
   *  decimal.js v10.6.0
   *  An arbitrary-precision Decimal type for JavaScript.
   *  https://github.com/MikeMcl/decimal.js
   *  Copyright (c) 2025 Michael Mclaughlin <M8ch88l@gmail.com>
   *  MIT Licence
   *)
*/
