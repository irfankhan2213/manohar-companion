================================================================================
MANOHAR TRADERS - TALLYPRIME SYNC AGENT (WINDOWS SETUP GUIDE)
================================================================================

1. PREREQUISITES:
   - Node.js LTS (v18 or higher) installed from https://nodejs.org
   - TallyPrime running on this PC.

2. ENABLE TALLYPRIME XML SERVER:
   - Open TallyPrime.
   - Press F12 (Configure) on your keyboard.
   - Click "Advanced Configuration".
   - Look for "TallyPrime acts as": Set to "Both" or "Server".
   - Look for "Enable ODBC Server": Set to "Yes".
   - Set Port: 9000.
   - Press Ctrl + A to save and restart TallyPrime.

3. RUNNING THE AGENT:
   - Double-click "run-agent.bat".
   - Select Option [1] to verify connection to both Tally and Cloud.
   - Select Option [2] to run your first manual sync.
   - Select Option [3] to run the continuous background sync daemon.

4. AUTOMATIC STARTUP ON WINDOWS:
   - Double-click "install-service.bat" to start the sync agent automatically
     in the background whenever this computer turns on.

================================================================================
